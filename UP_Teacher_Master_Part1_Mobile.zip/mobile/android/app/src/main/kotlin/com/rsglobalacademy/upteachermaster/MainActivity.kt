package com.rsglobalacademy.upteachermaster

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
