# Generate complete Android Gradle wrapper/platform files

The source package includes the app manifest, app-level Gradle configuration and Kotlin activity. The Flutter SDK generates version-specific root Gradle files and the Gradle wrapper for your installed Flutter release.

From this directory run:

```bash
flutter create --platforms=android --org com.rsglobalacademy --project-name up_teacher_master .
```

Then ensure the generated `android/app/src/main/AndroidManifest.xml` contains the deep-link intent filter below inside the main `<activity>`:

```xml
<intent-filter>
    <action android:name="android.intent.action.VIEW"/>
    <category android:name="android.intent.category.DEFAULT"/>
    <category android:name="android.intent.category.BROWSABLE"/>
    <data android:scheme="com.rsglobalacademy.upteachermaster" android:host="login-callback"/>
</intent-filter>
```

Ensure `applicationId` and `namespace` in `android/app/build.gradle` are both:
`com.rsglobalacademy.upteachermaster`

Then configure Supabase and run `flutter pub get`.
