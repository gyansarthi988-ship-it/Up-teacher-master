import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Phase 1 app identity', () {
    const appName = 'UP Teacher Master';
    expect(appName, contains('Teacher'));
  });
}
