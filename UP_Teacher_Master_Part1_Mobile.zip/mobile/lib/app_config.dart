class AppConfig {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://iuvnrtuycyeaxnkqsfrw.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml1dm5ydHV5Y3llYXhua3FzZnJ3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMzNTk3NzEsImV4cCI6MjEwODkzNTc3MX0.lAp7FLo8NmiVgl16AZnicsrMWsxquwpjIY8MFJOzr1E',
  );
  static const authRedirectUrl =
      'com.rsglobalacademy.upteachermaster://login-callback/';
}
