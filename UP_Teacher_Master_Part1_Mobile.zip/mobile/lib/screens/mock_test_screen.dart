import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Full-length mock test runner. Correct answers are never fetched by the client;
/// scoring and answer-key validation are performed by submit_test_attempt RPC.
class MockTestScreen extends StatefulWidget {
  final String examId;
  final int durationMinutes;
  final int questionCount;
  final String language; // 'hi' or 'en'
  final String? templateId;
  final Map<String, dynamic>? questionSelection;

  const MockTestScreen({super.key, required this.examId,
    this.durationMinutes = 120, this.questionCount = 100, this.language = 'hi',
    this.templateId, this.questionSelection});

  @override
  State<MockTestScreen> createState() => _MockTestScreenState();
}

class _MockTestScreenState extends State<MockTestScreen> {
  final _db = Supabase.instance.client;
  List<Map<String, dynamic>> _questions = [];
  final Map<String, String> _answers = {};
  final Set<int> _marked = {};
  int _current = 0;
  int _secondsLeft = 0;
  Timer? _timer;
  bool _loading = true;
  bool _submitting = false;
  bool _submitted = false;
  Map<String, dynamic>? _result;
  String? _error;

  bool get _hi => widget.language == 'hi';
  String t(String hi, String en) => _hi ? hi : en;

  @override
  void initState() { super.initState(); _secondsLeft = widget.durationMinutes * 60; _load(); }
  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  Future<void> _load() async {
    try {
      // Fetch only published questions. Template filters are applied before
      // the final question set is frozen; answer keys are never selected.
      final rows = await _db.from('questions').select('id,subject_id,topic_id,difficulty,question_hi,question_en,marks,negative_marks,question_options(id,option_key,text_hi,text_en,display_order)')
        .eq('exam_id', widget.examId).eq('status', 'published').limit(2000);
      final pool = (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      final config = widget.questionSelection ?? const <String, dynamic>{};
      final distribution = config['subject_distribution'];
      final difficulty = config['difficulty_distribution'];
      final List<Map<String, dynamic>> items = [];
      if (distribution is Map && distribution.isNotEmpty) {
        for (final entry in distribution.entries) {
          final subjectPool = pool.where((q) => q['subject_id'].toString() == entry.key.toString()).toList()..shuffle();
          final needed = (entry.value as num).toInt();
          final subjectDifficulty = difficulty is Map ? difficulty[entry.key] : null;
          if (subjectDifficulty is Map && subjectDifficulty.isNotEmpty) {
            final remaining = <Map<String, dynamic>>[...subjectPool];
            for (final d in subjectDifficulty.entries) {
              final count = (d.value as num).toInt();
              final matches = remaining.where((q) => q['difficulty'].toString() == d.key.toString()).take(count).toList();
              items.addAll(matches);
              remaining.removeWhere((q) => matches.any((m) => m['id'] == q['id']));
            }
            final selectedForSubject = items.where((q) => q['subject_id'].toString() == entry.key.toString()).length;
            if (selectedForSubject < needed) {
              final already = items.where((q) => q['subject_id'].toString() == entry.key.toString()).map((q) => q['id']).toSet();
              items.addAll(remaining.where((q) => !already.contains(q['id'])).take(needed - selectedForSubject));
            }
          } else {
            items.addAll(subjectPool.take(needed));
          }
          final selectedForSubject = items.where((q) => q['subject_id'].toString() == entry.key.toString()).length;
          if (selectedForSubject < needed) {
            throw Exception(t('किसी विषय में पर्याप्त प्रकाशित प्रश्न नहीं हैं।','Insufficient published questions in one or more subjects.'));
          }
        }
      } else {
        items.addAll(pool..shuffle());
        if (items.length > widget.questionCount) items.removeRange(widget.questionCount, items.length);
      }
      if (items.length > widget.questionCount) items.removeRange(widget.questionCount, items.length);
      items.shuffle();
      if (items.length < widget.questionCount && widget.templateId != null) {
        throw Exception(t('इस template के लिए पर्याप्त प्रकाशित प्रश्न नहीं हैं।','Not enough published questions for this mock-test template.'));
      }
      if (items.isEmpty) throw Exception(t('इस परीक्षा के लिए प्रकाशित प्रश्न उपलब्ध नहीं हैं।', 'No published questions are available for this exam.'));
      for (final q in items) {
        final opts = (q['question_options'] as List? ?? []).map((e) => Map<String,dynamic>.from(e as Map)).toList();
        opts.sort((a,b) => (a['display_order'] as int? ?? 0).compareTo(b['display_order'] as int? ?? 0));
        q['question_options'] = opts;
      }
      if (!mounted) return;
      setState(() { _questions = items; _loading = false; });
      _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
        if (!mounted || _submitted) { timer.cancel(); return; }
        if (_secondsLeft <= 1) { setState(() => _secondsLeft = 0); timer.cancel(); _submit(auto: true); }
        else { setState(() => _secondsLeft--); }
      });
    } catch (e) { if (mounted) setState(() { _error = e.toString(); _loading = false; }); }
  }

  String get _time {
    final m = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    final s = (_secondsLeft % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _submit({bool auto = false}) async {
    if (_submitting || _submitted || _questions.isEmpty) return;
    if (!auto) {
      final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
        title: Text(t('टेस्ट जमा करें?', 'Submit test?')),
        content: Text(t('आपने ${_answers.length}/${_questions.length} प्रश्नों के उत्तर दिए हैं। क्या आप टेस्ट जमा करना चाहते हैं?', 'You answered ${_answers.length}/${_questions.length} questions. Submit now?')),
        actions: [TextButton(onPressed: () => Navigator.pop(c,false), child: Text(t('वापस जाएँ','Continue'))), FilledButton(onPressed: () => Navigator.pop(c,true), child: Text(t('जमा करें','Submit')))],
      ));
      if (ok != true) return;
    }
    setState(() => _submitting = true);
    _timer?.cancel();
    try {
      final payload = _questions.map((q) => {'question_id': q['id'], 'option_id': _answers[q['id'].toString()] }).toList();
      final response = await _db.rpc('submit_test_attempt', params: {'p_exam_id': widget.examId, 'p_answers': payload, 'p_mode': 'mock'});
      if (!mounted) return;
      setState(() { _result = Map<String,dynamic>.from(response as Map); _submitted = true; _submitting = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _submitting = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: Text(t('मॉक टेस्ट','Mock Test'))), body: const Center(child: CircularProgressIndicator()));
    if (_error != null && _questions.isEmpty) return Scaffold(appBar: AppBar(title: Text(t('मॉक टेस्ट','Mock Test'))), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!))));
    if (_submitted) return _resultView();
    final q = _questions[_current];
    final opts = q['question_options'] as List;
    final qid = q['id'].toString();
    return Scaffold(
      appBar: AppBar(title: Text(t('फुल मॉक टेस्ट','Full Mock Test')), actions: [Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 17), child: Text(_time, style: TextStyle(fontWeight: FontWeight.bold, color: _secondsLeft < 300 ? Colors.yellow : Colors.white))) ]),
      body: Column(children: [
        LinearProgressIndicator(value: (_current + 1) / _questions.length),
        Padding(padding: const EdgeInsets.fromLTRB(16,12,16,4), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('${t('प्रश्न','Question')} ${_current+1}/${_questions.length}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${t('उत्तर दिए','Answered')}: ${_answers.length}') ])),
        Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
          Text(((_hi ? q['question_hi'] : q['question_en']) ?? q['question_en'] ?? q['question_hi'] ?? '').toString(), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
          const SizedBox(height: 18),
          ...opts.map((o) { final id = o['id'].toString(); final label = ((_hi ? o['text_hi'] : o['text_en']) ?? o['text_en'] ?? o['text_hi'] ?? '').toString(); return Card(child: RadioListTile<String>(value: id, groupValue: _answers[qid], onChanged: (v) => setState(() { if (v != null) _answers[qid] = v; }), title: Text('${o['option_key']}. $label'))); }),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () => setState(() { if (_marked.contains(_current)) _marked.remove(_current); else _marked.add(_current); }), icon: Icon(_marked.contains(_current) ? Icons.bookmark : Icons.bookmark_border), label: Text(t('बाद में देखने के लिए मार्क करें','Mark for review'))),
        ])),
        _palette(),
        SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: OutlinedButton(onPressed: _current > 0 ? () => setState(() => _current--) : null, child: Text(t('पिछला','Previous')))), const SizedBox(width: 8), Expanded(child: FilledButton(onPressed: _current < _questions.length-1 ? () => setState(() => _current++) : () => _submit(), child: Text(_current < _questions.length-1 ? t('अगला','Next') : t('जमा करें','Submit'))))]))),
      ]),
    );
  }

  Widget _palette() => Container(height: 76, padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: _questions.length, separatorBuilder: (_,__) => const SizedBox(width: 6), itemBuilder: (c,i) {
    final id = _questions[i]['id'].toString(); final answered = _answers.containsKey(id); final marked = _marked.contains(i);
    return InkWell(onTap: () => setState(() => _current = i), child: CircleAvatar(radius: 19, backgroundColor: i == _current ? Colors.blue : marked ? Colors.deepOrange : answered ? Colors.green : Colors.grey.shade300, child: Text('${i+1}', style: TextStyle(color: (i == _current || marked || answered) ? Colors.white : Colors.black)));
  }));

  Widget _resultView() {
    final r = _result ?? {};
    String val(String k) => (r[k] ?? 0).toString();
    return Scaffold(appBar: AppBar(title: Text(t('मॉक टेस्ट परिणाम','Mock Test Result'))), body: ListView(padding: const EdgeInsets.all(20), children: [
      Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [Text(t('आपका स्कोर','Your Score')), Text('${val('score')} / ${val('max_score')}', style: const TextStyle(fontSize: 34, fontWeight: FontWeight.bold)), Text('${t('कुल प्रश्न','Total')}: ${val('total_questions')}')]))),
      const SizedBox(height: 12),
      _stat(t('सही उत्तर','Correct'), val('correct_answers'), Colors.green), _stat(t('गलत उत्तर','Wrong'), val('wrong_answers'), Colors.red), _stat(t('छोड़े गए','Unanswered'), val('unanswered'), Colors.orange), _stat(t('प्रयास किए','Attempted'), val('attempted_questions'), Colors.blue),
      const SizedBox(height: 16), Text(t('आपका प्रयास सफलतापूर्वक सेव हो गया है।','Your attempt has been saved successfully.'), textAlign: TextAlign.center),
    ]));
  }
  Widget _stat(String label, String value, Color color) => Card(child: ListTile(title: Text(label), trailing: Text(value, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 20))));
}
