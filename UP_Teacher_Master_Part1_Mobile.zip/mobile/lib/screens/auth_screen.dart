import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../app_config.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final phone = TextEditingController();
  final otp = TextEditingController();
  bool otpSent = false;
  bool busy = false;
  String? error;

  Future<void> sendOtp() async {
    setState(() { busy = true; error = null; });
    try {
      await Supabase.instance.client.auth.signInWithOtp(
        phone: phone.text.trim(),
        channel: OtpChannel.sms,
      );
      setState(() => otpSent = true);
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (e) {
      setState(() => error = 'Unable to send OTP. Check your configuration and connection.');
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> verifyOtp() async {
    setState(() { busy = true; error = null; });
    try {
      await Supabase.instance.client.auth.verifyOTP(
        phone: phone.text.trim(),
        token: otp.text.trim(),
        type: OtpType.sms,
      );
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (_) {
      setState(() => error = 'OTP verification failed.');
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> googleLogin() async {
    setState(() { busy = true; error = null; });
    try {
      await Supabase.instance.client.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: AppConfig.authRedirectUrl,
      );
    } on AuthException catch (e) {
      setState(() => error = e.message);
    } catch (_) {
      setState(() => error = 'Google sign-in could not be started.');
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  void dispose() { phone.dispose(); otp.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Icon(Icons.school_rounded, size: 72, color: Color(0xFF174A7E)),
              const SizedBox(height: 12),
              const Text('UP TEACHER MASTER', textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 1)),
              const Text('एक लक्ष्य — शिक्षक बनने का संकल्प',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 36),
              Text(otpSent ? 'Verify your mobile number' : 'Welcome, Aspirant!',
                style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),
              if (!otpSent) ...[
                TextField(controller: phone, keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Mobile number with country code',
                    hintText: '+919876543210', border: OutlineInputBorder())),
                const SizedBox(height: 14),
                FilledButton(onPressed: busy ? null : sendOtp,
                  child: Text(busy ? 'Please wait…' : 'Send OTP')),
              ] else ...[
                Text('OTP sent to ${phone.text}', style: const TextStyle(color: Colors.black54)),
                const SizedBox(height: 12),
                TextField(controller: otp, keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: '6-digit OTP', border: OutlineInputBorder())),
                const SizedBox(height: 14),
                FilledButton(onPressed: busy ? null : verifyOtp,
                  child: Text(busy ? 'Verifying…' : 'Verify and Continue')),
                TextButton(onPressed: busy ? null : () => setState(() => otpSent = false),
                  child: const Text('Change mobile number')),
              ],
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: busy ? null : googleLogin,
                icon: const Icon(Icons.g_mobiledata, size: 30),
                label: const Text('Continue with Google'),
              ),
              if (error != null) ...[
                const SizedBox(height: 12),
                Text(error!, style: const TextStyle(color: Colors.red)),
              ],
              const SizedBox(height: 24),
              const Text('By continuing, you agree to our Terms and Privacy Policy.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
            ]),
          ),
        ),
      ),
    ),
  );
}
