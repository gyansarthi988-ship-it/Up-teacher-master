import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AiStudyMentorScreen extends StatefulWidget {
  final String language;
  const AiStudyMentorScreen({super.key, this.language = 'en'});
  @override
  State<AiStudyMentorScreen> createState() => _AiStudyMentorScreenState();
}

class _AiStudyMentorScreenState extends State<AiStudyMentorScreen> {
  final db = Supabase.instance.client;
  bool get hi => widget.language == 'hi';
  bool loading = true, saving = false;
  String? error;
  Map<String, dynamic> dashboard = {};
  List<Map<String, dynamic>> exams = [];
  String? examId;
  DateTime? targetDate;
  double minutes = 120;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final rows = await db.from('exams').select('id,code,name_hi,name_en').eq('is_active', true).order('name_en');
      exams = List<Map<String,dynamic>>.from(rows);
      final result = await db.rpc('get_my_mentor_dashboard');
      dashboard = Map<String,dynamic>.from(result as Map);
      if (dashboard['configured'] == true) {
        examId = dashboard['exam_id']?.toString();
        minutes = (dashboard['daily_minutes'] as num?)?.toDouble() ?? 120;
        final raw = dashboard['target_exam_date']?.toString();
        if (raw != null) targetDate = DateTime.tryParse(raw);
      }
    } catch (e) { error = e.toString(); }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _save() async {
    if (examId == null) { setState(() => error = hi ? 'पहले परीक्षा चुनें।' : 'Please choose an exam.'); return; }
    setState(() { saving = true; error = null; });
    try {
      await db.rpc('save_my_mentor_preferences', params: {
        'p_exam_id': examId,
        'p_target_exam_date': targetDate == null ? null : '${targetDate!.year.toString().padLeft(4,'0')}-${targetDate!.month.toString().padLeft(2,'0')}-${targetDate!.day.toString().padLeft(2,'0')}',
        'p_daily_minutes': minutes.round(),
        'p_preferred_language': hi ? 'hi' : 'en',
      });
      await _load();
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => saving = false); }
  }

  @override
  Widget build(BuildContext context) {
    final tasks = ((dashboard['learning_plan'] as Map?)?['tasks'] as List?) ?? [];
    final accuracy = dashboard['accuracy'];
    return Scaffold(
      appBar: AppBar(title: Text(hi ? 'AI Personal Study Mentor' : 'AI Personal Study Mentor')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(color: const Color(0xFFEAF2FF), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(hi ? 'आपका व्यक्तिगत तैयारी मार्गदर्शक' : 'Your personal preparation coach', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6), Text(hi ? 'आपके mock test और practice परिणामों के आधार पर पढ़ाई की प्राथमिकताएँ सुझाई जाएँगी।' : 'Study priorities are suggested from your mock-test and practice results.'),
          ]))),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
          if (dashboard['configured'] != true) ...[
            const SizedBox(height: 12), Text(hi ? 'अपना लक्ष्य सेट करें' : 'Set your preparation goal', style: Theme.of(context).textTheme.titleLarge),
            DropdownButtonFormField<String>(value: examId, decoration: InputDecoration(labelText: hi ? 'लक्ष्य परीक्षा' : 'Target examination'), items: exams.map((e) => DropdownMenuItem(value: e['id'].toString(), child: Text((hi ? e['name_hi'] : e['name_en'])?.toString() ?? e['code'].toString()))).toList(), onChanged: (v) => setState(() => examId = v)),
            const SizedBox(height: 12),
            OutlinedButton.icon(onPressed: () async { final d = await showDatePicker(context: context, initialDate: targetDate ?? DateTime.now().add(const Duration(days: 90)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 1500))); if (d != null) setState(() => targetDate = d); }, icon: const Icon(Icons.event), label: Text(targetDate == null ? (hi ? 'परीक्षा की तारीख चुनें (वैकल्पिक)' : 'Choose exam date (optional)') : '${targetDate!.day}/${targetDate!.month}/${targetDate!.year}')),
            Text('${hi ? 'रोज़ाना पढ़ाई' : 'Daily study time'}: ${minutes.round()} ${hi ? 'मिनट' : 'minutes'}'),
            Slider(value: minutes, min: 15, max: 600, divisions: 39, onChanged: (v) => setState(() => minutes = v)),
            FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.flag), label: Text(saving ? '...' : (hi ? 'मेरा लक्ष्य सेव करें' : 'Save my goal'))),
          ] else ...[
            const SizedBox(height: 12), Card(child: ListTile(leading: const Icon(Icons.school), title: Text(dashboard['exam_name']?.toString() ?? ''), subtitle: Text('${dashboard['daily_minutes']} ${hi ? 'मिनट प्रतिदिन' : 'minutes per day'}'), trailing: IconButton(icon: const Icon(Icons.edit), onPressed: () => setState(() => dashboard['configured'] = false)))),
            Row(children: [Expanded(child: _stat(hi ? 'हल किए' : 'Attempted', '${dashboard['attempted'] ?? 0}')), const SizedBox(width: 8), Expanded(child: _stat(hi ? 'सही' : 'Correct', '${dashboard['correct'] ?? 0}')), const SizedBox(width: 8), Expanded(child: _stat(hi ? 'सटीकता' : 'Accuracy', accuracy == null ? '—' : '$accuracy%'))]),
            const SizedBox(height: 16), Text(hi ? 'आपका 7-दिन का अध्ययन प्लान' : 'Your 7-day study plan', style: Theme.of(context).textTheme.titleLarge),
            if (tasks.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(hi ? 'अभी पर्याप्त practice data नहीं है। पहले कुछ practice या mock tests पूरे करें।' : 'Not enough practice data yet. Complete some practice or mock tests first.')),
            ...tasks.map((t) { final item = Map<String,dynamic>.from(t as Map); return Card(child: ListTile(leading: Icon(item['status']=='completed' ? Icons.check_circle : Icons.menu_book, color: item['status']=='completed' ? Colors.green : null), title: Text((hi ? item['title_hi'] : item['title_en'])?.toString() ?? ''), subtitle: Text('${item['scheduled_for']} · ${item['target_questions']} ${hi ? 'प्रश्न' : 'questions'} · ${item['status']}')); }),
            const SizedBox(height: 10), OutlinedButton.icon(onPressed: () async { try { await db.rpc('generate_my_learning_plan', params: {'p_exam_id': examId}); await _load(); } catch (e) { setState(() => error = e.toString()); } }, icon: const Icon(Icons.refresh), label: Text(hi ? 'मेरी योजना अपडेट करें' : 'Refresh my plan')),
            const SizedBox(height: 8), Text(hi ? 'सुझाव उपलब्ध practice data पर आधारित हैं; यह परीक्षा में सफलता की गारंटी नहीं है।' : 'Recommendations are based on available practice data and do not guarantee exam results.', style: Theme.of(context).textTheme.bodySmall),
          ],
        ]),
      ),
    );
  }

  Widget _stat(String label, String value) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)), Text(label, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall)])));
}
