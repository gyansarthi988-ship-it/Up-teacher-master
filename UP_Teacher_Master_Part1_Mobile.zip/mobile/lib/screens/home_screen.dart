import '../notification_service.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'exam_content_screen.dart';
import 'performance_analytics_screen.dart';
import 'smart_learning_screen.dart';
import 'premium_membership_screen.dart';
import 'study_material_library_screen.dart';
import 'profile_screen.dart';
import 'notifications_screen.dart';
import 'doubt_assistant_screen.dart';
import 'ai_study_mentor_screen.dart';
import 'spaced_revision_screen.dart';
import 'daily_command_center_screen.dart';
import 'exam_readiness_screen.dart';
import 'syllabus_tracker_screen.dart';
import 'weak_topic_diagnosis_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String language = 'English';
  final exams = const [
    ('SUPER_TET', 'UP Super TET', 'Teacher recruitment preparation', Icons.school),
    ('TGT', 'UP TGT', 'Trained Graduate Teacher', Icons.menu_book),
    ('PRT', 'UP PRT', 'Primary Teacher', Icons.child_care),
    ('JUNIOR', 'UP Junior Level', 'Junior level preparation', Icons.class_),
  ];

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    final isHindi = language == 'हिन्दी';
    return Scaffold(
      appBar: AppBar(
        title: const Text('UP Teacher Master'),
        actions: [
          PopupMenuButton<String>(
            initialValue: language,
            onSelected: (v) => setState(() => language = v),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'English', child: Text('English')),
              PopupMenuItem(value: 'हिन्दी', child: Text('हिन्दी')),
            ],
            child: const Padding(padding: EdgeInsets.symmetric(horizontal: 12),
              child: Row(children: [Icon(Icons.language), SizedBox(width: 4), Text('Language')])),
          ),
        ],
      ),
      drawer: Drawer(child: SafeArea(child: Column(children: [
        const ListTile(leading: Icon(Icons.school), title: Text('UP Teacher Master'),
          subtitle: Text('Student menu')),
        const Divider(),
        ListTile(leading: const Icon(Icons.checklist), title: Text(isHindi ? 'सिलेबस ट्रैकर' : 'Syllabus Tracker'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => SyllabusTrackerScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.troubleshoot), title: Text(isHindi ? 'कमजोर टॉपिक डायग्नोसिस' : 'Weak Topic Diagnosis'),
          subtitle: Text(isHindi ? 'कमजोरी और सुधार के अगले कदम' : 'Identify gaps and get action steps'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => WeakTopicDiagnosisScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.speed), title: Text(isHindi ? 'Exam Readiness Score' : 'परीक्षा तैयारी स्तर'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => ExamReadinessScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.dashboard), title: Text(isHindi ? 'आज की तैयारी' : 'Daily Study Dashboard'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => DailyCommandCenterScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.notifications_active), title: Text(isHindi ? 'सूचनाएँ और अपडेट' : 'Notifications & Updates'), onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => NotificationsScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.person), title: Text(isHindi ? 'मेरी प्रोफाइल' : 'My Profile'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => ProfileScreen(language: isHindi ? 'hi' : 'en'))); }),
        const ListTile(leading: Icon(Icons.bookmark), title: Text('Bookmarks')),
        ListTile(leading: const Icon(Icons.insights), title: const Text('My Performance'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => PerformanceAnalyticsScreen(language: language == 'हिन्दी' ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.auto_awesome), title: Text(isHindi ? 'स्मार्ट स्टडी प्लान' : 'Smart Study Plan'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => SmartLearningScreen(language: language == 'हिन्दी' ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.psychology), title: Text(isHindi ? 'AI पर्सनल स्टडी मेंटर' : 'AI Personal Study Mentor'),
          onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => AiStudyMentorScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.replay_circle_filled), title: Text(isHindi ? 'स्मार्ट रिवीजन' : 'Spaced Revision'), onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => SpacedRevisionScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.workspace_premium), title: Text(isHindi ? 'प्रीमियम सदस्यता' : 'Premium Membership'), onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => PremiumMembershipScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.picture_as_pdf), title: Text(isHindi ? 'स्टडी मटेरियल' : 'Study Materials'), onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => StudyMaterialLibraryScreen(language: isHindi ? 'hi' : 'en'))); }),
        ListTile(leading: const Icon(Icons.psychology_alt), title: Text(isHindi ? 'AI से सवाल पूछें' : 'AI Doubt Solver'), onTap: () { Navigator.of(context).pop(); Navigator.of(context).push(MaterialPageRoute(builder: (_) => DoubtAssistantScreen(language: isHindi ? 'hi' : 'en'))); }),
        const Spacer(),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'),
          onTap: () async { await NotificationService.instance.unregisterCurrentDevice(); await Supabase.instance.client.auth.signOut(); }),
      ]))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: const Color(0xFF174A7E),
            borderRadius: BorderRadius.circular(18)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(isHindi ? 'नमस्ते, अभ्यर्थी!' : 'Namaste, Aspirant!',
              style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            Text(user?.phone ?? user?.email ?? 'Welcome',
              style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(isHindi ? 'अपनी शिक्षक भर्ती परीक्षा चुनें' : 'Choose your teacher recruitment exam',
              style: const TextStyle(color: Colors.white, fontSize: 17)),
          ]),
        ),
        const SizedBox(height: 16),
        Card(
          child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.dashboard_customize)),
            title: Text(isHindi ? 'आज की तैयारी – Study Dashboard' : 'Daily Study Command Centre'),
            subtitle: Text(isHindi ? 'लक्ष्य, प्रगति, रिवीजन और कमजोर टॉपिक्स' : 'Goals, progress, revision and weak topics'),
            trailing: const Icon(Icons.arrow_forward),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => DailyCommandCenterScreen(language: isHindi ? 'hi' : 'en'))),
          ),
        ),
        const SizedBox(height: 22),
        Text(isHindi ? 'अपनी परीक्षा चुनें' : 'Choose Your Examination',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...exams.map((e) => Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: const Color(0xFFE7EFF8),
              child: Icon(e.$4, color: const Color(0xFF174A7E))),
            title: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(e.$3),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () async {
              try {
                final exam = await Supabase.instance.client.from('exams')
                    .select('id,name_en').eq('code', e.$1).maybeSingle();
                if (!mounted) return;
                if (exam == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('This examination is not configured yet.')));
                  return;
                }
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => ExamContentScreen(
                    examId: exam['id'] as String,
                    examName: exam['name_en'] as String,
                  ),
                ));
              } catch (_) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Could not load examination. Please try again.')));
              }
            },
          ),
        )),
        const SizedBox(height: 18),
        Text(isHindi ? 'आपकी तैयारी' : 'Your preparation',
          style: Theme.of(context).textTheme.titleMedium),
        const Wrap(spacing: 8, runSpacing: 8, children: [
          _FeatureChip(icon: Icons.quiz, label: 'Practice MCQs'),
          _FeatureChip(icon: Icons.timer, label: 'Mock Tests'),
          _FeatureChip(icon: Icons.picture_as_pdf, label: 'Study Notes'),
          _FeatureChip(icon: Icons.analytics, label: 'Performance Analytics'),
        ]),
      ]),
    );
  }
}

class _FeatureChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _FeatureChip({required this.icon, required this.label});
  @override
  Widget build(BuildContext context) => Chip(avatar: Icon(icon, size: 18),
    label: Text(label), backgroundColor: Colors.white);
}
