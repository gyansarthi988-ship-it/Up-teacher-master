import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Personal performance dashboard. Data is returned by a user-scoped RPC;
/// the client never reads another student's attempts.
class PerformanceAnalyticsScreen extends StatefulWidget {
  final String? examId;
  final String language;
  const PerformanceAnalyticsScreen({super.key, this.examId, this.language = 'hi'});
  @override
  State<PerformanceAnalyticsScreen> createState() => _PerformanceAnalyticsScreenState();
}

class _PerformanceAnalyticsScreenState extends State<PerformanceAnalyticsScreen> {
  bool _loading = true;
  String? _error;
  Map<String, dynamic> _data = {};
  bool get _hi => widget.language == 'hi';
  String t(String hi, String en) => _hi ? hi : en;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final result = await Supabase.instance.client.rpc(
        'get_my_performance_analytics',
        params: {'p_exam_id': widget.examId},
      );
      if (!mounted) return;
      setState(() { _data = Map<String, dynamic>.from(result as Map); _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Map<String, dynamic> get _summary => Map<String, dynamic>.from(_data['summary'] as Map? ?? {});
  List<Map<String, dynamic>> _list(String key) => (_data[key] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  String _n(dynamic v, {int decimals = 0}) {
    final x = num.tryParse('$v') ?? 0;
    return decimals == 0 ? x.toStringAsFixed(0) : x.toStringAsFixed(decimals);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: Text(t('मेरी प्रगति','My Performance'))), body: const Center(child: CircularProgressIndicator()));
    if (_error != null) return Scaffold(appBar: AppBar(title: Text(t('मेरी प्रगति','My Performance'))), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!))));
    final s = _summary;
    final subjects = _list('subjects');
    final topics = _list('topics');
    final trend = _list('trend');
    return Scaffold(
      appBar: AppBar(title: Text(t('मेरी प्रगति','My Performance')), actions: [IconButton(onPressed: () { setState(() => _loading = true); _load(); }, icon: const Icon(Icons.refresh))]),
      body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.all(16), children: [
        if ((s['attempts'] as num? ?? 0) == 0) ...[
          const SizedBox(height: 70), const Icon(Icons.insights, size: 64, color: Colors.blueGrey),
          const SizedBox(height: 12), Text(t('अभी कोई submitted test उपलब्ध नहीं है। पहले Practice या Mock Test पूरा करें।','No submitted tests yet. Complete a Practice or Mock Test first.'), textAlign: TextAlign.center),
        ] else ...[
          _hero(_n(s['average_percentage'], decimals: 1), t('औसत प्रतिशत','Average percentage')),
          const SizedBox(height: 12),
          GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.8, crossAxisSpacing: 10, mainAxisSpacing: 10, children: [
            _metric(t('कुल टेस्ट','Tests'), _n(s['attempts']), Icons.assignment_turned_in),
            _metric(t('Accuracy','Accuracy'), '${_n(s['accuracy'], decimals: 1)}%', Icons.track_changes),
            _metric(t('सही उत्तर','Correct'), _n(s['correct']), Icons.check_circle_outline),
            _metric(t('गलत उत्तर','Wrong'), _n(s['wrong']), Icons.cancel_outlined),
            _metric(t('प्रयास किए','Attempted'), _n(s['attempted']), Icons.edit_note),
            _metric(t('छोड़े गए','Unanswered'), _n(s['unanswered']), Icons.remove_circle_outline),
          ]),
          const SizedBox(height: 22), _heading(t('विषय के अनुसार प्रदर्शन','Subject-wise performance')),
          if (subjects.isEmpty) _empty(t('विषयवार डेटा अभी उपलब्ध नहीं है।','Subject data is not available yet.')),
          ...subjects.map(_subjectTile),
          const SizedBox(height: 18), _heading(t('कमजोर टॉपिक्स – सुधार की जरूरत','Weak topics – need improvement')),
          ...topics.where((x) => x['weak'] == true).map(_topicTile),
          if (topics.every((x) => x['weak'] != true)) _empty(t('अभी कोई कमजोर topic चिन्हित नहीं हुआ। कम से कम 3 attempts के बाद सुझाव दिखेंगे।','No weak topics identified yet. Suggestions appear after at least 3 attempts per topic.')),
          const SizedBox(height: 18), _heading(t('हाल के टेस्ट','Recent tests')),
          ...trend.reversed.map(_trendTile),
        ],
      ])),
    );
  }

  Widget _hero(String value, String label) => Card(color: Theme.of(context).colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [Text(value, style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold)), Text(label)])));
  Widget _metric(String label, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 9), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(label, maxLines: 1, overflow: TextOverflow.ellipsis)]))])));
  Widget _heading(String text) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)));
  Widget _empty(String text) => Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(text, style: const TextStyle(color: Colors.black54)));
  Widget _subjectTile(Map<String, dynamic> x) {
    final accuracy = num.tryParse('${x['accuracy']}') ?? 0;
    return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text((_hi ? x['name_hi'] : x['name_en'])?.toString() ?? x['name_en']?.toString() ?? '—', style: const TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 8), LinearProgressIndicator(value: (accuracy / 100).clamp(0, 1)), const SizedBox(height: 5), Text('${accuracy.toStringAsFixed(1)}%  •  ${_n(x['correct'])}/${_n(x['attempted'])} ${t('सही','correct')}')])));
  }
  Widget _topicTile(Map<String, dynamic> x) => Card(child: ListTile(leading: const Icon(Icons.priority_high, color: Colors.deepOrange), title: Text((_hi ? x['name_hi'] : x['name_en'])?.toString() ?? '—'), subtitle: Text('${_n(x['accuracy'], decimals: 1)}% ${t('सटीकता','accuracy')} • ${_n(x['attempted'])} ${t('प्रयास','attempts')}')));
  Widget _trendTile(Map<String, dynamic> x) => Card(child: ListTile(leading: const Icon(Icons.history), title: Text('${_n(x['percentage'], decimals: 1)}%  •  ${_n(x['score'], decimals: 1)}/${_n(x['max_score'], decimals: 1)}'), subtitle: Text('${x['mode'] == 'mock' ? t('मॉक टेस्ट','Mock test') : t('प्रैक्टिस','Practice')} • ${x['submitted_at'] ?? ''}')));
}
