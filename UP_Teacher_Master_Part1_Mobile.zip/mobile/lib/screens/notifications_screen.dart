import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotificationsScreen extends StatefulWidget {
  final String language;
  const NotificationsScreen({super.key, this.language = 'en'});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> notices = [];
  Set<String> readIds = {};
  bool get hi => widget.language == 'hi';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final client = Supabase.instance.client;
      final uid = client.auth.currentUser?.id;
      if (uid == null) throw Exception(hi ? 'कृपया पहले लॉगिन करें।' : 'Please sign in first.');
      final rows = await client.from('announcements').select('id,title_en,title_hi,body_en,body_hi,category,publish_at,created_at,target_exam_id').eq('is_published', true).order('publish_at', ascending: false).limit(100);
      final reads = await client.from('announcement_reads').select('announcement_id').eq('user_id', uid);
      if (!mounted) return;
      setState(() { notices = List<Map<String,dynamic>>.from(rows); readIds = (reads as List).map((r) => r['announcement_id'] as String).toSet(); loading = false; });
    } catch (e) { if (mounted) setState(() { error = e.toString(); loading = false; }); }
  }

  Future<void> _markRead(String id) async {
    if (readIds.contains(id)) return;
    try {
      await Supabase.instance.client.from('announcement_reads').insert({'announcement_id': id, 'user_id': Supabase.instance.client.auth.currentUser!.id});
      if (mounted) setState(() => readIds.add(id));
    } catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(hi ? 'Read status save नहीं हुआ।' : 'Could not save read status.'))); }
  }

  String _title(Map<String,dynamic> n) => (hi && (n['title_hi'] as String?)?.isNotEmpty == true) ? n['title_hi'] as String : n['title_en'] as String;
  String _body(Map<String,dynamic> n) => (hi && (n['body_hi'] as String?)?.isNotEmpty == true) ? n['body_hi'] as String : n['body_en'] as String;
  String _category(String value) => switch(value) { 'exam_update' => hi ? 'परीक्षा अपडेट' : 'Exam Update', 'important' => hi ? 'महत्वपूर्ण' : 'Important', 'maintenance' => hi ? 'मेंटेनेंस' : 'Maintenance', _ => hi ? 'सामान्य' : 'General' };

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(hi ? 'सूचनाएँ और अपडेट' : 'Notifications & Updates'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
    body: loading ? const Center(child: CircularProgressIndicator()) : error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center))) : notices.isEmpty ? Center(child: Text(hi ? 'अभी कोई नई सूचना नहीं है।' : 'No announcements yet.')) : RefreshIndicator(onRefresh: _load, child: ListView.builder(padding: const EdgeInsets.all(12), itemCount: notices.length, itemBuilder: (context,index) {
      final n = notices[index]; final id = n['id'] as String; final isRead = readIds.contains(id);
      return Card(child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => _markRead(id), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Container(padding: const EdgeInsets.symmetric(horizontal: 9,vertical: 5), decoration: BoxDecoration(color: const Color(0xFFE7EFF8),borderRadius: BorderRadius.circular(20)), child: Text(_category(n['category'] as String),style: const TextStyle(fontSize: 12,fontWeight: FontWeight.w600))), const Spacer(), if (!isRead) const Icon(Icons.circle,size: 10,color: Color(0xFF174A7E)), if (isRead) Text(hi?'पढ़ लिया':'Read',style: const TextStyle(fontSize: 12,color: Colors.grey))]),
        const SizedBox(height: 10), Text(_title(n),style: TextStyle(fontSize: 17,fontWeight: isRead?FontWeight.w500:FontWeight.bold)), const SizedBox(height: 7), Text(_body(n)), const SizedBox(height: 8), Text((n['publish_at'] ?? n['created_at']).toString().substring(0,10),style: const TextStyle(color: Colors.grey,fontSize: 12))
      ]))));
    })),
  );
}
