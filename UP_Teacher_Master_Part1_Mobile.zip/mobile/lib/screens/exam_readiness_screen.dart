import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ExamReadinessScreen extends StatefulWidget {
  final String language;
  const ExamReadinessScreen({super.key, this.language = 'hi'});
  @override
  State<ExamReadinessScreen> createState() => _ExamReadinessScreenState();
}

class _ExamReadinessScreenState extends State<ExamReadinessScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic> data = {};
  bool get hi => widget.language == 'hi';
  String t(String h, String e) => hi ? h : e;
  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await Supabase.instance.client.rpc('get_my_performance_analytics');
      data = Map<String, dynamic>.from(result as Map);
    } catch (_) {
      error = t('प्रदर्शन डेटा अभी उपलब्ध नहीं है।','Performance data is not available yet.');
    }
    if (mounted) setState(() => loading = false);
  }

  Map<String, dynamic> get summary => Map<String, dynamic>.from(data['summary'] as Map? ?? {});
  List<Map<String, dynamic>> list(String k) =>
      (data[k] as List? ?? []).map((x) => Map<String,dynamic>.from(x as Map)).toList();
  double val(dynamic x) => (num.tryParse('$x') ?? 0).toDouble();
  int n(dynamic x) => val(x).round();

  @override
  Widget build(BuildContext context) {
    final attempts = n(summary['attempts']);
    final avg = val(summary['average_percentage']);
    final accuracy = val(summary['accuracy']);
    final topics = list('topics');
    final subjects = list('subjects');
    final weak = topics.where((x) => x['weak'] == true).length;
    final readiness = attempts == 0 ? 0.0 : (avg * .55 + accuracy * .30 + (topics.length >= 8 ? 100 : topics.length / 8 * 100) * .15 - weak * 2).clamp(0,100).toDouble();
    final label = attempts == 0 ? t('डेटा चाहिए','More data needed')
      : readiness >= 80 ? t('अच्छी तैयारी','Strong preparation')
      : readiness >= 60 ? t('सुधार के साथ तैयार','Promising – keep improving')
      : readiness >= 40 ? t('अभी और अभ्यास करें','More practice needed')
      : t('बुनियाद मजबूत करें','Strengthen fundamentals');
    return Scaffold(
      appBar: AppBar(title: Text(t('Exam Readiness','परीक्षा तैयारी स्तर')),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      body: loading ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(16), children: [
          if (error != null) Text(error!, style: const TextStyle(color: Colors.deepOrange)),
          Card(color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
              Text(t('आपका अनुमानित Exam Readiness Score','YOUR ESTIMATED EXAM READINESS SCORE'),
                textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(width: 150, height: 150, child: Stack(fit: StackFit.expand, children: [
                CircularProgressIndicator(value: readiness/100, strokeWidth: 12),
                Center(child: Text(attempts == 0 ? '—' : readiness.toStringAsFixed(0),
                  style: const TextStyle(fontSize: 42, fontWeight: FontWeight.bold))),
              ])),
              const SizedBox(height: 10),
              Text(label, style: Theme.of(context).textTheme.titleLarge),
              Text(t('यह अभ्यास डेटा पर आधारित अनुमान है, चयन या वास्तविक परीक्षा परिणाम की गारंटी नहीं।',
                'This is an estimate from practice data, not a guarantee of selection or actual exam results.'),
                textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
            ]))),
          const SizedBox(height: 16),
          Text(t('Readiness के मुख्य संकेतक','READINESS INDICATORS'),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _indicator(t('औसत स्कोर','Average score'), avg, '${avg.toStringAsFixed(1)}%'),
          _indicator(t('Accuracy','Accuracy'), accuracy, '${accuracy.toStringAsFixed(1)}%'),
          _indicator(t('Practice किए topics','Topics practised'), (topics.length/8*100).clamp(0,100).toDouble(),
            '${topics.length} ${t('टॉपिक्स','topics')}'),
          const SizedBox(height: 16),
          Text(t('कमजोर विषय / टॉपिक्स','WEAK AREAS'),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          if (attempts == 0) _empty(t('पहले Practice या Mock Test पूरा करें।','Complete a Practice or Mock Test to generate your report.')),
          if (weak == 0 && attempts > 0) _empty(t('अभी कोई weak topic चिन्हित नहीं हुआ।','No weak topic has been flagged yet.')),
          ...topics.where((x) => x['weak'] == true).take(8).map((x) => Card(child: ListTile(
            leading: const Icon(Icons.warning_amber, color: Colors.deepOrange),
            title: Text((hi ? x['name_hi'] : x['name_en'])?.toString() ?? '—'),
            subtitle: Text('${val(x['accuracy']).toStringAsFixed(1)}% • ${n(x['attempted'])} ${t('प्रयास','attempts')}')))),
          const SizedBox(height: 16),
          Text(t('विषयवार तैयारी','SUBJECT READINESS'),
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          ...subjects.map((x) {
            final a = val(x['accuracy']);
            return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text((hi ? x['name_hi'] : x['name_en'])?.toString() ?? '—',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                LinearProgressIndicator(value: (a/100).clamp(0,1)),
                const SizedBox(height: 4), Text('${a.toStringAsFixed(1)}% ${t('सटीकता','accuracy')}'),
              ])));
          }),
          const SizedBox(height: 12),
          _empty(t('सुझाव: कमजोर टॉपिक्स की revision करें, फिर timed mock test दें।',
            'Tip: Revise weak topics, then attempt a timed mock test.')),
        ])),
    );
  }

  Widget _indicator(String title, double v, String trailing) => Card(child: Padding(
    padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Expanded(child: Text(title)), Text(trailing, style: const TextStyle(fontWeight: FontWeight.bold))]),
      const SizedBox(height: 8), LinearProgressIndicator(value: (v/100).clamp(0,1)),
    ])));
  Widget _empty(String s) => Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(s));
}
