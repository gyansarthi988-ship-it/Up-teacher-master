import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'practice_screen.dart';

/// Personalised study plan and wrong-question notebook for the signed-in learner.
class SmartLearningScreen extends StatefulWidget {
  final String language;
  const SmartLearningScreen({super.key, this.language = 'hi'});
  @override
  State<SmartLearningScreen> createState() => _SmartLearningScreenState();
}

class _SmartLearningScreenState extends State<SmartLearningScreen> {
  final _db = Supabase.instance.client;
  bool _loading = true;
  bool _generating = false;
  String? _error;
  String? _examId;
  List<Map<String, dynamic>> _exams = [];
  List<Map<String, dynamic>> _tasks = [];
  List<Map<String, dynamic>> _wrong = [];
  bool get _hi => widget.language == 'hi';
  String t(String hi, String en) => _hi ? hi : en;

  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    try {
      final rows = await _db.from('exams').select('id,code,name_en,name_hi').order('name_en');
      _exams = List<Map<String, dynamic>>.from(rows);
      if (_exams.isNotEmpty) {
        _examId = _exams.firstWhere((e) => e['code'] == 'SUPER_TET', orElse: () => _exams.first)['id'] as String;
        await _loadPlan();
      }
    } catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadPlan() async {
    if (_examId == null) return;
    final data = await _db.rpc('get_my_learning_plan', params: {'p_exam_id': _examId});
    final map = Map<String, dynamic>.from(data as Map);
    _tasks = (map['tasks'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    _wrong = (map['wrong_questions'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<void> _generate() async {
    if (_examId == null) return;
    setState(() { _generating = true; _error = null; });
    try {
      final data = await _db.rpc('generate_my_learning_plan', params: {'p_exam_id': _examId});
      final map = Map<String, dynamic>.from(data as Map);
      _tasks = (map['tasks'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
      _wrong = (map['wrong_questions'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (e) { _error = e.toString(); }
    if (mounted) setState(() => _generating = false);
  }

  Future<void> _refresh() async {
    try { await _loadPlan(); if (mounted) setState(() => _error = null); }
    catch (e) { if (mounted) setState(() => _error = e.toString()); }
  }

  Future<void> _setTask(Map<String, dynamic> task, String status) async {
    await _db.from('learning_plan_tasks').update({
      'status': status, 'completed_at': status == 'completed' ? DateTime.now().toUtc().toIso8601String() : null,
    }).eq('id', task['id']);
    await _refresh();
  }

  Future<void> _master(Map<String, dynamic> item, bool mastered) async {
    await _db.from('wrong_question_bookmarks').update({'mastered': mastered,
      'next_review_at': DateTime.now().add(const Duration(days: 3)).toIso8601String().substring(0, 10)}).eq('id', item['id']);
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: Text(t('स्मार्ट स्टडी प्लान','Smart Study Plan'))), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(t('स्मार्ट स्टडी प्लान','Smart Study Plan')), actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh))]),
      body: RefreshIndicator(onRefresh: _refresh, child: ListView(padding: const EdgeInsets.all(16), children: [
        if (_exams.isNotEmpty) DropdownButtonFormField<String>(value: _examId, decoration: InputDecoration(labelText: t('परीक्षा चुनें','Select examination'), border: const OutlineInputBorder()), items: _exams.map((e) => DropdownMenuItem(value: e['id'] as String, child: Text((_hi ? e['name_hi'] : e['name_en'])?.toString() ?? e['name_en'].toString()))).toList(), onChanged: (v) async { setState(() { _examId = v; _loading = true; }); try { await _loadPlan(); } catch (e) { _error = e.toString(); } if (mounted) setState(() => _loading = false); }),
        const SizedBox(height: 14),
        Card(color: Theme.of(context).colorScheme.primaryContainer, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t('आपकी कमजोरियों के आधार पर 7 दिन का प्लान','A 7-day plan based on your weak topics'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(t('आपके submitted tests से कमजोर topics चुने जाएंगे। Revision दिन 1, 3 और 7 पर रखा जाएगा।','Weak topics are selected from your submitted tests, with revision on days 1, 3 and 7.')), const SizedBox(height: 12), FilledButton.icon(onPressed: _generating ? null : _generate, icon: _generating ? const SizedBox(width: 16,height: 16,child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome), label: Text(t('मेरा प्लान बनाएं / अपडेट करें','Generate / Update My Plan')))]))),
        if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 12), _section(t('आज और अगले 7 दिन','Today & Next 7 Days')),
        if (_tasks.isEmpty) _empty(t('अभी प्लान नहीं है। पहले Practice/Mock Test दें, फिर प्लान बनाएं।','No plan yet. Complete Practice/Mock Tests, then generate your plan.')),
        ..._tasks.map(_taskCard),
        const SizedBox(height: 18), _section(t('गलत प्रश्नों की कॉपी','Wrong Question Notebook')),
        if (_wrong.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Wrap(spacing: 8, runSpacing: 8, children: [FilledButton.icon(onPressed: _practiceWrong, icon: const Icon(Icons.replay), label: Text(t('सभी गलत प्रश्न Practice करें','Practise All Wrong Questions'))), OutlinedButton.icon(onPressed: _practiceDueWrong, icon: const Icon(Icons.event_available), label: Text(t('Due Revision','आज का Revision')))])),
        if (_wrong.isEmpty) _empty(t('अभी कोई गलत प्रश्न रिकॉर्ड नहीं हुआ।','No wrong answers recorded yet.')),
        ..._wrong.map(_wrongCard),
      ])),
    );
  }

  Widget _section(String s) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(s, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)));
  Widget _empty(String s) => Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Text(s, style: const TextStyle(color: Colors.black54)));
  void _openTopicPractice(Map<String, dynamic> task) {
    final topicId = task['topic_id']?.toString();
    if (topicId == null || _examId == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t('इस task के लिए topic उपलब्ध नहीं है।','Topic is unavailable for this task.'))));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PracticeScreen(examId: _examId!, topicId: topicId, topicName: (_hi ? task['title_hi'] : task['title_en'])?.toString() ?? t('Topic Practice','Topic Practice'), onSubmitted: () => _setTask(task, 'completed')))).then((_) => _refresh());
  }

  Future<void> _practiceDueWrong() async {
    if (_examId == null) return;
    try {
      final data = await _db.rpc('get_my_due_wrong_question_ids', params: {'p_exam_id': _examId});
      final map = Map<String, dynamic>.from(data as Map);
      final ids = (map['question_ids'] as List? ?? []).map((e) => e.toString()).toList();
      if (!mounted) return;
      if (ids.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t('आज कोई revision due नहीं है।','No revision is due today.'))));
        return;
      }
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => PracticeScreen(examId: _examId!, topicId: '', topicName: t('Due Revision Practice','आज का Revision'), questionIds: ids))).then((_) => _refresh());
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Revision could not load: $e')));
    }
  }

  void _practiceWrong() {
    if (_examId == null || _wrong.isEmpty) return;
    final ids = _wrong.where((x) => x['mastered'] != true).map((x) => x['question_id'].toString()).toList();
    if (ids.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t('सभी प्रश्न mastered हैं।','All questions are marked mastered.'))));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PracticeScreen(examId: _examId!, topicId: '', topicName: t('Wrong Question Practice','गलत प्रश्नों की Practice'), questionIds: ids))).then((_) => _refresh());
  }

  Widget _taskCard(Map<String, dynamic> x) {
    final done = x['status'] == 'completed';
    final date = DateTime.tryParse('${x['scheduled_for']}');
    final title = (_hi ? x['title_hi'] : x['title_en'])?.toString() ?? x['title_en'].toString();
    return Card(child: ListTile(onTap: () => _openTopicPractice(x), leading: Icon(done ? Icons.check_circle : (x['task_type'] == 'study_topic' ? Icons.menu_book : Icons.replay), color: done ? Colors.green : Theme.of(context).colorScheme.primary), title: Text(title, style: TextStyle(decoration: done ? TextDecoration.lineThrough : null)), subtitle: Text('${date == null ? '' : '${date.day}/${date.month}'} • ${x['target_questions']} ${t('प्रश्न','questions')} • ${x['task_type']}\n${t('Practice खोलने के लिए tap करें','Tap to start practice')}'), isThreeLine: true, trailing: done ? const Icon(Icons.done) : IconButton(tooltip: t('पूरा करें','Mark complete'), icon: const Icon(Icons.task_alt), onPressed: () => _setTask(x, 'completed'))));
  }
  Widget _wrongCard(Map<String, dynamic> x) {
    final mastered = x['mastered'] == true;
    final question = (_hi ? x['question_hi'] : x['question_en'])?.toString() ?? x['question_en']?.toString() ?? '—';
    final explanation = (_hi ? x['explanation_hi'] : x['explanation_en'])?.toString();
    return Card(child: ExpansionTile(leading: Icon(mastered ? Icons.verified : Icons.error_outline, color: mastered ? Colors.green : Colors.deepOrange), title: Text(question, maxLines: 3, overflow: TextOverflow.ellipsis), subtitle: Text('${t('गलतियां','Wrong attempts')}: ${x['wrong_count']} • ${t('अगली समीक्षा','Review')}: ${x['next_review_at']}'), children: [if ((explanation ?? '').isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 12), child: Align(alignment: Alignment.centerLeft, child: Text(explanation!))), Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 12), child: Row(children: [TextButton.icon(onPressed: () => _master(x, !mastered), icon: Icon(mastered ? Icons.refresh : Icons.verified), label: Text(mastered ? t('फिर से दोहराएं','Revise again') : t('मुझे आ गया','Mark mastered')))]))]));
  }
}
