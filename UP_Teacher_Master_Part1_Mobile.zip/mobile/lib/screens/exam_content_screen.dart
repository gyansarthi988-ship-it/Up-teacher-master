import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'practice_screen.dart';
import 'mock_test_catalog_screen.dart';

class ExamContentScreen extends StatefulWidget {
  final String examId;
  final String examName;
  const ExamContentScreen({super.key, required this.examId, required this.examName});

  @override
  State<ExamContentScreen> createState() => _ExamContentScreenState();
}

class _ExamContentScreenState extends State<ExamContentScreen> {
  late Future<_SyllabusData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_SyllabusData> _load() async {
    final db = Supabase.instance.client;
    final mappings = await db.from('exam_subjects')
        .select('subject_id').eq('exam_id', widget.examId);
    final subjectIds = (mappings as List).map((e) => e['subject_id'] as String).toList();
    if (subjectIds.isEmpty) return const _SyllabusData([], [], [], []);
    final subjectRows = await db.from('subjects')
        .select('id,code,name_en,name_hi').inFilter('id', subjectIds).eq('is_active', true);
    final subjects = (subjectRows as List).cast<Map<String, dynamic>>();
    final sids = subjects.map((e) => e['id'] as String).toList();
    if (sids.isEmpty) return _SyllabusData([], [], [], []);
    final chapterRows = await db.from('chapters')
        .select('id,subject_id,name_en,name_hi').inFilter('subject_id', sids).eq('is_active', true);
    final chapters = (chapterRows as List).cast<Map<String, dynamic>>();
    final cids = chapters.map((e) => e['id'] as String).toList();
    if (cids.isEmpty) return _SyllabusData(subjects, chapters, [], []);
    final topicRows = await db.from('topics')
        .select('id,chapter_id,name_en,name_hi').inFilter('chapter_id', cids).eq('is_active', true);
    final topics = (topicRows as List).cast<Map<String, dynamic>>();
    final syllabusRows = await db.from('syllabus_items')
        .select('topic_id,weightage,notes_en,notes_hi')
        .eq('exam_id', widget.examId).eq('is_active', true);
    final syllabus = (syllabusRows as List).cast<Map<String, dynamic>>();
    final allowedTopicIds = syllabus.map((e) => e['topic_id'] as String).toSet();
    return _SyllabusData(subjects, chapters,
        topics.where((t) => allowedTopicIds.contains(t['id'])).toList(), syllabus);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.examName)),
    body: FutureBuilder<_SyllabusData>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Unable to load syllabus. Please check your connection and try again.\n${snapshot.error}',
              textAlign: TextAlign.center),
          ));
        }
        final data = snapshot.data!;
        if (data.subjects.isEmpty) {
          return const Center(child: Padding(
            padding: EdgeInsets.all(24),
            child: Text('Syllabus is being prepared. Please check again later.',
              textAlign: TextAlign.center),
          ));
        }
        return RefreshIndicator(
          onRefresh: () async => setState(() => _future = _load()),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Examination syllabus',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Card(color: const Color(0xFFEAF1FA), child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.timer)),
                title: const Text('Full-Length Mock Tests', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('Exam pattern • Subject-wise distribution • Timed test'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MockTestCatalogScreen(
                  examId: widget.examId, examName: widget.examName,
                ))),
              )),
              const SizedBox(height: 8),
              const Text('Subjects and topics published by the UP Teacher Master content team.',
                style: TextStyle(color: Colors.black54)),
              const SizedBox(height: 16),
              ...data.subjects.map((subject) {
                final subjectChapters = data.chapters.where((c) => c['subject_id'] == subject['id']).toList();
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ExpansionTile(
                    leading: const Icon(Icons.menu_book, color: Color(0xFF174A7E)),
                    title: Text('${subject['name_en']}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${subject['name_hi']}'),
                    children: subjectChapters.map((chapter) {
                      final chapterTopics = data.topics.where((t) => t['chapter_id'] == chapter['id']).toList();
                      return ExpansionTile(
                        tilePadding: const EdgeInsets.symmetric(horizontal: 20),
                        title: Text('${chapter['name_en']}'),
                        subtitle: Text('${chapter['name_hi']}'),
                        children: chapterTopics.map((topic) {
                          final syllabusItem = data.syllabus.firstWhere(
                            (s) => s['topic_id'] == topic['id'],
                            orElse: () => <String, dynamic>{},
                          );
                          final noteEn = syllabusItem['notes_en'] as String?;
                          final noteHi = syllabusItem['notes_hi'] as String?;
                          return ListTile(
                            dense: true,
                            leading: const Icon(Icons.topic_outlined, size: 19),
                            title: Text('${topic['name_en']}'),
                            trailing: const Icon(Icons.play_circle_outline, color: Color(0xFF174A7E)),
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => PracticeScreen(
                                examId: widget.examId,
                                topicId: topic['id'] as String,
                                topicName: (topic['name_hi'] ?? topic['name_en']).toString(),
                              ),
                            )),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${topic['name_hi']}'),
                                if ((noteEn ?? '').isNotEmpty) Text(noteEn!),
                                if ((noteHi ?? '').isNotEmpty) Text(noteHi!),
                              ],
                            ),
                          );
                        }).toList(),
                      );
                    }).toList(),
                  ),
                );
              }),
            ],
          ),
        );
      },
    ),
  );
}

class _SyllabusData {
  final List<Map<String, dynamic>> subjects;
  final List<Map<String, dynamic>> chapters;
  final List<Map<String, dynamic>> topics;
  final List<Map<String, dynamic>> syllabus;
  const _SyllabusData(this.subjects, this.chapters, this.topics, this.syllabus);
}
