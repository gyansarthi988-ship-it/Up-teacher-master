import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class DoubtAssistantScreen extends StatefulWidget {
  final String language;
  const DoubtAssistantScreen({super.key, this.language = 'en'});
  @override
  State<DoubtAssistantScreen> createState() => _DoubtAssistantScreenState();
}

class _DoubtAssistantScreenState extends State<DoubtAssistantScreen> {
  final question = TextEditingController();
  final subject = TextEditingController(text: 'General');
  bool busy = false;
  String? answer;
  String? error;
  List<Map<String, dynamic>> history = [];
  bool get hi => widget.language == 'hi';

  @override
  void initState() { super.initState(); _loadHistory(); }
  @override
  void dispose() { question.dispose(); subject.dispose(); super.dispose(); }

  Future<void> _loadHistory() async {
    try {
      final rows = await Supabase.instance.client.from('study_doubts')
        .select('id,subject,question,answer,status,created_at')
        .order('created_at', ascending: false).limit(20);
      if (mounted) setState(() => history = List<Map<String, dynamic>>.from(rows));
    } catch (_) { /* History is optional until migration is deployed. */ }
  }

  Future<void> _ask() async {
    final text = question.text.trim();
    if (text.length < 8) {
      setState(() => error = hi ? 'कृपया कम-से-कम 8 अक्षरों का प्रश्न लिखें।' : 'Please enter at least 8 characters.');
      return;
    }
    setState(() { busy = true; error = null; answer = null; });
    try {
      final result = await Supabase.instance.client.functions.invoke('answer-study-doubt', body: {
        'question': text, 'subject': subject.text.trim().isEmpty ? 'General' : subject.text.trim(),
        'language': hi ? 'hi' : 'en',
      });
      final data = Map<String, dynamic>.from(result.data as Map);
      if (result.status >= 400 || data['error'] != null) throw Exception(data['error'] ?? 'Request failed');
      if (mounted) setState(() => answer = data['answer']?.toString());
      question.clear();
      await _loadHistory();
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(hi ? 'AI Doubt Solver' : 'AI Doubt Solver')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(hi ? 'अपना सवाल पूछें' : 'Ask your study question', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 6), Text(hi ? 'Super TET, TGT, PRT और Junior परीक्षा की तैयारी के लिए bilingual सहायता।' : 'Bilingual study help for Super TET, TGT, PRT and Junior exams.'),
        const SizedBox(height: 14), TextField(controller: subject, decoration: InputDecoration(labelText: hi ? 'विषय' : 'Subject', border: const OutlineInputBorder())),
        const SizedBox(height: 12), TextField(controller: question, minLines: 4, maxLines: 7, maxLength: 3000, decoration: InputDecoration(labelText: hi ? 'अपना प्रश्न लिखें...' : 'Type your question...', alignLabelWithHint: true, border: const OutlineInputBorder())),
        if (error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(error!, style: const TextStyle(color: Colors.red))),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : _ask, icon: busy ? const SizedBox(width: 18,height: 18,child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome), label: Text(busy ? (hi ? 'उत्तर तैयार हो रहा है...' : 'Generating answer...') : (hi ? 'AI से उत्तर पूछें' : 'Ask AI Tutor')))),
      ]))),
      if (answer != null) Card(color: const Color(0xFFEAF3FF), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(hi ? 'आपका उत्तर' : 'Your Answer', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 10), SelectableText(answer!), const SizedBox(height: 10), Text(hi ? 'ध्यान दें: AI उत्तर में गलती हो सकती है। महत्वपूर्ण तथ्यों को आधिकारिक स्रोत से जाँचें।' : 'Note: AI can make mistakes. Verify important facts with official sources.', style: Theme.of(context).textTheme.bodySmall)]))),
      const SizedBox(height: 12), Text(hi ? 'आपके पिछले सवाल' : 'Your recent questions', style: Theme.of(context).textTheme.titleLarge),
      if (history.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(hi ? 'अभी कोई पुराना सवाल नहीं है।' : 'No previous questions yet.')),
      ...history.map((item) => Card(child: ExpansionTile(title: Text(item['question']?.toString() ?? '', maxLines: 2, overflow: TextOverflow.ellipsis), subtitle: Text('${item['subject'] ?? 'General'} · ${item['status'] ?? ''}'), children: [if ((item['answer'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.all(14), child: SelectableText(item['answer'].toString()))]))),
    ]),
  );
}
