import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key, this.existing = false});
  final bool existing;
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  String exam = 'SUPER_TET';
  String language = 'hi';
  int minutes = 120;
  bool busy = false;
  String? error;

  Future<void> save() async {
    setState(() { busy = true; error = null; });
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Please sign in again.');
      await Supabase.instance.client.from('user_onboarding_preferences').upsert({
        'user_id': user.id,
        'primary_exam_code': exam,
        'preferred_language': language,
        'daily_goal_minutes': minutes,
        'completed_at': DateTime.now().toUtc().toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, onConflict: 'user_id');
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const HomeScreen()), (route) => false);
    } catch (_) {
      setState(() => error = language == 'hi'
        ? 'सेटअप सेव नहीं हो पाया। कृपया दोबारा प्रयास करें।'
        : 'Setup could not be saved. Please try again.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final hi = language == 'hi';
    final exams = [
      ('SUPER_TET', 'UP Super TET'),
      ('TGT', 'UP TGT'),
      ('PRT', 'UP PRT'),
      ('JUNIOR', 'UP Junior Level'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(hi ? 'आपकी तैयारी का सेटअप' : 'Your Study Setup'),
        actions: [
          TextButton(
            onPressed: busy ? null : () => setState(() => language = hi ? 'en' : 'hi'),
            child: Text(hi ? 'English' : 'हिन्दी',
              style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
      body: SafeArea(child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 8),
          const CircleAvatar(radius: 38, child: Icon(Icons.school_rounded, size: 42)),
          const SizedBox(height: 18),
          Text(hi ? 'स्वागत है, अभ्यर्थी!' : 'Welcome, Aspirant!',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(hi
            ? 'अपनी परीक्षा और पढ़ाई का लक्ष्य चुनें। हम आपके लिए तैयारी का अनुभव व्यवस्थित करेंगे।'
            : 'Choose your exam and study goal. We will organise your preparation experience.',
            textAlign: TextAlign.center),
          const SizedBox(height: 28),
          Text(hi ? '1. आपकी मुख्य परीक्षा' : '1. Your primary examination',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...exams.map((item) => Card(
            child: RadioListTile<String>(
              value: item.$1, groupValue: exam,
              title: Text(item.$2),
              onChanged: busy ? null : (v) => setState(() => exam = v!),
            ),
          )),
          const SizedBox(height: 18),
          Text(hi ? '2. ऐप की भाषा' : '2. App language',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'hi', label: Text('हिन्दी')),
              ButtonSegment(value: 'en', label: Text('English')),
              ButtonSegment(value: 'both', label: Text('दोनों / Both')),
            ],
            selected: {language},
            onSelectionChanged: busy ? null : (v) => setState(() => language = v.first),
          ),
          const SizedBox(height: 22),
          Text(hi ? '3. रोज़ाना पढ़ाई का लक्ष्य' : '3. Daily study target',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
          Text('$minutes ${hi ? 'मिनट प्रतिदिन' : 'minutes per day'}'),
          Slider(
            value: minutes.toDouble(), min: 15, max: 360, divisions: 23,
            label: '$minutes min',
            onChanged: busy ? null : (v) => setState(() => minutes = v.round()),
          ),
          if (error != null) ...[
            const SizedBox(height: 8),
            Text(error!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: busy ? null : save,
            icon: busy
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.arrow_forward),
            label: Text(busy
              ? (hi ? 'सेव हो रहा है…' : 'Saving…')
              : (hi ? 'सेटअप पूरा करें' : 'Complete Setup')),
          ),
          const SizedBox(height: 12),
          Text(hi
            ? 'आप इन प्राथमिकताओं को बाद में भी बदल सकते हैं।'
            : 'You can change these preferences later.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodySmall),
        ],
      )),
    );
  }
}
