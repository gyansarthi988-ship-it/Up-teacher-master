import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PracticeScreen extends StatefulWidget {
  final String examId;
  final String topicId;
  final String topicName;
  final List<String>? questionIds;
  final Future<void> Function()? onSubmitted;
  const PracticeScreen({super.key, required this.examId, required this.topicId, required this.topicName, this.questionIds, this.onSubmitted});
  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  bool _loading = true;
  bool _submitting = false;
  String? _error;
  List<Map<String, dynamic>> _questions = [];
  final Map<String, String?> _answers = {};
  int _index = 0;
  Timer? _timer;
  int _secondsLeft = 15 * 60;

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  Future<void> _load() async {
    try {
      var query = Supabase.instance.client.from('questions')
        .select('id,question_hi,question_en,marks,negative_marks,topic_id,question_options(id,option_key,text_hi,text_en,display_order)')
        .eq('exam_id', widget.examId).eq('status', 'published');
      if (widget.questionIds != null) {
        if (widget.questionIds!.isEmpty) { if (mounted) setState(() { _questions = []; _loading = false; }); return; }
        query = query.inFilter('id', widget.questionIds!);
      } else {
        query = query.eq('topic_id', widget.topicId);
      }
      final rows = await query.limit(50);
      final list = (rows as List).cast<Map<String, dynamic>>();
      for (final q in list) {
        final opts = (q['question_options'] as List? ?? []).cast<Map<String, dynamic>>();
        opts.sort((a,b) => (a['display_order'] as int? ?? 0).compareTo(b['display_order'] as int? ?? 0));
        q['question_options'] = opts;
      }
      if (!mounted) return;
      setState(() { _questions = list; _loading = false; });
    } catch (e) { if (mounted) setState(() { _error = e.toString(); _loading = false; }); }
  }

  void _startMockTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_secondsLeft <= 1) { t.cancel(); _submit('mock'); }
      else if (mounted) setState(() => _secondsLeft--);
    });
  }

  Future<void> _submit(String mode) async {
    if (_submitting || _questions.isEmpty) return;
    _timer?.cancel();
    setState(() => _submitting = true);
    try {
      final payload = _questions.map((q) => {
        'question_id': q['id'], 'option_id': _answers[q['id']]
      }).toList();
      final result = await Supabase.instance.client.rpc('submit_test_attempt', params: {
        'p_exam_id': widget.examId, 'p_answers': payload, 'p_mode': mode,
      });
      if (widget.onSubmitted != null) await widget.onSubmitted!();
      if (!mounted) return;
      await Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => _ResultScreen(result: Map<String, dynamic>.from(result as Map), questions: _questions),
      ));
    } catch (e) {
      if (mounted) { setState(() => _submitting = false); ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Submission failed. Please try again. $e'))); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(widget.topicName), actions: [
      if (_questions.isNotEmpty) Padding(padding: const EdgeInsets.only(right: 16),
        child: Center(child: Text('${_secondsLeft ~/ 60}:${(_secondsLeft % 60).toString().padLeft(2,'0')}'))),
    ]), body: _loading ? const Center(child: CircularProgressIndicator()) :
      _error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Questions could not be loaded.\n$_error', textAlign: TextAlign.center))) :
      _questions.isEmpty ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('इस topic के प्रश्न अभी उपलब्ध नहीं हैं। Questions will appear here after the content team publishes them.'))) :
      _quizBody());
  }

  Widget _quizBody() {
    final q = _questions[_index];
    final options = (q['question_options'] as List).cast<Map<String, dynamic>>();
    final selected = _answers[q['id']];
    return Column(children: [
      LinearProgressIndicator(value: (_index + 1) / _questions.length),
      Padding(padding: const EdgeInsets.fromLTRB(16,12,16,4), child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text('Question ${_index + 1} of ${_questions.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
          Text('Marks: ${q['marks'] ?? 1}  |  Negative: ${q['negative_marks'] ?? 0}')],)),
      Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
        Text((q['question_hi'] ?? q['question_en'] ?? '').toString(), style: Theme.of(context).textTheme.titleLarge),
        if ((q['question_hi'] ?? '').toString().isNotEmpty && (q['question_en'] ?? '').toString().isNotEmpty) ...[
          const SizedBox(height: 8), Text(q['question_en'].toString(), style: const TextStyle(color: Colors.black54)),
        ],
        const SizedBox(height: 18),
        ...options.map((o) => Card(child: RadioListTile<String>(
          value: o['id'].toString(), groupValue: selected,
          onChanged: (v) => setState(() => _answers[q['id'].toString()] = v),
          title: Text('${o['option_key']}. ${o['text_hi'] ?? o['text_en'] ?? ''}'),
          subtitle: (o['text_hi'] != null && o['text_en'] != null) ? Text(o['text_en'].toString()) : null,
        ))),
      ])),
      Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        OutlinedButton(onPressed: _index == 0 ? null : () => setState(() => _index--), child: const Text('Previous')),
        const Spacer(),
        if (_index < _questions.length - 1)
          FilledButton(onPressed: () => setState(() => _index++), child: const Text('Next'))
        else FilledButton(onPressed: _submitting ? null : () => _submit('practice'), child: _submitting ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Text('Submit')),
      ])),
    ]);
  }
}

class _ResultScreen extends StatelessWidget {
  final Map<String, dynamic> result;
  final List<Map<String, dynamic>> questions;
  const _ResultScreen({required this.result, required this.questions});
  @override
  Widget build(BuildContext context) {
    final score = result['score'] ?? 0;
    final max = result['max_score'] ?? 0;
    final details = (result['details'] as List? ?? []).cast<Map<String, dynamic>>();
    return Scaffold(appBar: AppBar(title: const Text('Test Result')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
          Text('$score / $max', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
          const Text('Your Score'), const SizedBox(height: 16),
          Wrap(alignment: WrapAlignment.spaceEvenly, spacing: 18, runSpacing: 12, children: [
            _metric('Correct', result['correct_answers']), _metric('Wrong', result['wrong_answers']),
            _metric('Skipped', result['unanswered']), _metric('Attempted', result['attempted_questions']),
          ]),
        ]))),
        const SizedBox(height: 12), const Text('Answer Review', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        ...details.asMap().entries.map((entry) {
          final i = entry.key; final d = entry.value; final q = questions[i];
          final opts = (q['question_options'] as List).cast<Map<String, dynamic>>();
          final correctMatches = opts.where((o) => o['id'] == d['correct_option_id']);
          final chosenMatches = opts.where((o) => o['id'] == d['selected_option_id']);
          final correct = correctMatches.isEmpty ? null : correctMatches.first;
          final chosen = chosenMatches.isEmpty ? null : chosenMatches.first;
          return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Q${i+1}. ${q['question_hi'] ?? q['question_en']}', style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6), Text('Your answer: ${chosen == null ? 'Not attempted' : '${chosen['option_key']}. ${chosen['text_hi'] ?? chosen['text_en']}'}'),
            Text('Correct answer: ${correct == null ? 'Unavailable' : '${correct['option_key']}. ${correct['text_hi'] ?? correct['text_en']}'}', style: const TextStyle(color: Colors.green)),
            if ((d['explanation_hi'] ?? d['explanation_en'] ?? '').toString().isNotEmpty)
              Padding(padding: const EdgeInsets.only(top:6), child: Text('Explanation: ${d['explanation_hi'] ?? d['explanation_en']}')),
          ])));
        }),
        FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Back to syllabus')),
      ]));
  }
  Widget _metric(String label, dynamic value) => Column(children: [Text('${value ?? 0}', style: const TextStyle(fontSize:20,fontWeight:FontWeight.bold)), Text(label)]);
}
