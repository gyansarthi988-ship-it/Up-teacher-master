import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Converts performance analytics into an actionable, topic-wise improvement plan.
/// All data is scoped to the signed-in learner by get_my_performance_analytics.
class WeakTopicDiagnosisScreen extends StatefulWidget {
  final String language;
  const WeakTopicDiagnosisScreen({super.key, this.language = 'hi'});
  @override
  State<WeakTopicDiagnosisScreen> createState() => _WeakTopicDiagnosisScreenState();
}

class _WeakTopicDiagnosisScreenState extends State<WeakTopicDiagnosisScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic> data = {};
  bool get hi => widget.language == 'hi';
  String t(String h, String e) => hi ? h : e;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    if (mounted) setState(() { loading = true; error = null; });
    try {
      final result = await Supabase.instance.client.rpc('get_my_performance_analytics');
      data = Map<String, dynamic>.from(result as Map);
    } catch (e) {
      error = t('प्रदर्शन डेटा लोड नहीं हुआ। पहले Practice या Mock Test जमा करें।',
        'Could not load performance data. Complete a Practice or Mock Test first.');
    }
    if (mounted) setState(() => loading = false);
  }

  Map<String, dynamic> get summary => Map<String, dynamic>.from(data['summary'] as Map? ?? {});
  List<Map<String, dynamic>> get topics => (data['topics'] as List? ?? [])
      .map((e) => Map<String, dynamic>.from(e as Map)).toList();
  double number(dynamic v) => (num.tryParse('$v') ?? 0).toDouble();
  String topicName(Map<String, dynamic> x) =>
      ((hi ? x['name_hi'] : x['name_en']) ?? x['name_en'] ?? 'Topic').toString();

  String level(Map<String, dynamic> x) {
    final a = number(x['accuracy']);
    if (a < 40) return t('अत्यधिक कमजोर', 'Critical');
    if (a < 60) return t('कमजोर', 'Weak');
    return t('ध्यान देने योग्य', 'Needs attention');
  }

  List<String> actions(Map<String, dynamic> x) {
    final a = number(x['accuracy']);
    if (a < 40) return [
      t('सबसे पहले इस टॉपिक के बेसिक नोट्स पढ़ें।', 'Start with the basic notes for this topic.'),
      t('10 आसान MCQs हल करें और हर उत्तर का explanation पढ़ें।', 'Solve 10 easy MCQs and read every explanation.'),
      t('कल दोबारा अभ्यास करें; फिर 3 दिन बाद revision करें।', 'Practise again tomorrow, then revise after 3 days.')
    ];
    if (a < 60) return [
      t('गलत हुए प्रश्नों के concepts दोहराएँ।', 'Revise the concepts behind your incorrect answers.'),
      t('15 topic-wise MCQs समय सीमा में हल करें।', 'Solve 15 timed topic-wise MCQs.'),
      t('गलत प्रश्नों को Spaced Revision में दोहराएँ।', 'Repeat incorrect questions in Spaced Revision.')
    ];
    return [
      t('इस टॉपिक का संक्षिप्त revision करें।', 'Do a short revision of this topic.'),
      t('10 mixed MCQs से accuracy जाँचें।', 'Check accuracy with 10 mixed MCQs.'),
      t('गलतियों को नोट करके अगले सप्ताह फिर जाँचें।', 'Record mistakes and reassess next week.')
    ];
  }

  @override
  Widget build(BuildContext context) {
    final weak = topics.where((x) => x['weak'] == true).toList()
      ..sort((a,b) => number(a['accuracy']).compareTo(number(b['accuracy'])));
    final attempts = (num.tryParse('${summary['attempts']}') ?? 0).toInt();
    return Scaffold(
      appBar: AppBar(title: Text(t('कमजोर टॉपिक डायग्नोसिस', 'Weak Topic Diagnosis')),
        actions: [IconButton(onPressed: load, icon: const Icon(Icons.refresh))]),
      body: loading ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(16), children: [
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
          Card(color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('आपका सुधार प्लान', 'YOUR IMPROVEMENT PLAN'),
                style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(t('यह रिपोर्ट आपके submitted practice और mock test के प्रदर्शन से बनती है।',
                'This report is generated from your submitted practice and mock test performance.')),
              const SizedBox(height: 8),
              Text('${t('कुल टेस्ट', 'Tests')}: $attempts  •  ${t('पहचाने गए कमजोर टॉपिक्स', 'Weak topics identified')}: ${weak.length}',
                style: const TextStyle(fontWeight: FontWeight.w600))
            ]))),
          const SizedBox(height: 12),
          if (attempts == 0)
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(
              t('अभी पर्याप्त डेटा नहीं है। पहले कुछ Practice या Mock Tests जमा करें। उसके बाद यह स्क्रीन आपकी कमजोरियों और सुधार के कदम दिखाएगी।',
                'There is not enough data yet. Submit a few Practice or Mock Tests first. This screen will then show your weak areas and improvement steps.'))))
          else if (weak.isEmpty)
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(
              t('Analytics में अभी कोई weak topic चिन्हित नहीं है। नियमित अभ्यास जारी रखें और नए टेस्ट जमा करते रहें।',
                'No weak topics are currently flagged by analytics. Keep practising and submitting new tests.'))))
          else ...[
            Text(t('सबसे पहले इन टॉपिक्स पर काम करें', 'PRIORITISE THESE TOPICS'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...weak.take(12).map((x) {
              final accuracy = number(x['accuracy']).clamp(0,100).toDouble();
              final steps = actions(x);
              return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(topicName(x), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(20)),
                      child: Text(level(x), style: TextStyle(color: Colors.deepOrange.shade900, fontSize: 11)))
                  ]),
                  const SizedBox(height: 9),
                  LinearProgressIndicator(value: accuracy/100),
                  const SizedBox(height: 5),
                  Text('${accuracy.toStringAsFixed(1)}% ${t('सटीकता', 'accuracy')}  •  ${x['attempted'] ?? 0} ${t('प्रयास', 'attempts')}'),
                  const Divider(height: 20),
                  Text(t('आपके अगले कदम', 'YOUR NEXT STEPS'), style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  ...steps.asMap().entries.map((e) => Padding(
                    padding: const EdgeInsets.only(bottom: 5),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      CircleAvatar(radius: 10, child: Text('${e.key+1}', style: const TextStyle(fontSize: 11))),
                      const SizedBox(width: 8), Expanded(child: Text(e.value))
                    ])))
                ])));
            })
          ],
          const SizedBox(height: 10),
          Text(t('ध्यान दें: सुझाव उपलब्ध analytics data पर आधारित हैं। यह AI द्वारा verified diagnosis या परीक्षा परिणाम की गारंटी नहीं है।',
            'Note: Recommendations are based on available analytics data. They are not an AI-verified diagnosis or a guarantee of exam results.'),
            style: Theme.of(context).textTheme.bodySmall)
        ])),
    );
  }
}
