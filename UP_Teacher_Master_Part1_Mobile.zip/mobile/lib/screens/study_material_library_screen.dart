import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'premium_membership_screen.dart';

class StudyMaterialLibraryScreen extends StatefulWidget {
  final String language;
  final String? examId;
  const StudyMaterialLibraryScreen({super.key,this.language='en',this.examId});
  @override State<StudyMaterialLibraryScreen> createState()=>_StudyMaterialLibraryScreenState();
}
class _StudyMaterialLibraryScreenState extends State<StudyMaterialLibraryScreen>{
 final db=Supabase.instance.client;
 List<Map<String,dynamic>> rows=[];
 Map<String,String> progress={};
 bool loading=true; String? error; String filter='all'; String search='';
 bool get hi=>widget.language=='hi';
 String t(String e,String h)=>hi?h:e;
 @override void initState(){super.initState();load();}
 Future<void> load() async {
  setState(()=>loading=true); error=null;
  try{
   var q=db.from('study_materials').select('id,exam_id,subject_id,topic_id,title_en,title_hi,description_en,description_hi,material_type,storage_path,external_url,access_tier,file_size_bytes,published_at,topics(name_en,name_hi,chapters(name_en,name_hi,subjects(name_en,name_hi)))').eq('status','published');
   if(widget.examId!=null) q=q.eq('exam_id',widget.examId!);
   final data=await q.order('published_at',ascending:false);
   rows=data.map((e)=>Map<String,dynamic>.from(e)).toList();
   final p=await db.from('user_material_progress').select('material_id,status').eq('user_id',db.auth.currentUser!.id);
   progress={for(final x in p) x['material_id'] as String:x['status'] as String};
  }catch(_){error=t('Could not load study materials. Apply migration 0018 and retry.','अध्ययन सामग्री लोड नहीं हुई। Migration 0018 लागू करके दोबारा प्रयास करें।');}
  if(mounted)setState(()=>loading=false);
 }
 Future<void> mark(String id,String status) async{
  try{
   await db.from('user_material_progress').upsert({'user_id':db.auth.currentUser!.id,'material_id':id,'status':status,'completed_at':status=='completed'?DateTime.now().toUtc().toIso8601String():null,'updated_at':DateTime.now().toUtc().toIso8601String()},onConflict:'user_id,material_id');
   if(mounted)setState(()=>progress[id]=status);
  }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('Progress save failed.','प्रगति सेव नहीं हुई।'))));}
 }
 Future<void> open(Map<String,dynamic> x) async{
  if(x['access_tier']=='premium'){
   try{if(await db.rpc('has_premium_access')!=true){if(!mounted)return;await Navigator.push(context,MaterialPageRoute(builder:(_)=>PremiumMembershipScreen(language:widget.language)));return;}}
   catch(_){msg(t('Membership verification failed.','सदस्यता सत्यापन विफल।'));return;}
  }
  try{
   String? url=x['external_url'] as String?; final path=x['storage_path'] as String?;
   if((url==null||url.isEmpty)&&path!=null&&path.isNotEmpty)url=await db.storage.from('study-materials').createSignedUrl(path,600);
   if(url==null||url.isEmpty){msg(t('Material link unavailable.','सामग्री लिंक उपलब्ध नहीं।'));return;}
   await Clipboard.setData(ClipboardData(text:url));
   if(mounted)showDialog<void>(context:context,builder:(_)=>AlertDialog(title:Text(t('Secure link copied','सुरक्षित लिंक कॉपी हुआ')),content:Text(t('Temporary link copied. Paste it in your browser.','अस्थायी लिंक कॉपी हुआ। इसे ब्राउज़र में पेस्ट करें।')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))]));
  }catch(_){msg(t('Material access failed.','सामग्री खोलने में समस्या हुई।'));}
 }
 void msg(String s){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));}
 @override Widget build(BuildContext context){
  final visible=rows.where((x){
   final title=((hi?x['title_hi']:x['title_en'])??x['title_en']??x['title_hi']??'').toString().toLowerCase();
   final matches=title.contains(search.toLowerCase());
   return matches&&(filter=='all'||(filter=='completed'?(progress[x['id']]=='completed'):filter=='pending'?(progress[x['id']]!='completed'):x['access_tier']==filter));
  }).toList();
  final completed=rows.where((x)=>progress[x['id']]=='completed').length;
  return Scaffold(appBar:AppBar(title:Text(t('Study Library & Progress','स्टडी लाइब्रेरी और प्रगति')),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),
   body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.all(14),children:[
    if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
    Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
     Text(t('YOUR LEARNING COMPLETION','आपकी पढ़ाई की प्रगति'),style:const TextStyle(fontWeight:FontWeight.bold)),
     const SizedBox(height:8),LinearProgressIndicator(value:rows.isEmpty?0:completed/rows.length),
     const SizedBox(height:5),Text('$completed / ${rows.length} ${t('materials completed','सामग्री पूरी')}')
    ]))),
    TextField(decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:t('Search notes, PDFs, chapters...','नोट्स, PDF और अध्याय खोजें...')),onChanged:(v)=>setState(()=>search=v)),
    const SizedBox(height:8),
    Wrap(spacing:6,children:[
     for(final f in ['all','pending','completed','free','premium'])
      ChoiceChip(label:Text({'all':t('All','सभी'),'pending':t('Pending','बाकी'),'completed':t('Completed','पूरे'),'free':'FREE','premium':'PREMIUM'}[f]!),selected:filter==f,onSelected:(_)=>setState(()=>filter=f))
    ]),
    if(visible.isEmpty)Padding(padding:const EdgeInsets.all(20),child:Text(t('No matching materials. Admin must publish study materials first.','कोई सामग्री नहीं मिली। Admin को पहले सामग्री publish करनी होगी।'))),
    ...visible.map((x){
     final id=x['id'] as String; final title=(hi?x['title_hi']:x['title_en'])??x['title_en']??x['title_hi']??t('Study material','अध्ययन सामग्री');
     final topic=x['topics'] is Map?Map<String,dynamic>.from(x['topics']):<String,dynamic>{};
     final chapter=topic['chapters'] is Map?Map<String,dynamic>.from(topic['chapters']):<String,dynamic>{};
     final subject=chapter['subjects'] is Map?Map<String,dynamic>.from(chapter['subjects']):<String,dynamic>{};
     final subtitle=[if(subject.isNotEmpty)(hi?subject['name_hi']:subject['name_en']),if(chapter.isNotEmpty)(hi?chapter['name_hi']:chapter['name_en']),if(topic.isNotEmpty)(hi?topic['name_hi']:topic['name_en'])].whereType<String>().join(' • ');
     final status=progress[id]??'not_started';
     return Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      ListTile(contentPadding:EdgeInsets.zero,leading:Icon(x['access_tier']=='premium'?Icons.workspace_premium:Icons.menu_book),title:Text(title.toString(),style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('$subtitle\n${x['access_tier']=='premium'?'PREMIUM':'FREE'} • ${status.replaceAll('_',' ')}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.open_in_new),onPressed:()=>open(x))),
      DropdownButtonFormField<String>(value:status,decoration:InputDecoration(labelText:t('Learning status','पढ़ाई की स्थिति'),isDense:true),items:[
       DropdownMenuItem(value:'not_started',child:Text(t('Not started','शुरू नहीं किया'))),
       DropdownMenuItem(value:'in_progress',child:Text(t('In progress','पढ़ रहे हैं'))),
       DropdownMenuItem(value:'completed',child:Text(t('Completed','पूरा हुआ'))),
      ],onChanged:(v){if(v!=null)mark(id,v);})
     ])));
    })
   ])));
 }
}
