import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/services.dart';
import 'premium_membership_screen.dart';

class SpacedRevisionScreen extends StatefulWidget {
  final String language;
  const SpacedRevisionScreen({super.key, this.language = 'en'});
  @override
  State<SpacedRevisionScreen> createState() => _SpacedRevisionScreenState();
}

class _SpacedRevisionScreenState extends State<SpacedRevisionScreen> {
  final db = Supabase.instance.client;
  bool get hi => widget.language == 'hi';
  bool loading = true, busy = false, revealed = false;
  String? error, examId;
  List<Map<String, dynamic>> exams = [], items = [], relatedMaterials = [];
  int index = 0;
  int masteredThisSession = 0;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final rows = await db.from('exams').select('id,code,name_hi,name_en').eq('is_active', true).order('name_en');
      exams = List<Map<String,dynamic>>.from(rows);
      if (examId == null && exams.isNotEmpty) examId = exams.first['id'].toString();
      if (examId != null) {
        final result = await db.rpc('get_my_revision_queue', params: {'p_exam_id': examId, 'p_limit': 50});
        items = List<Map<String,dynamic>>.from((result as Map)['items'] as List? ?? []);
        final topicIds = items.map((x) => x['topic_id']).whereType<String>().toSet().toList();
        relatedMaterials = [];
        if (topicIds.isNotEmpty) {
          final materialRows = await db.from('study_materials')
            .select('id,topic_id,title_en,title_hi,description_en,description_hi,storage_path,external_url,access_tier,material_type')
            .eq('status','published').inFilter('topic_id', topicIds);
          relatedMaterials = List<Map<String,dynamic>>.from(materialRows);
        }
      }
      index = 0; revealed = false;
    } catch (e) { error = e.toString(); }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _rate(String rating) async {
    if (examId == null || items.isEmpty || busy) return;
    setState(() => busy = true);
    try {
      final item = items[index];
      final result = await db.rpc('submit_my_revision_review', params: {
        'p_exam_id': examId, 'p_question_id': item['question_id'], 'p_rating': rating,
      });
      if ((result as Map)['mastered'] == true) masteredThisSession++;
      items.removeAt(index);
      if (index >= items.length && index > 0) index--;
      revealed = false;
      if (items.isEmpty) await _load();
    } catch (e) { error = e.toString(); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> _openRelatedMaterial(Map<String,dynamic> material) async {
    if (material['access_tier'] == 'premium') {
      try {
        if (await Supabase.instance.client.rpc('has_premium_access') != true) {
          if (!mounted) return;
          await Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => PremiumMembershipScreen(language: widget.language)));
          return;
        }
      } catch (_) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(hi ? 'Premium access सत्यापित नहीं हुआ।' : 'Could not verify Premium access.')));
        return;
      }
    }
    try {
      String? url = material['external_url'] as String?;
      final path = material['storage_path'] as String?;
      if ((url == null || url.isEmpty) && path != null && path.isNotEmpty) {
        url = await Supabase.instance.client.storage.from('study-materials').createSignedUrl(path, 600);
      }
      if (url == null || url.isEmpty) throw Exception('No material URL');
      await Clipboard.setData(ClipboardData(text: url));
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(hi ? 'अस्थायी सामग्री लिंक कॉपी हो गया।' : 'Temporary material link copied.')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(hi ? 'सामग्री उपलब्ध नहीं है।' : 'Material is unavailable.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final item = items.isEmpty ? null : items[index];
    return Scaffold(
      appBar: AppBar(title: Text(hi ? 'स्मार्ट रिवीजन' : 'Spaced Revision')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(hi ? 'भूलने से पहले दोहराएँ' : 'Review before you forget', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 6), Text(hi ? 'आपके गलत उत्तरों को अंतराल के साथ फिर से दिखाया जाएगा।' : 'Previously missed questions return at spaced intervals.'),
            const SizedBox(height: 12), DropdownButtonFormField<String>(value: examId, decoration: InputDecoration(labelText: hi ? 'परीक्षा चुनें' : 'Select exam'), items: exams.map((e) => DropdownMenuItem(value: e['id'].toString(), child: Text((hi ? e['name_hi'] : e['name_en'])?.toString() ?? e['code'].toString()))).toList(), onChanged: (v) { setState(() => examId = v); _load(); }),
          ]))),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
          Row(children: [Expanded(child: _metric(hi ? 'बाकी प्रश्न' : 'Due now', '${items.length}')), const SizedBox(width: 8), Expanded(child: _metric(hi ? 'इस सत्र में mastered' : 'Mastered this session', '$masteredThisSession'))]),
          const SizedBox(height: 14),
          if (item == null) Card(child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [const Icon(Icons.celebration, size: 42), const SizedBox(height: 8), Text(hi ? 'आज के सभी रिवीजन पूरे!' : 'All caught up for now!', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 6), Text(hi ? 'नए गलत उत्तर आने पर वे यहाँ दिखाई देंगे।' : 'New missed questions will appear here when due.'), OutlinedButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: Text(hi ? 'रिफ्रेश' : 'Refresh'))]))),
          if (item != null) ...[
            Text('${hi ? 'प्रश्न' : 'Question'} ${index + 1} / ${items.length}', style: Theme.of(context).textTheme.titleMedium),
            Card(child: Padding(padding: const EdgeInsets.all(18), child: Text((hi ? item['question_hi'] : item['question_en'])?.toString() ?? '', style: Theme.of(context).textTheme.titleMedium))),
            ...relatedMaterials.where((m) => m['topic_id'] == item['topic_id']).map((m) => Card(
              child: ListTile(
                leading: Icon(m['access_tier'] == 'premium' ? Icons.workspace_premium : Icons.menu_book),
                title: Text((hi ? m['title_hi'] : m['title_en'])?.toString() ?? (m['title_en'] ?? m['title_hi'] ?? 'Study material').toString()),
                subtitle: Text(hi ? 'इस प्रश्न के टॉपिक से संबंधित अध्ययन सामग्री' : 'Study material linked to this revision topic'),
                trailing: const Icon(Icons.open_in_new),
                onTap: () => _openRelatedMaterial(m),
              ),
            )), 

            OutlinedButton.icon(onPressed: () => setState(() => revealed = !revealed), icon: Icon(revealed ? Icons.visibility_off : Icons.visibility), label: Text(revealed ? (hi ? 'उत्तर छिपाएँ' : 'Hide explanation') : (hi ? 'व्याख्या दिखाएँ' : 'Reveal explanation'))),
            if (revealed) Card(color: Theme.of(context).colorScheme.surfaceContainerHighest, child: Padding(padding: const EdgeInsets.all(16), child: Text(((hi ? item['explanation_hi'] : item['explanation_en']) ?? (hi ? 'व्याख्या उपलब्ध नहीं है।' : 'No explanation available.')).toString()))),
            const SizedBox(height: 12), Text(hi ? 'आपको उत्तर कितना याद था?' : 'How well did you recall it?', style: Theme.of(context).textTheme.titleMedium),
            if (!revealed) Text(hi ? 'रेटिंग देने से पहले व्याख्या देखें।' : 'Reveal the explanation before rating your recall.'),
            Wrap(spacing: 8, runSpacing: 8, children: [
              _rateButton('again', hi ? 'फिर से' : 'Again', Colors.red),
              _rateButton('hard', hi ? 'मुश्किल' : 'Hard', Colors.orange),
              _rateButton('good', hi ? 'अच्छा' : 'Good', Colors.green),
              _rateButton('easy', hi ? 'आसान' : 'Easy', Colors.blue),
            ]),
            if (busy) const LinearProgressIndicator(),
          ],
          const SizedBox(height: 12), Text(hi ? 'नोट: 5 सफल रिवीजन के बाद प्रश्न mastered माना जाएगा।' : 'A question is marked mastered after five successful reviews. Intervals adapt to your recall rating.', style: Theme.of(context).textTheme.bodySmall),
        ]),
      ),
    );
  }

  Widget _metric(String label, String value) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(label, textAlign: TextAlign.center)])));
  Widget _rateButton(String rating, String label, Color color) => FilledButton(onPressed: (!revealed || busy) ? null : () => _rate(rating), style: FilledButton.styleFrom(backgroundColor: color), child: Text(label));
}
