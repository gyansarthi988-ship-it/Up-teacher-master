import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'performance_analytics_screen.dart';
import 'smart_learning_screen.dart';
import 'spaced_revision_screen.dart';
import 'ai_study_mentor_screen.dart';

class DailyCommandCenterScreen extends StatefulWidget {
  final String language;
  const DailyCommandCenterScreen({super.key, this.language = 'en'});
  @override
  State<DailyCommandCenterScreen> createState() => _DailyCommandCenterScreenState();
}

class _DailyCommandCenterScreenState extends State<DailyCommandCenterScreen> {
  bool loading = true;
  String? error;
  Map<String, dynamic> analytics = {};
  Map<String, dynamic> mentor = {};
  bool get hi => widget.language == 'hi';
  String t(String h, String e) => hi ? h : e;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final db = Supabase.instance.client;
      final results = await Future.wait([
        db.rpc('get_my_performance_analytics'),
        db.rpc('get_my_mentor_dashboard'),
      ]);
      analytics = Map<String, dynamic>.from(results[0] as Map);
      mentor = Map<String, dynamic>.from(results[1] as Map);
    } catch (e) {
      error = t('डैशबोर्ड डेटा अभी उपलब्ध नहीं है। कृपया बाद में refresh करें।',
        'Dashboard data is not available yet. Please refresh later.');
    }
    if (mounted) setState(() => loading = false);
  }

  Map<String, dynamic> get summary =>
      Map<String, dynamic>.from(analytics['summary'] as Map? ?? {});
  int number(dynamic value) => (num.tryParse('$value') ?? 0).round();
  String percent(dynamic value) => '${(num.tryParse('$value') ?? 0).toStringAsFixed(1)}%';

  void _open(Widget page) => Navigator.of(context).push(
    MaterialPageRoute(builder: (_) => page)).then((_) => _load());

  @override
  Widget build(BuildContext context) {
    final attempts = number(summary['attempts']);
    final tasks = ((mentor['learning_plan'] as Map?)?['tasks'] as List?) ?? [];
    final pending = tasks.where((e) => (e as Map)['status'] != 'completed').length;
    return Scaffold(
      appBar: AppBar(title: Text(t('Daily Study Command Centre','Daily Study Command Centre')),
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
      body: loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(onRefresh: _load, child: ListView(
          padding: const EdgeInsets.all(16), children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFF174A7E), Color(0xFF2879A8)]),
                borderRadius: BorderRadius.circular(18)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t('आज का लक्ष्य','TODAY’S FOCUS'),
                  style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(mentor['configured'] == true
                    ? '${mentor['daily_minutes'] ?? 120} ${t('मिनट पढ़ाई','study minutes')}'
                    : t('अपना study goal सेट करें','Set your study goal'),
                  style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(mentor['exam_name']?.toString() ??
                    t('परीक्षा चुनकर अपनी तैयारी शुरू करें','Choose an exam to begin your preparation'),
                  style: const TextStyle(color: Colors.white70)),
                const SizedBox(height: 14),
                FilledButton.tonalIcon(
                  onPressed: () => _open(AiStudyMentorScreen(language: hi ? 'hi' : 'en')),
                  icon: const Icon(Icons.flag),
                  label: Text(t('लक्ष्य सेट / अपडेट करें','Set / Update Goal')),
                ),
              ]),
            ),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
              child: Text(error!, style: const TextStyle(color: Colors.deepOrange))),
            const SizedBox(height: 18),
            Text(t('आपकी तैयारी का सारांश','YOUR PREPARATION SUMMARY'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2, childAspectRatio: 1.75, crossAxisSpacing: 10, mainAxisSpacing: 10,
              children: [
                _metric(t('कुल टेस्ट','Tests completed'), '$attempts', Icons.assignment_turned_in),
                _metric(t('औसत स्कोर','Average score'), percent(summary['average_percentage']), Icons.insights),
                _metric(t('सटीकता','Accuracy'), percent(summary['accuracy']), Icons.track_changes),
                _metric(t('सही उत्तर','Correct answers'), '${number(summary['correct'])}', Icons.check_circle),
              ]),
            const SizedBox(height: 20),
            Text(t('आज के अध्ययन कार्य','STUDY ACTIONS'),
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _action(Icons.event_repeat, t('Pending Revision','बाकी रिवीजन'),
              t('स्मार्ट रिवीजन खोलें','Open spaced revision'), () =>
                _open(SpacedRevisionScreen(language: hi ? 'hi' : 'en')),
              badge: '${number(mentor['due_revision_count'])}'),
            _action(Icons.auto_awesome, t('Smart Study Plan','स्मार्ट स्टडी प्लान'),
              t('$pending कार्य बाकी',' $pending tasks pending'), () =>
                _open(SmartLearningScreen(language: hi ? 'hi' : 'en'))),
            _action(Icons.psychology, t('Personal Study Mentor','पर्सनल स्टडी मेंटर'),
              t('अपनी तैयारी की योजना देखें','Review your preparation plan'), () =>
                _open(AiStudyMentorScreen(language: hi ? 'hi' : 'en'))),
            _action(Icons.analytics, t('Detailed Performance','विस्तृत प्रदर्शन'),
              t('विषय और टॉपिक के अनुसार रिपोर्ट','Subject and topic reports'), () =>
                _open(PerformanceAnalyticsScreen(language: hi ? 'hi' : 'en'))),
            const SizedBox(height: 12),
            if (attempts == 0)
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Text(
                t('अभी आपका test data नहीं है। परीक्षा चुनें और Practice शुरू करें।',
                  'No test data yet. Choose an exam and start practising.')))),
            Text(t('आपकी प्रगति आपके submitted practice और mock tests पर आधारित है।',
              'Progress is based on your submitted practice and mock tests.'),
              style: Theme.of(context).textTheme.bodySmall),
          ])),
    );
  }

  Widget _metric(String label, String value, IconData icon) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
      Icon(icon, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 9),
      Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          Text(label, maxLines: 2, overflow: TextOverflow.ellipsis,
            style: Theme.of(context).textTheme.bodySmall),
        ])),
    ])));

  Widget _action(IconData icon, String title, String subtitle, VoidCallback onTap,
      {String? badge}) => Card(child: ListTile(
    leading: CircleAvatar(child: Icon(icon)), title: Text(title),
    subtitle: Text(subtitle), trailing: badge == null
      ? const Icon(Icons.chevron_right) : Chip(label: Text(badge)),
    onTap: onTap));
}
