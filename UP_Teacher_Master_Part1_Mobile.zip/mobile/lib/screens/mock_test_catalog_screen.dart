import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'mock_test_screen.dart';
import 'premium_membership_screen.dart';

/// Published, exam-specific mock templates. Template configuration is stored
/// in question_selection JSON so content staff can publish new patterns safely.
class MockTestCatalogScreen extends StatefulWidget {
  final String examId;
  final String examName;
  final String language;
  const MockTestCatalogScreen({super.key, required this.examId, required this.examName, this.language = 'en'});
  @override
  State<MockTestCatalogScreen> createState() => _MockTestCatalogScreenState();
}

class _MockTestCatalogScreenState extends State<MockTestCatalogScreen> {
  late Future<List<Map<String, dynamic>>> _future;
  bool get hi => widget.language == 'hi';
  bool _premiumAccess = false;
  String t(String h, String e) => hi ? h : e;
  @override
  void initState() { super.initState(); _future = _load(); _loadEntitlement(); }
  Future<void> _loadEntitlement() async { try { final value = await Supabase.instance.client.rpc('has_premium_access'); if (mounted) setState(() => _premiumAccess = value == true); } catch (_) {} }

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await Supabase.instance.client.from('mock_test_templates')
      .select('id,title_en,title_hi,description_en,description_hi,duration_minutes,question_count,total_marks,default_marks,default_negative_marks,language_mode,is_premium,question_selection,exam_pattern_id')
      .eq('exam_id', widget.examId).eq('is_active', true).order('display_order');
    return (rows as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(t('मॉक टेस्ट चुनें', 'Choose Mock Test'))),
    body: FutureBuilder<List<Map<String, dynamic>>>(future: _future, builder: (context, s) {
      if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (s.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('${t('मॉक टेस्ट लोड नहीं हो सके।','Could not load mock tests.')}\n${s.error}')));
      final items = s.data ?? [];
      if (items.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(t('इस परीक्षा के लिए मॉक टेस्ट जल्द उपलब्ध होंगे।','Mock tests for this exam will be available soon.'))));
      return RefreshIndicator(onRefresh: () async => setState(() => _future = _load()), child: ListView(
        padding: const EdgeInsets.all(16), children: [
          Card(color: const Color(0xFFEAF1FA), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.examName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Text(t('पब्लिश किए गए exam-pattern आधारित टेस्ट','Published exam-pattern based tests')),
          ]))),
          const SizedBox(height: 10),
          ...items.map((item) {
            final config = item['question_selection'] is Map ? Map<String, dynamic>.from(item['question_selection']) : <String, dynamic>{};
            final title = (hi ? item['title_hi'] : item['title_en']) ?? item['title_en'] ?? item['title_hi'] ?? 'Mock Test';
            final desc = (hi ? item['description_hi'] : item['description_en']) ?? item['description_en'] ?? item['description_hi'] ?? '';
            final premium = item['is_premium'] == true;
            final mode = (item['language_mode'] ?? 'bilingual').toString();
            return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Expanded(child: Text(title.toString(), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))), if (premium) const Chip(label: Text('PREMIUM'))]),
              if (desc.toString().isNotEmpty) Text(desc.toString()),
              const SizedBox(height: 12),
              Wrap(spacing: 14, runSpacing: 8, children: [
                _meta(Icons.quiz, '${item['question_count']} ${t('प्रश्न','Questions')}'),
                _meta(Icons.timer, '${item['duration_minutes']} ${t('मिनट','min')}'),
                _meta(Icons.stars, '${item['total_marks']} ${t('अंक','Marks')}'),
                _meta(Icons.translate, mode.toUpperCase()),
              ]),
              if (config['subject_distribution'] is Map) ...[
                const SizedBox(height: 8),
                Text(t('विषयवार प्रश्न वितरण उपलब्ध','Subject-wise question distribution configured'), style: const TextStyle(color: Colors.black54, fontSize: 12)),
              ],
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, child: FilledButton.icon(
                onPressed: premium && !_premiumAccess ? () { Navigator.of(context).push(MaterialPageRoute(builder: (_) => PremiumMembershipScreen(language: hi ? 'hi' : 'en'))); } : () {
                  Navigator.of(context).push(MaterialPageRoute(builder: (_) => MockTestScreen(
                    examId: widget.examId,
                    durationMinutes: (item['duration_minutes'] as num).toInt(),
                    questionCount: (item['question_count'] as num).toInt(),
                    language: mode == 'hindi' ? 'hi' : mode == 'english' ? 'en' : widget.language,
                    templateId: item['id'].toString(),
                    questionSelection: config,
                  )));
                }, icon: const Icon(Icons.play_arrow), label: Text(t('टेस्ट शुरू करें','Start Test')),
              )),
            ])));
          }),
        ],
      ));
    }),
  );

  Widget _meta(IconData icon, String value) => Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 16, color: const Color(0xFF174A7E)), const SizedBox(width: 4), Text(value, style: const TextStyle(fontSize: 12))]);
}
