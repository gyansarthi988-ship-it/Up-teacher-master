import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'auth_screen.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';

class AppGate extends StatelessWidget {
  const AppGate({super.key});

  Future<bool> _hasCompletedSetup(String userId) async {
    try {
      final row = await Supabase.instance.client
          .from('user_onboarding_preferences')
          .select('completed_at')
          .eq('user_id', userId)
          .maybeSingle();
      return row != null && row['completed_at'] != null;
    } catch (_) {
      // If the onboarding migration has not been applied yet, keep the app
      // usable and show the home screen rather than trapping signed-in users.
      return true;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final session = Supabase.instance.client.auth.currentSession;
        if (session == null) return const AuthScreen();
        return FutureBuilder<bool>(
          future: _hasCompletedSetup(session.user.id),
          builder: (context, setup) {
            if (setup.connectionState != ConnectionState.done) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            if (setup.data == false) return const OnboardingScreen();
            return const HomeScreen();
          },
        );
      },
    );
  }
}
