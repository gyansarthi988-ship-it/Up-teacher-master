import 'dart:async';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

/// FCM registration is optional until the Firebase Android app is configured.
/// Supabase RLS binds every device token to the currently authenticated user.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();
  StreamSubscription<String>? _tokenSub;
  StreamSubscription<RemoteMessage>? _messageSub;
  StreamSubscription<AuthState>? _authSub;
  bool _started = false;

  Future<void> initialize() async {
    if (_authSub != null) return;
    final client = Supabase.instance.client;
    if (client.auth.currentUser != null) unawaited(_register());
    _authSub = client.auth.onAuthStateChange.listen((state) {
      if (state.session != null) { unawaited(_register()); }
      else { unawaited(unregisterCurrentDevice()); }
    });
  }

  Future<void> _register() async {
    if (_started || Supabase.instance.client.auth.currentUser == null) return;
    try {
      if (Firebase.apps.isEmpty) await Firebase.initializeApp();
      FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);
      final messaging = FirebaseMessaging.instance;
      await messaging.requestPermission(alert: true, badge: true, sound: true);
      final token = await messaging.getToken();
      if (token != null) await _saveToken(token);
      _tokenSub = messaging.onTokenRefresh.listen((value) => _saveToken(value));
      _messageSub = FirebaseMessaging.onMessage.listen((message) {
        // Foreground messages are exposed to the app stream; UI can show an in-app banner.
        debugPrint('UPTM push received: ${message.messageId ?? message.data}');
      });
      _started = true;
    } catch (e) {
      // Missing google-services.json / Firebase config must not block app startup.
      debugPrint('Push notifications are not configured yet: $e');
    }
  }

  Future<void> _saveToken(String token) async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;
    if (user == null) return;
    await client.from('user_device_tokens').upsert({
      'user_id': user.id,
      'fcm_token': token,
      'platform': defaultTargetPlatform.name,
      'last_seen_at': DateTime.now().toUtc().toIso8601String(),
      'is_active': true,
    }, onConflict: 'fcm_token');
  }

  Future<void> unregisterCurrentDevice() async {
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null) {
        await Supabase.instance.client.from('user_device_tokens')
            .update({'is_active': false}).eq('fcm_token', token);
      }
      await _tokenSub?.cancel();
      await _messageSub?.cancel();
      _started = false;
    } catch (e) { debugPrint('Could not unregister push token: $e'); }
  }
}
