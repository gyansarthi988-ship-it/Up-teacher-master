import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app_config.dart';
import 'screens/app_gate.dart';
import 'notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.supabaseUrl.contains('YOUR_PROJECT') ||
      AppConfig.supabaseAnonKey.contains('YOUR_SUPABASE')) {
    runApp(const SetupRequiredApp());
    return;
  }
  await Supabase.initialize(
    url: AppConfig.supabaseUrl,
    anonKey: AppConfig.supabaseAnonKey,
    authOptions: const FlutterAuthClientOptions(
      authFlowType: AuthFlowType.pkce,
    ),
  );
  await NotificationService.instance.initialize();
  runApp(const UpTeacherMasterApp());
}

class SetupRequiredApp extends StatelessWidget {
  const SetupRequiredApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: appTheme,
    home: const Scaffold(
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'UP Teacher Master\\n\\nSetup required: configure SUPABASE_URL and SUPABASE_ANON_KEY using --dart-define. See README.md.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    ),
  );
}

final appTheme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174A7E)),
  scaffoldBackgroundColor: const Color(0xFFF6F8FC),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF174A7E),
    foregroundColor: Colors.white,
    centerTitle: false,
  ),
);

class UpTeacherMasterApp extends StatelessWidget {
  const UpTeacherMasterApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'UP Teacher Master',
    debugShowCheckedModeBanner: false,
    theme: appTheme,
    home: const AppGate(),
  );
}
