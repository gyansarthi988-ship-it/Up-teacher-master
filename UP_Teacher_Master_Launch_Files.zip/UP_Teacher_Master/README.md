# UP Teacher Master — Phase 1 Starter

A real Phase 1 project foundation containing:
- Flutter Android student app (phone OTP + Google OAuth through Supabase)
- Next.js web admin panel starter
- Supabase PostgreSQL migration with profiles, roles, exam catalogue, RLS and bootstrap admin support
- Environment templates and setup instructions

## Important
This is source code, not a prebuilt APK or a deployed service. You must create your own Supabase and Firebase/Google OAuth projects and add their credentials. Never commit `.env` files, service-role keys, keystores, or passwords.

## Prerequisites
- Flutter stable SDK and Android SDK
- Node.js 20+
- Supabase project
- Google Cloud OAuth client configured for Supabase
- A verified SMS provider configured in Supabase Auth for production OTP

## 1. Supabase setup
Supabase project URL and public anon key have been configured in this local package. The Phase 1 and Phase 2 migrations have already been run successfully in the owner's Supabase project. Do not run them again unless you intentionally reset the database.

In Authentication > URL Configuration, add redirect URL:
   `com.rsglobalacademy.upteachermaster://login-callback/`
4. Enable Phone provider and configure an SMS provider. For development, Supabase test phone numbers can be used.
5. Enable Google provider and enter the Google OAuth client ID/secret. Set the Supabase callback URL shown in the provider setup as an authorized redirect URI in Google Cloud.
The admin environment is in `admin/.env.local`; the Flutter app has the project URL and public anon key as defaults. The owner account has already been promoted to `super_admin`.

## 2. Flutter Android app
```bash
cd mobile
flutter create --platforms=android --org com.rsglobalacademy --project-name up_teacher_master .
# Ensure the generated AndroidManifest contains the deep link in mobile/README_ANDROID_BOOTSTRAP.md
flutter pub get
flutter run
```
Configure `mobile/lib/app_config.dart` with your Supabase URL and anon key, or pass:
```bash
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```
For release:
```bash
flutter build appbundle --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
Set up your own Android signing key before publishing. Do not use a debug-signed build for Play Store.

## 3. Web admin panel
```bash
cd admin
cp .env.example .env.local
# Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run dev
```
Open http://localhost:3000. The admin panel provides email/password sign-in, a protected dashboard and the Phase 2 Content Studio. Admin role is checked against `user_roles` in Supabase.

## 4. Ownership checklist
- Create Supabase, Google Cloud, Play Console and domain accounts in your name.
- Keep recovery email/phone under your control.
- Store secrets in a password manager.
- Enable MFA on provider accounts.
- Keep source code in a private Git repository owned by you.
- Back up database migrations and signing keys securely.

## Phase 1 boundaries
Included: project foundation, bilingual app shell, authentication integration, exam selection shell, admin login/dashboard shell, database foundation and RLS.
Not yet included: question bank, Excel importer, mock-test engine, payment/subscription system, push notifications, production APK/AAB signing, live deployment and Play Store publication.


## Phase 2 — Content Management System

Phase 2 adds syllabus management, bilingual MCQ authoring, review/publish, XLSX/XLS/CSV bulk import and private PDF uploads. Apply `supabase/migrations/0002_phase2_content_cms.sql` after Phase 1 migration. See `docs/PHASE2_CONTENT_CMS.md` and use `UP_Teacher_Master_Question_Import_Template.xlsx` for bulk imports. The admin Content Studio is available after the Next.js admin panel is configured. The student Flutter app includes an exam syllabus browser. Correct answers remain protected; test scoring and student PDF signed-download delivery are later-phase work.

## GitHub Cloud Build (first test APK)
The repository includes `.github/workflows/android-apk.yml`. Add GitHub Actions repository secrets `SUPABASE_URL` and `SUPABASE_ANON_KEY`, then run **Actions → Build UP Teacher Master Android APK → Run workflow**. The result is a debug APK artifact for device testing, not a signed Play Store release. See `docs/GITHUB_CLOUD_BUILD_SETUP.md`.

## Phase 3: Practice Engine

Phase 3 adds topic-wise bilingual MCQ practice, answer navigation, secure server-side scoring, negative marking, attempt records and post-submission answer explanations. Apply `supabase/migrations/0003_practice_mock_engine.sql` in Supabase after Phase 1 and Phase 2. See `docs/PHASE3_PRACTICE_ENGINE.md` and `docs/PHASE3_ACCEPTANCE.md`.
