import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, "Content-Type": "application/json" },
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const aiKey = Deno.env.get("OPENAI_API_KEY");
  if (!url || !anon || !service || !aiKey) return json({ error: "Server is not configured. Contact administrator." }, 503);
  const authHeader = req.headers.get("Authorization") ?? "";
  const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
  const { data: { user }, error: authError } = await userClient.auth.getUser();
  if (authError || !user) return json({ error: "Authentication required" }, 401);
  let body: { question?: string; subject?: string; exam_id?: string | null; language?: string };
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
  const question = String(body.question ?? "").trim();
  if (question.length < 8 || question.length > 3000) return json({ error: "Question must contain 8–3000 characters." }, 400);
  const subject = String(body.subject ?? "General").trim().slice(0, 100);
  const language = ["hi", "en"].includes(String(body.language)) ? String(body.language) : "auto";
  const admin = createClient(url, service);
  const since = new Date(Date.now() - 60 * 60 * 1000).toISOString();
  const { count: recentCount, error: countError } = await admin.from("study_doubts")
    .select("id", { count: "exact", head: true }).eq("user_id", user.id).gte("created_at", since);
  if (countError) return json({ error: "Could not verify request limit." }, 500);
  if ((recentCount ?? 0) >= 5) return json({ error: "Hourly limit reached. Please try again later." }, 429);
  const { data: row, error: insertError } = await admin.from("study_doubts").insert({
    user_id: user.id, exam_id: body.exam_id || null, subject, question, answer_language: language, status: "pending",
  }).select("id").single();
  if (insertError || !row) return json({ error: "Could not save your doubt." }, 500);
  try {
    const system = `You are UP Teacher Master, a careful bilingual tutor for UP Super TET, UP TGT, UP PRT and UP Junior teacher recruitment exams. Explain clearly at the learner's level. If language is hi, answer in simple Hindi; if en, answer in clear English; if auto, match the question language. Structure: direct answer, step-by-step explanation, one exam-oriented example, and a short takeaway. For uncertain or disputed facts, say so and recommend checking the official syllabus/source. Never invent official notifications, answer keys, dates or citations. Question subject: ${subject}.`;
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST", headers: { Authorization: `Bearer ${aiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("OPENAI_MODEL") || "gpt-4o-mini", temperature: 0.25,
        messages: [{ role: "system", content: system }, { role: "user", content: question }], max_tokens: 900 }),
    });
    const result = await response.json();
    if (!response.ok) throw new Error("AI provider request failed");
    const answer = result.choices?.[0]?.message?.content;
    if (!answer) throw new Error("Empty AI response");
    await admin.from("study_doubts").update({ answer, status: "answered", provider_model: result.model ?? null,
      token_usage: result.usage ?? {}, answered_at: new Date().toISOString() }).eq("id", row.id).eq("user_id", user.id);
    return json({ id: row.id, answer, status: "answered" });
  } catch (_error) {
    await admin.from("study_doubts").update({ status: "failed" }).eq("id", row.id).eq("user_id", user.id);
    return json({ error: "Your doubt was saved, but the AI answer could not be generated. Please try again later.", id: row.id }, 502);
  }
});
