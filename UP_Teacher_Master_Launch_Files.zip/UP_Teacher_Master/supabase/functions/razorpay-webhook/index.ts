import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const enc = new TextEncoder();
async function hmac(secret: string, body: string) {
  const key = await crypto.subtle.importKey('raw', enc.encode(secret), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const bytes = new Uint8Array(await crypto.subtle.sign('HMAC', key, enc.encode(body)));
  return [...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function safeEqual(a: string,b: string) { if(a.length!==b.length) return false; let v=0; for(let i=0;i<a.length;i++) v |= a.charCodeAt(i)^b.charCodeAt(i); return v===0; }
Deno.serve(async (req) => {
  if(req.method!=='POST') return new Response('Method not allowed',{status:405});
  const raw=await req.text(); const signature=req.headers.get('x-razorpay-signature') ?? '';
  const secret=Deno.env.get('RAZORPAY_WEBHOOK_SECRET') ?? '';
  if(!secret || !signature || !safeEqual(await hmac(secret,raw),signature)) return new Response('Invalid signature',{status:401});
  let event:any; try { event=JSON.parse(raw); } catch { return new Response('Invalid JSON',{status:400}); }
  if(event.event!=='payment.captured') return new Response('Event ignored',{status:200});
  const payment=event.payload?.payment?.entity;
  if(!payment?.order_id || !payment?.id) return new Response('Missing payment identifiers',{status:400});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const {data:order,error}=await db.from('payment_orders').select('id,user_id,plan_id,amount_paise,currency,status').eq('provider_order_id',payment.order_id).maybeSingle();
  if(error || !order) return new Response('Order not found',{status:404});
  if(Number(payment.amount)!==Number(order.amount_paise) || payment.currency!==order.currency) return new Response('Amount/currency mismatch',{status:409});
  if(order.status==='paid') return new Response('Already processed',{status:200});
  const {data:plan,error:planErr}=await db.from('membership_plans').select('duration_days').eq('id',order.plan_id).single();
  if(planErr || !plan) return new Response('Plan not found',{status:404});
  const {error:updateErr}=await db.from('payment_orders').update({status:'paid',provider_payment_id:payment.id,paid_at:new Date().toISOString(),provider_payload:{event_id:event.id,payment_id:payment.id}}).eq('id',order.id).neq('status','paid');
  if(updateErr) return new Response('Could not update order',{status:500});
  const {error:subErr}=await db.from('user_subscriptions').upsert({user_id:order.user_id,plan_id:order.plan_id,payment_order_id:order.id,starts_at:new Date().toISOString(),expires_at:new Date(Date.now()+Number(plan.duration_days)*86400000).toISOString(),status:'active'}, {onConflict:'payment_order_id',ignoreDuplicates:true});
  if(subErr) return new Response('Payment recorded; membership activation needs reconciliation',{status:500});
  return new Response('Membership activated',{status:200});
});
