import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1';
import { JWT } from 'npm:google-auth-library@9.15.0';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const anon = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const authHeader = req.headers.get('Authorization') ?? '';
    const userClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } });
    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) return json({ error: 'Authentication required' }, 401);
    const { data: admin, error: roleError } = await userClient.rpc('is_admin');
    if (roleError || admin !== true) return json({ error: 'Admin access required' }, 403);

    const { announcement_id } = await req.json();
    if (typeof announcement_id !== 'string') return json({ error: 'announcement_id is required' }, 400);
    const db = createClient(url, serviceKey);
    const { data: notice, error: noticeError } = await db.from('announcements')
      .select('id,title_en,title_hi,body_en,body_hi,is_published,target_exam_id,expires_at')
      .eq('id', announcement_id).single();
    if (noticeError || !notice || !notice.is_published) return json({ error: 'Published announcement not found' }, 404);
    if (notice.expires_at && new Date(notice.expires_at).getTime() <= Date.now()) return json({ error: 'Announcement has expired' }, 400);

    const serviceAccountRaw = Deno.env.get('FIREBASE_SERVICE_ACCOUNT_JSON');
    const projectId = Deno.env.get('FIREBASE_PROJECT_ID');
    if (!serviceAccountRaw || !projectId) return json({ error: 'Firebase server credentials are not configured' }, 503);
    const serviceAccount = JSON.parse(serviceAccountRaw);
    const jwt = new JWT({ email: serviceAccount.client_email, key: serviceAccount.private_key, scopes: ['https://www.googleapis.com/auth/firebase.messaging'] });
    const auth = await jwt.authorize();
    if (!auth.access_token) return json({ error: 'Could not obtain Firebase access token' }, 502);

    let tokenQuery = db.from('user_device_tokens').select('fcm_token').eq('is_active', true);
    if (notice.target_exam_id) {
      const { data: selections } = await db.from('user_exam_selections').select('user_id').eq('exam_id', notice.target_exam_id);
      const ids = (selections ?? []).map((x) => x.user_id);
      if (!ids.length) return json({ sent: 0, failed: 0, message: 'No users selected this exam' });
      tokenQuery = tokenQuery.in('user_id', ids);
    }
    const { data: tokenRows, error: tokenError } = await tokenQuery.limit(5000);
    if (tokenError) return json({ error: tokenError.message }, 500);
    const tokens = [...new Set((tokenRows ?? []).map((x) => x.fcm_token))];
    let sent = 0; let failed = 0;
    const title = notice.title_en;
    const body = notice.body_en.slice(0, 500);
    for (const token of tokens) {
      const response = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
        method: 'POST', headers: { Authorization: `Bearer ${auth.access_token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: { token, notification: { title, body }, data: { announcement_id: notice.id, type: 'announcement' }, android: { priority: 'HIGH', notification: { channel_id: 'uptm_updates' } } } }),
      });
      if (response.ok) sent++; else failed++;
    }
    return json({ sent, failed, targeted_tokens: tokens.length });
  } catch (e) { return json({ error: e instanceof Error ? e.message : 'Unexpected error' }, 500); }
});
