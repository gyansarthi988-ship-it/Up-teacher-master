-- Phase 3W: user-owned syllabus topic progress
create table if not exists public.user_topic_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  syllabus_item_id uuid not null references public.syllabus_items(id) on delete cascade,
  status text not null default 'not_started'
    check (status in ('not_started','in_progress','completed','revise')),
  confidence smallint not null default 0 check (confidence between 0 and 5),
  notes text,
  updated_at timestamptz not null default now(),
  primary key(user_id, syllabus_item_id)
);
alter table public.user_topic_progress enable row level security;
drop policy if exists "users read own topic progress" on public.user_topic_progress;
create policy "users read own topic progress" on public.user_topic_progress
for select to authenticated using (user_id = auth.uid());
drop policy if exists "users insert own topic progress" on public.user_topic_progress;
create policy "users insert own topic progress" on public.user_topic_progress
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "users update own topic progress" on public.user_topic_progress;
create policy "users update own topic progress" on public.user_topic_progress
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update on public.user_topic_progress to authenticated;
