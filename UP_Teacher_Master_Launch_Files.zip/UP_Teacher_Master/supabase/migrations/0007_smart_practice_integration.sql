-- Phase 3E: connect learning plans and the wrong-question notebook to live practice.
-- Each submitted response updates the learner's personal revision notebook.
create or replace function public.sync_wrong_question_notebook()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid;
  v_exam uuid;
begin
  select a.user_id, a.exam_id into v_user, v_exam
  from public.test_attempts a
  where a.id = new.attempt_id;

  if v_user is null or new.selected_option_id is null then
    return new;
  end if;

  if new.is_correct = false then
    insert into public.wrong_question_bookmarks
      (user_id, exam_id, question_id, wrong_count, last_wrong_at, next_review_at, mastered)
    values
      (v_user, v_exam, new.question_id, 1, coalesce(new.answered_at, now()), current_date + 1, false)
    on conflict (user_id, question_id) do update set
      exam_id = excluded.exam_id,
      wrong_count = public.wrong_question_bookmarks.wrong_count + 1,
      last_wrong_at = excluded.last_wrong_at,
      next_review_at = current_date + 1,
      mastered = false;
  else
    update public.wrong_question_bookmarks
       set next_review_at = current_date + 3,
           mastered = false
     where user_id = v_user and question_id = new.question_id;
  end if;

  return new;
end;
$$;

revoke all on function public.sync_wrong_question_notebook() from public;

drop trigger if exists trg_sync_wrong_question_notebook on public.test_attempt_responses;
create trigger trg_sync_wrong_question_notebook
  after insert on public.test_attempt_responses
  for each row execute function public.sync_wrong_question_notebook();

-- A narrow RPC returns only due, unmastered questions owned by the current user.
create or replace function public.get_my_due_wrong_question_ids(p_exam_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_ids jsonb;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_exam_id is null then raise exception 'Exam is required'; end if;

  select coalesce(jsonb_agg(question_id order by next_review_at, last_wrong_at desc), '[]'::jsonb)
    into v_ids
  from public.wrong_question_bookmarks
  where user_id = v_user
    and exam_id = p_exam_id
    and mastered = false
    and next_review_at <= current_date;

  return jsonb_build_object('question_ids', v_ids, 'due_count', jsonb_array_length(v_ids));
end;
$$;

revoke all on function public.get_my_due_wrong_question_ids(uuid) from public;
grant execute on function public.get_my_due_wrong_question_ids(uuid) to authenticated;
