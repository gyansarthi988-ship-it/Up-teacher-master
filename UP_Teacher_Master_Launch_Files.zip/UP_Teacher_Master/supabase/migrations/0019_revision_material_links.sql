-- Phase 3Y: expose question topic linkage in the authenticated revision queue.
create or replace function public.get_my_revision_queue(p_exam_id uuid, p_limit integer default 30)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_user uuid:=auth.uid(); v_data jsonb;
begin
 if v_user is null then raise exception 'Authentication required'; end if;
 if p_exam_id is null then raise exception 'Exam is required'; end if;
 select coalesce(jsonb_agg(jsonb_build_object(
   'question_id',q.id,'topic_id',q.topic_id,
   'question_hi',q.question_hi,'question_en',q.question_en,
   'explanation_hi',e.explanation_hi,'explanation_en',e.explanation_en,
   'wrong_count',w.wrong_count,'next_review_at',w.next_review_at,
   'review_interval_days',w.review_interval_days,'successful_reviews',w.successful_reviews
 ) order by w.next_review_at,w.wrong_count desc),'[]'::jsonb) into v_data
 from public.wrong_question_bookmarks w
 join public.questions q on q.id=w.question_id
 left join public.question_explanations e on e.question_id=q.id
 where w.user_id=v_user and w.exam_id=p_exam_id and w.mastered=false and w.next_review_at<=current_date
 and q.status='published'
 limit greatest(1,least(coalesce(p_limit,30),100));
 return jsonb_build_object('items',v_data,'due_count',jsonb_array_length(v_data));
end; $$;
grant execute on function public.get_my_revision_queue(uuid,integer) to authenticated;
