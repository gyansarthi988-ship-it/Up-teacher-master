-- Phase 3: secure student practice and mock-test attempts.
-- Correct answers remain hidden from direct table reads; scoring happens server-side.

create table if not exists public.test_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete restrict,
  attempt_mode text not null default 'practice' check (attempt_mode in ('practice','mock')),
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  total_questions int not null default 0,
  attempted_questions int not null default 0,
  correct_answers int not null default 0,
  wrong_answers int not null default 0,
  unanswered int not null default 0,
  score numeric(10,2) not null default 0,
  max_score numeric(10,2) not null default 0,
  status text not null default 'in_progress' check (status in ('in_progress','submitted'))
);

create table if not exists public.test_attempt_responses (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.test_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete restrict,
  selected_option_id uuid references public.question_options(id) on delete set null,
  is_correct boolean not null default false,
  marks_awarded numeric(10,2) not null default 0,
  answered_at timestamptz not null default now(),
  unique(attempt_id, question_id)
);

create index if not exists test_attempts_user_date_idx on public.test_attempts(user_id, started_at desc);
create index if not exists test_attempt_responses_attempt_idx on public.test_attempt_responses(attempt_id);

alter table public.test_attempts enable row level security;
alter table public.test_attempt_responses enable row level security;

create policy "students read own attempts" on public.test_attempts
for select to authenticated using (user_id = auth.uid() or public.can_manage_content());
create policy "students read own attempt responses" on public.test_attempt_responses
for select to authenticated using (
  exists(select 1 from public.test_attempts a where a.id = attempt_id and a.user_id = auth.uid())
  or public.can_manage_content()
);

-- Atomic submission and scoring. Client sends only selected option IDs, never the answer key.
create or replace function public.submit_test_attempt(
  p_exam_id uuid,
  p_answers jsonb,
  p_mode text default 'practice'
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_attempt_id uuid;
  v_item jsonb;
  v_qid uuid;
  v_oid uuid;
  v_correct_option uuid;
  v_marks numeric(10,2);
  v_negative numeric(10,2);
  v_is_correct boolean;
  v_awarded numeric(10,2);
  v_total int := 0;
  v_attempted int := 0;
  v_correct int := 0;
  v_wrong int := 0;
  v_score numeric(10,2) := 0;
  v_max numeric(10,2) := 0;
  v_details jsonb := '[]'::jsonb;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if p_mode not in ('practice','mock') then raise exception 'Invalid attempt mode'; end if;
  if jsonb_typeof(p_answers) <> 'array' or jsonb_array_length(p_answers) = 0 then
    raise exception 'Answers must be a non-empty JSON array';
  end if;
  if jsonb_array_length(p_answers) > 300 then raise exception 'Maximum 300 questions per attempt'; end if;

  insert into public.test_attempts(user_id, exam_id, attempt_mode, total_questions)
  values(auth.uid(), p_exam_id, p_mode, jsonb_array_length(p_answers))
  returning id into v_attempt_id;

  for v_item in select value from jsonb_array_elements(p_answers)
  loop
    v_qid := (v_item->>'question_id')::uuid;
    v_oid := nullif(v_item->>'option_id','')::uuid;
    select a.correct_option_id, q.marks, q.negative_marks
      into v_correct_option, v_marks, v_negative
    from public.questions q
    join public.question_answers a on a.question_id = q.id
    where q.id = v_qid and q.exam_id = p_exam_id and q.status = 'published';
    if not found then raise exception 'Question is unavailable or not published'; end if;
    if v_oid is not null and not exists(
      select 1 from public.question_options o where o.id = v_oid and o.question_id = v_qid
    ) then raise exception 'Selected option does not belong to question'; end if;

    v_total := v_total + 1;
    v_max := v_max + v_marks;
    v_is_correct := v_oid is not null and v_oid = v_correct_option;
    if v_oid is not null then v_attempted := v_attempted + 1; end if;
    if v_is_correct then
      v_correct := v_correct + 1; v_awarded := v_marks;
    elsif v_oid is not null then
      v_wrong := v_wrong + 1; v_awarded := -v_negative;
    else
      v_awarded := 0;
    end if;
    v_score := v_score + v_awarded;

    insert into public.test_attempt_responses(attempt_id, question_id, selected_option_id, is_correct, marks_awarded)
    values(v_attempt_id, v_qid, v_oid, v_is_correct, v_awarded);

    v_details := v_details || jsonb_build_array(jsonb_build_object(
      'question_id', v_qid,
      'selected_option_id', v_oid,
      'correct_option_id', v_correct_option,
      'is_correct', v_is_correct,
      'marks_awarded', v_awarded,
      'explanation_hi', (select explanation_hi from public.question_explanations where question_id = v_qid),
      'explanation_en', (select explanation_en from public.question_explanations where question_id = v_qid)
    ));
  end loop;

  update public.test_attempts set
    submitted_at = now(), total_questions = v_total, attempted_questions = v_attempted,
    correct_answers = v_correct, wrong_answers = v_wrong, unanswered = v_total - v_attempted,
    score = v_score, max_score = v_max, status = 'submitted'
  where id = v_attempt_id;

  return jsonb_build_object(
    'attempt_id', v_attempt_id, 'total_questions', v_total,
    'attempted_questions', v_attempted, 'correct_answers', v_correct,
    'wrong_answers', v_wrong, 'unanswered', v_total - v_attempted,
    'score', v_score, 'max_score', v_max, 'details', v_details
  );
end;
$$;

revoke all on function public.submit_test_attempt(uuid,jsonb,text) from public;
grant execute on function public.submit_test_attempt(uuid,jsonb,text) to authenticated;

-- No direct client writes: all submissions pass through the validated RPC.
revoke insert, update, delete on public.test_attempts from anon, authenticated;
revoke insert, update, delete on public.test_attempt_responses from anon, authenticated;
