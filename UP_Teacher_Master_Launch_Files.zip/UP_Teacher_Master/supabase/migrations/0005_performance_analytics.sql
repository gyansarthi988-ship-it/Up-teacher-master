-- Phase 3C: student performance analytics. Reads only the signed-in user's submitted attempts.
create index if not exists test_attempts_user_submitted_idx
  on public.test_attempts(user_id, submitted_at desc) where status = 'submitted';

create or replace function public.get_my_performance_analytics(p_exam_id uuid default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_result jsonb;
begin
  if v_user is null then raise exception 'Authentication required'; end if;

  with my_attempts as (
    select a.* from public.test_attempts a
    where a.user_id = v_user and a.status = 'submitted'
      and (p_exam_id is null or a.exam_id = p_exam_id)
  ),
  overall as (
    select count(*)::int attempts,
      coalesce(sum(total_questions),0)::int questions_seen,
      coalesce(sum(attempted_questions),0)::int attempted,
      coalesce(sum(correct_answers),0)::int correct,
      coalesce(sum(wrong_answers),0)::int wrong,
      coalesce(sum(unanswered),0)::int unanswered,
      coalesce(sum(score),0)::numeric(12,2) score,
      coalesce(sum(max_score),0)::numeric(12,2) max_score,
      coalesce(round(100.0 * sum(correct_answers) / nullif(sum(attempted_questions),0),2),0) accuracy,
      coalesce(round(avg(100.0 * score / nullif(max_score,0)),2),0) average_percentage,
      max(submitted_at) last_attempt_at
    from my_attempts
  ),
  trend as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'attempt_id', id, 'submitted_at', submitted_at, 'mode', attempt_mode,
      'score', score, 'max_score', max_score,
      'percentage', round(100.0 * score / nullif(max_score,0),2),
      'correct', correct_answers, 'wrong', wrong_answers, 'unanswered', unanswered
    ) order by submitted_at), '[]'::jsonb) items
    from (select * from my_attempts order by submitted_at desc limit 20) x
  ),
  topic_stats as (
    select q.topic_id, t.name_en, t.name_hi,
      count(*)::int questions, count(*) filter (where r.selected_option_id is not null)::int attempted,
      count(*) filter (where r.is_correct)::int correct,
      count(*) filter (where r.selected_option_id is not null and not r.is_correct)::int wrong,
      round(100.0 * count(*) filter (where r.is_correct) / nullif(count(*) filter (where r.selected_option_id is not null),0),2) accuracy
    from public.test_attempt_responses r
    join my_attempts a on a.id = r.attempt_id
    join public.questions q on q.id = r.question_id
    left join public.topics t on t.id = q.topic_id
    where q.topic_id is not null
    group by q.topic_id, t.name_en, t.name_hi
  ),
  topics as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'topic_id', topic_id, 'name_en', name_en, 'name_hi', name_hi,
      'questions', questions, 'attempted', attempted, 'correct', correct,
      'wrong', wrong, 'accuracy', accuracy,
      'weak', coalesce(accuracy,0) < 50 and attempted >= 3
    ) order by accuracy asc nulls first, attempted desc), '[]'::jsonb) items
    from topic_stats
  ),
  subject_stats as (
    select s.id subject_id, s.name_en, s.name_hi,
      count(*)::int questions,
      count(*) filter (where r.selected_option_id is not null)::int attempted,
      count(*) filter (where r.is_correct)::int correct,
      round(100.0 * count(*) filter (where r.is_correct) / nullif(count(*) filter (where r.selected_option_id is not null),0),2) accuracy
    from public.test_attempt_responses r
    join my_attempts a on a.id = r.attempt_id
    join public.questions q on q.id = r.question_id
    join public.subjects s on s.id = q.subject_id
    group by s.id, s.name_en, s.name_hi
  ),
  subjects as (
    select coalesce(jsonb_agg(jsonb_build_object(
      'subject_id', subject_id, 'name_en', name_en, 'name_hi', name_hi,
      'questions', questions, 'attempted', attempted, 'correct', correct, 'accuracy', accuracy
    ) order by accuracy asc nulls first), '[]'::jsonb) items from subject_stats
  )
  select jsonb_build_object(
    'summary', (select to_jsonb(overall) from overall),
    'trend', (select items from trend),
    'topics', (select items from topics),
    'subjects', (select items from subjects)
  ) into v_result;
  return v_result;
end;
$$;

revoke all on function public.get_my_performance_analytics(uuid) from public;
grant execute on function public.get_my_performance_analytics(uuid) to authenticated;
