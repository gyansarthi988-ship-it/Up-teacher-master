-- Phase 3B: configurable mock-test blueprints managed by content administrators.
create table if not exists public.mock_test_templates (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  exam_pattern_id uuid references public.exam_patterns(id) on delete set null,
  title_en text not null,
  title_hi text not null,
  description_en text,
  description_hi text,
  duration_minutes int not null check (duration_minutes between 1 and 600),
  question_count int not null check (question_count between 1 and 300),
  total_marks numeric(8,2) not null default 0,
  default_marks numeric(7,2) not null default 1,
  default_negative_marks numeric(7,2) not null default 0,
  language_mode text not null default 'bilingual' check (language_mode in ('hindi','english','bilingual')),
  question_selection jsonb not null default '{"strategy":"random","published_only":true}'::jsonb,
  is_premium boolean not null default false,
  is_active boolean not null default false,
  display_order int not null default 0,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists mock_test_templates_exam_active_idx
  on public.mock_test_templates(exam_id, is_active, display_order);
alter table public.mock_test_templates enable row level security;
create policy "active mock templates visible" on public.mock_test_templates
for select to authenticated using (is_active = true or public.can_manage_content());
create policy "content staff manage mock templates" on public.mock_test_templates
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());
