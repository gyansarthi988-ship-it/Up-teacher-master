-- Phase 3D: personalised study plan, spaced revision and wrong-question notebook.
create table if not exists public.learning_plan_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  topic_id uuid references public.topics(id) on delete set null,
  task_type text not null check (task_type in ('study_topic','revise_topic','retry_wrong')),
  scheduled_for date not null,
  title_hi text not null,
  title_en text not null,
  target_questions int not null default 10 check (target_questions between 1 and 100),
  status text not null default 'pending' check (status in ('pending','completed','skipped')),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, exam_id, topic_id, task_type, scheduled_for)
);
create index if not exists learning_plan_user_date_idx on public.learning_plan_tasks(user_id, scheduled_for, status);

create table if not exists public.wrong_question_bookmarks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  wrong_count int not null default 1,
  last_wrong_at timestamptz not null default now(),
  next_review_at date not null default current_date + 1,
  mastered boolean not null default false,
  created_at timestamptz not null default now(),
  unique(user_id, question_id)
);
create index if not exists wrong_book_user_review_idx on public.wrong_question_bookmarks(user_id, next_review_at) where mastered = false;

alter table public.learning_plan_tasks enable row level security;
alter table public.wrong_question_bookmarks enable row level security;
create policy "students manage own learning tasks" on public.learning_plan_tasks
for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "students manage own wrong notebook" on public.wrong_question_bookmarks
for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Generate a 7-day plan from recent submitted results. Weakest topics receive
-- focused practice followed by revision on day 1, 3 and 7.
create or replace function public.generate_my_learning_plan(p_exam_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_user uuid := auth.uid(); v_count int := 0;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_exam_id is null then raise exception 'Exam is required'; end if;

  insert into public.wrong_question_bookmarks(user_id, exam_id, question_id, wrong_count, last_wrong_at, next_review_at)
  select v_user, a.exam_id, r.question_id, count(*)::int, max(r.answered_at), current_date + 1
  from public.test_attempts a join public.test_attempt_responses r on r.attempt_id = a.id
  where a.user_id = v_user and a.exam_id = p_exam_id and a.status = 'submitted'
    and r.selected_option_id is not null and r.is_correct = false
  group by a.exam_id, r.question_id
  on conflict(user_id, question_id) do update set
    wrong_count = greatest(public.wrong_question_bookmarks.wrong_count, excluded.wrong_count),
    last_wrong_at = greatest(public.wrong_question_bookmarks.last_wrong_at, excluded.last_wrong_at),
    next_review_at = least(public.wrong_question_bookmarks.next_review_at, excluded.next_review_at),
    mastered = false;

  with topic_stats as (
    select q.topic_id, t.name_hi, t.name_en,
      count(*) filter(where r.selected_option_id is not null)::int attempted,
      count(*) filter(where r.is_correct)::int correct
    from public.test_attempts a join public.test_attempt_responses r on r.attempt_id=a.id
    join public.questions q on q.id=r.question_id left join public.topics t on t.id=q.topic_id
    where a.user_id=v_user and a.exam_id=p_exam_id and a.status='submitted' and q.topic_id is not null
    group by q.topic_id,t.name_hi,t.name_en
    having count(*) filter(where r.selected_option_id is not null) >= 2
  ), weak as (
    select *, coalesce(100.0*correct/nullif(attempted,0),0) accuracy,
      row_number() over(order by coalesce(100.0*correct/nullif(attempted,0),0) asc, attempted desc) rn
    from topic_stats
  ), chosen as (select * from weak where accuracy < 70 order by rn limit 5),
  days as (select * from (values (0,'study_topic'),(1,'revise_topic'),(3,'revise_topic'),(6,'revise_topic')) d(day_no,task_type))
  insert into public.learning_plan_tasks(user_id,exam_id,topic_id,task_type,scheduled_for,title_hi,title_en,target_questions)
  select v_user,p_exam_id,c.topic_id,d.task_type,current_date+d.day_no,
    case when d.task_type='study_topic' then 'कमजोर टॉपिक पढ़ें: '||coalesce(c.name_hi,c.name_en,'टॉपिक') else 'रिवीजन करें: '||coalesce(c.name_hi,c.name_en,'टॉपिक') end,
    case when d.task_type='study_topic' then 'Study weak topic: '||coalesce(c.name_en,c.name_hi,'Topic') else 'Revise: '||coalesce(c.name_en,c.name_hi,'Topic') end,
    case when d.task_type='study_topic' then 15 else 10 end
  from chosen c cross join days d
  on conflict(user_id,exam_id,topic_id,task_type,scheduled_for) do nothing;
  get diagnostics v_count = row_count;
  return public.get_my_learning_plan(p_exam_id);
end; $$;

create or replace function public.get_my_learning_plan(p_exam_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_user uuid := auth.uid(); v_result jsonb;
begin
 if v_user is null then raise exception 'Authentication required'; end if;
 select jsonb_build_object(
  'tasks', coalesce((select jsonb_agg(jsonb_build_object('id',id,'topic_id',topic_id,'task_type',task_type,'scheduled_for',scheduled_for,'title_hi',title_hi,'title_en',title_en,'target_questions',target_questions,'status',status) order by scheduled_for,created_at) from public.learning_plan_tasks where user_id=v_user and exam_id=p_exam_id and scheduled_for between current_date and current_date+6),'[]'::jsonb),
  'wrong_questions', coalesce((select jsonb_agg(jsonb_build_object('id',w.id,'question_id',q.id,'question_hi',q.question_hi,'question_en',q.question_en,'wrong_count',w.wrong_count,'next_review_at',w.next_review_at,'mastered',w.mastered,'explanation_hi',e.explanation_hi,'explanation_en',e.explanation_en) order by w.mastered,w.next_review_at) from public.wrong_question_bookmarks w join public.questions q on q.id=w.question_id left join public.question_explanations e on e.question_id=q.id where w.user_id=v_user and w.exam_id=p_exam_id),'[]'::jsonb)
 ) into v_result;
 return v_result;
end; $$;

revoke all on function public.generate_my_learning_plan(uuid) from public;
revoke all on function public.get_my_learning_plan(uuid) from public;
grant execute on function public.generate_my_learning_plan(uuid) to authenticated;
grant execute on function public.get_my_learning_plan(uuid) to authenticated;
