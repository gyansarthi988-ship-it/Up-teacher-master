-- Phase 3J: secure premium membership, plans, payment ledger and entitlements
create extension if not exists pgcrypto;

create table if not exists public.membership_plans (
 id uuid primary key default gen_random_uuid(), code text not null unique,
 name_en text not null, name_hi text not null, description_en text, description_hi text,
 duration_days int not null check(duration_days between 1 and 3660),
 price_paise bigint not null check(price_paise >= 0), currency text not null default 'INR' check(currency='INR'),
 is_active boolean not null default true, display_order int not null default 0,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.payment_orders (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 plan_id uuid not null references public.membership_plans(id), provider text not null default 'razorpay',
 provider_order_id text unique, amount_paise bigint not null check(amount_paise >= 0), currency text not null default 'INR',
 status text not null default 'created' check(status in ('created','paid','failed','refunded','cancelled')),
 provider_payment_id text unique, provider_payload jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now(), paid_at timestamptz
);

create table if not exists public.user_subscriptions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 plan_id uuid references public.membership_plans(id), payment_order_id uuid unique references public.payment_orders(id),
 starts_at timestamptz not null default now(), expires_at timestamptz not null,
 status text not null default 'active' check(status in ('active','expired','cancelled','revoked')),
 granted_by uuid references auth.users(id), grant_reason text,
 created_at timestamptz not null default now(), check(expires_at > starts_at)
);
create index if not exists user_subscriptions_user_expiry_idx on public.user_subscriptions(user_id, expires_at desc);
create index if not exists payment_orders_user_created_idx on public.payment_orders(user_id, created_at desc);

alter table public.membership_plans enable row level security;
alter table public.payment_orders enable row level security;
alter table public.user_subscriptions enable row level security;

drop policy if exists membership_plans_read_active on public.membership_plans;
create policy membership_plans_read_active on public.membership_plans for select to authenticated using(is_active or public.is_admin());
drop policy if exists membership_plans_admin_manage on public.membership_plans;
create policy membership_plans_admin_manage on public.membership_plans for all to authenticated using(public.is_admin()) with check(public.is_admin());
drop policy if exists payment_orders_read_own on public.payment_orders;
create policy payment_orders_read_own on public.payment_orders for select to authenticated using(user_id=auth.uid() or public.is_admin());
drop policy if exists subscriptions_read_own on public.user_subscriptions;
create policy subscriptions_read_own on public.user_subscriptions for select to authenticated using(user_id=auth.uid() or public.is_admin());
-- No client insert/update/delete policies for payment or subscription ledgers.

create or replace function public.has_premium_access()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.user_subscriptions s where s.user_id=auth.uid() and s.status='active' and s.starts_at<=now() and s.expires_at>now()); $$;
grant execute on function public.has_premium_access() to authenticated;

create or replace function public.get_my_membership()
returns jsonb language sql stable security definer set search_path=public
as $$
 select jsonb_build_object(
  'is_premium', public.has_premium_access(),
  'subscription', (select jsonb_build_object('id',s.id,'plan_name_en',p.name_en,'plan_name_hi',p.name_hi,'starts_at',s.starts_at,'expires_at',s.expires_at,'status',s.status)
    from public.user_subscriptions s left join public.membership_plans p on p.id=s.plan_id
    where s.user_id=auth.uid() and s.status='active' and s.expires_at>now() order by s.expires_at desc limit 1),
  'recent_orders', coalesce((select jsonb_agg(jsonb_build_object('id',o.id,'amount_paise',o.amount_paise,'currency',o.currency,'status',o.status,'created_at',o.created_at) order by o.created_at desc)
    from (select * from public.payment_orders where user_id=auth.uid() order by created_at desc limit 10) o),'[]'::jsonb)
 );
$$;
grant execute on function public.get_my_membership() to authenticated;

-- Admin-only manual complimentary grant/revoke. Payment activation is webhook-only.
create or replace function public.admin_grant_membership(p_user_id uuid,p_plan_id uuid,p_days int,p_reason text default 'Admin complimentary grant')
returns uuid language plpgsql security definer set search_path=public
as $$ declare v_id uuid; begin
 if not public.is_admin() then raise exception 'Not authorised'; end if;
 if p_days is null or p_days<1 or p_days>3660 then raise exception 'Invalid duration'; end if;
 insert into public.user_subscriptions(user_id,plan_id,starts_at,expires_at,granted_by,grant_reason)
 values(p_user_id,p_plan_id,now(),now()+make_interval(days=>p_days),auth.uid(),left(coalesce(p_reason,''),500)) returning id into v_id;
 insert into public.audit_logs(actor_id,action,entity_type,entity_id,metadata)
 values(auth.uid(),'membership.granted','user_subscription',v_id::text,jsonb_build_object('user_id',p_user_id,'days',p_days,'reason',p_reason));
 return v_id;
end $$;
grant execute on function public.admin_grant_membership(uuid,uuid,int,text) to authenticated;

insert into public.membership_plans(code,name_en,name_hi,description_en,description_hi,duration_days,price_paise,display_order)
values ('monthly','Premium - 1 Month','प्रीमियम - 1 महीना','Full premium access for 30 days','30 दिनों के लिए सभी प्रीमियम सुविधाएँ',30,9900,1),
('quarterly','Premium - 3 Months','प्रीमियम - 3 महीने','Full premium access for 90 days','90 दिनों के लिए सभी प्रीमियम सुविधाएँ',90,24900,2),
('annual','Premium - 12 Months','प्रीमियम - 12 महीने','Full premium access for 365 days','365 दिनों के लिए सभी प्रीमियम सुविधाएँ',365,79900,3)
on conflict(code) do nothing;
