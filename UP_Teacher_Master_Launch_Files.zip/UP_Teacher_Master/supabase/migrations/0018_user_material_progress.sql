-- Phase 3X: per-user study material completion tracking
create table if not exists public.user_material_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  material_id uuid not null references public.study_materials(id) on delete cascade,
  status text not null default 'not_started'
    check (status in ('not_started','in_progress','completed')),
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key(user_id, material_id)
);
alter table public.user_material_progress enable row level security;
drop policy if exists "users read own material progress" on public.user_material_progress;
create policy "users read own material progress" on public.user_material_progress
for select to authenticated using (user_id = auth.uid());
drop policy if exists "users insert own material progress" on public.user_material_progress;
create policy "users insert own material progress" on public.user_material_progress
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "users update own material progress" on public.user_material_progress;
create policy "users update own material progress" on public.user_material_progress
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update on public.user_material_progress to authenticated;
