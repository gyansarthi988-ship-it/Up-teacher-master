-- Phase 3P: student doubt history and moderated AI answers
create table if not exists public.study_doubts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exam_id uuid null references public.exams(id) on delete set null,
  subject text not null default '',
  question text not null check (char_length(question) between 8 and 3000),
  answer text,
  answer_language text not null default 'auto' check (answer_language in ('auto','hi','en')),
  status text not null default 'pending' check (status in ('pending','answered','needs_review','failed')),
  provider_model text,
  token_usage jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  answered_at timestamptz
);
create index if not exists study_doubts_user_created_idx on public.study_doubts(user_id, created_at desc);
alter table public.study_doubts enable row level security;
drop policy if exists "Users read own doubts" on public.study_doubts;
create policy "Users read own doubts" on public.study_doubts for select to authenticated using (auth.uid() = user_id);
-- Inserts and answer updates are performed only by the Edge Function using server credentials.
drop policy if exists "No client doubt writes" on public.study_doubts;
revoke insert, update, delete on public.study_doubts from anon, authenticated;
grant select on public.study_doubts to authenticated;
drop policy if exists "Admins read all study doubts" on public.study_doubts;
create policy "Admins read all study doubts" on public.study_doubts for select to authenticated using (public.is_admin());
