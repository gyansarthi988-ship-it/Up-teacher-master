-- Phase 3Q: learner goals and explainable adaptive mentor recommendations.
create table if not exists public.study_mentor_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  target_exam_date date,
  daily_minutes int not null default 120 check (daily_minutes between 15 and 600),
  preferred_language text not null default 'auto' check (preferred_language in ('auto','hi','en')),
  updated_at timestamptz not null default now()
);

alter table public.study_mentor_preferences enable row level security;
drop policy if exists "Students manage own mentor preferences" on public.study_mentor_preferences;
create policy "Students manage own mentor preferences" on public.study_mentor_preferences
for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create or replace function public.save_my_mentor_preferences(
  p_exam_id uuid, p_target_exam_date date default null,
  p_daily_minutes int default 120, p_preferred_language text default 'auto'
) returns public.study_mentor_preferences
language plpgsql security definer set search_path = public as $$
declare v_user uuid := auth.uid(); v_row public.study_mentor_preferences;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  if p_daily_minutes < 15 or p_daily_minutes > 600 then raise exception 'Daily minutes must be 15 to 600'; end if;
  if p_preferred_language not in ('auto','hi','en') then raise exception 'Invalid language'; end if;
  if not exists(select 1 from public.exams where id=p_exam_id and is_active=true) then raise exception 'Active exam not found'; end if;
  insert into public.study_mentor_preferences(user_id,exam_id,target_exam_date,daily_minutes,preferred_language,updated_at)
  values(v_user,p_exam_id,p_target_exam_date,p_daily_minutes,p_preferred_language,now())
  on conflict(user_id) do update set exam_id=excluded.exam_id,target_exam_date=excluded.target_exam_date,
    daily_minutes=excluded.daily_minutes,preferred_language=excluded.preferred_language,updated_at=now()
  returning * into v_row;
  return v_row;
end; $$;
revoke all on function public.save_my_mentor_preferences(uuid,date,int,text) from public;
grant execute on function public.save_my_mentor_preferences(uuid,date,int,text) to authenticated;

create or replace function public.get_my_mentor_dashboard()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_user uuid := auth.uid(); v_pref public.study_mentor_preferences; v_exam_name text; v_total int; v_correct int; v_accuracy numeric; v_plan jsonb;
begin
  if v_user is null then raise exception 'Authentication required'; end if;
  select * into v_pref from public.study_mentor_preferences where user_id=v_user;
  if not found then return jsonb_build_object('configured',false,'message','Set your target exam and daily study time to begin.'); end if;
  select coalesce(name_en,code) into v_exam_name from public.exams where id=v_pref.exam_id;
  select count(*) filter(where r.selected_option_id is not null), count(*) filter(where r.is_correct)
    into v_total,v_correct
  from public.test_attempts a join public.test_attempt_responses r on r.attempt_id=a.id
  where a.user_id=v_user and a.exam_id=v_pref.exam_id and a.status='submitted';
  v_accuracy := case when coalesce(v_total,0)=0 then null else round(100.0*v_correct/nullif(v_total,0),1) end;
  v_plan := public.get_my_learning_plan(v_pref.exam_id);
  return jsonb_build_object('configured',true,'exam_id',v_pref.exam_id,'exam_name',v_exam_name,
    'target_exam_date',v_pref.target_exam_date,'daily_minutes',v_pref.daily_minutes,
    'preferred_language',v_pref.preferred_language,'attempted',coalesce(v_total,0),
    'correct',coalesce(v_correct,0),'accuracy',v_accuracy,'learning_plan',v_plan,
    'days_remaining',case when v_pref.target_exam_date is null then null else greatest(0,v_pref.target_exam_date-current_date) end);
end; $$;
revoke all on function public.get_my_mentor_dashboard() from public;
grant execute on function public.get_my_mentor_dashboard() to authenticated;
