-- Phase 3O: Firebase Cloud Messaging device token registry
create table if not exists public.user_device_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  fcm_token text not null unique,
  platform text not null default 'android' check (platform in ('android','ios','web','linux','macos','windows','fuchsia')),
  is_active boolean not null default true,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists user_device_tokens_user_active_idx
  on public.user_device_tokens(user_id, is_active) where is_active = true;
alter table public.user_device_tokens enable row level security;
drop policy if exists "Users manage own push tokens" on public.user_device_tokens;
create policy "Users manage own push tokens" on public.user_device_tokens
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
grant select, insert, update, delete on public.user_device_tokens to authenticated;
