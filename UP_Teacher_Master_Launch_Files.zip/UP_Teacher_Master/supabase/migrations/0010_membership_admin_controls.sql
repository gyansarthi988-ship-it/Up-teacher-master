-- Phase 3L: administrative subscription controls and auditable revocation.
create or replace function public.admin_revoke_membership(p_subscription_id uuid,p_reason text default 'Administrative revocation')
returns void language plpgsql security definer set search_path=public
as $$
declare v_user uuid; v_status text;
begin
 if not public.is_admin() then raise exception 'Not authorised'; end if;
 select user_id,status into v_user,v_status from public.user_subscriptions where id=p_subscription_id for update;
 if not found then raise exception 'Membership not found'; end if;
 if v_status<>'active' then raise exception 'Only active memberships can be revoked'; end if;
 update public.user_subscriptions set status='revoked' where id=p_subscription_id;
 insert into public.audit_logs(actor_id,action,entity_type,entity_id,metadata)
 values(auth.uid(),'membership.revoked','user_subscription',p_subscription_id::text,jsonb_build_object('user_id',v_user,'reason',left(coalesce(p_reason,''),500)));
end $$;
grant execute on function public.admin_revoke_membership(uuid,text) to authenticated;

create or replace function public.admin_membership_summary()
returns jsonb language plpgsql stable security definer set search_path=public
as $$
declare v_result jsonb;
begin
 if not public.is_admin() then raise exception 'Not authorised'; end if;
 select jsonb_build_object(
  'active_subscriptions',(select count(*) from public.user_subscriptions where status='active' and starts_at<=now() and expires_at>now()),
  'paid_orders',(select count(*) from public.payment_orders where status='paid'),
  'revenue_paise',(select coalesce(sum(amount_paise),0) from public.payment_orders where status='paid'),
  'pending_orders',(select count(*) from public.payment_orders where status='created')
 ) into v_result;
 return v_result;
end $$;
grant execute on function public.admin_membership_summary() to authenticated;
