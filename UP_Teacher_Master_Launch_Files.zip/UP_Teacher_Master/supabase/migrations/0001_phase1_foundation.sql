-- UP Teacher Master: Phase 1 foundation
create extension if not exists pgcrypto;

create type public.app_role as enum
  ('super_admin', 'content_admin', 'question_manager', 'test_manager', 'support_staff', 'student');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  email text,
  preferred_language text not null default 'hi' check (preferred_language in ('hi','en')),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null default 'student',
  created_at timestamptz not null default now(),
  unique(user_id, role)
);

create table public.exams (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name_en text not null,
  name_hi text not null,
  description_en text,
  description_hi text,
  is_active boolean not null default true,
  display_order int not null default 0,
  created_at timestamptz not null default now()
);

create table public.user_exam_selections (
  user_id uuid not null references auth.users(id) on delete cascade,
  exam_id uuid not null references public.exams(id) on delete cascade,
  selected_subject text,
  created_at timestamptz not null default now(),
  primary key(user_id, exam_id)
);

create table public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid()
      and role in ('super_admin','content_admin','question_manager','test_manager','support_staff')
  );
$$;

create or replace function public.has_role(required_role public.app_role)
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = required_role
  );
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, phone, email, full_name)
  values (new.id, new.phone, new.email, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do update set
    phone = excluded.phone,
    email = excluded.email,
    updated_at = now();

  insert into public.user_roles(user_id, role)
  values (new.id, 'student')
  on conflict (user_id, role) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.exams enable row level security;
alter table public.user_exam_selections enable row level security;
alter table public.app_settings enable row level security;
alter table public.audit_logs enable row level security;

create policy "profiles read own or admin" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "roles read own or admin" on public.user_roles
for select to authenticated using (user_id = auth.uid() or public.is_admin());
-- Role changes are intentionally not allowed from client-side policies.

create policy "active exams visible" on public.exams
for select to anon, authenticated using (is_active = true or public.is_admin());
create policy "admins manage exams" on public.exams
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "exam selections own" on public.user_exam_selections
for all to authenticated using (user_id = auth.uid() or public.is_admin())
with check (user_id = auth.uid() or public.is_admin());

create policy "settings public read" on public.app_settings
for select to anon, authenticated using (key in ('app_name','maintenance_mode'));
create policy "admins manage settings" on public.app_settings
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "admins read audit logs" on public.audit_logs
for select to authenticated using (public.has_role('super_admin'));
create policy "admins insert audit logs" on public.audit_logs
for insert to authenticated with check (actor_id = auth.uid() and public.is_admin());

insert into public.exams(code,name_en,name_hi,description_en,description_hi,display_order)
values
('SUPER_TET','UP Super TET','यूपी सुपर टीईटी','Teacher recruitment preparation','शिक्षक भर्ती की तैयारी',1),
('TGT','UP TGT','यूपी टीजीटी','Trained Graduate Teacher preparation','प्रशिक्षित स्नातक शिक्षक परीक्षा की तैयारी',2),
('PRT','UP PRT','यूपी पीआरटी','Primary Teacher preparation','प्राथमिक शिक्षक परीक्षा की तैयारी',3),
('JUNIOR','UP Junior Level','यूपी जूनियर लेवल','Junior level teacher preparation','जूनियर स्तर शिक्षक परीक्षा की तैयारी',4)
on conflict (code) do nothing;

insert into public.app_settings(key,value) values
('app_name','"UP Teacher Master"'::jsonb),
('maintenance_mode','false'::jsonb)
on conflict (key) do nothing;

-- No admin is created automatically. Promote your own verified account
-- using the SQL in docs/ADMIN_BOOTSTRAP.md after first login.
