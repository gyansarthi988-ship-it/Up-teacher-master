-- Phase 3T: first-login onboarding preferences
create table if not exists public.user_onboarding_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  primary_exam_code text not null default 'SUPER_TET'
    check (primary_exam_code in ('SUPER_TET','TGT','PRT','JUNIOR')),
  preferred_language text not null default 'hi'
    check (preferred_language in ('hi','en','both')),
  daily_goal_minutes integer not null default 120
    check (daily_goal_minutes between 15 and 360),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.user_onboarding_preferences enable row level security;

drop policy if exists "Users read own onboarding preferences" on public.user_onboarding_preferences;
create policy "Users read own onboarding preferences"
on public.user_onboarding_preferences for select
to authenticated using (auth.uid() = user_id);

drop policy if exists "Users insert own onboarding preferences" on public.user_onboarding_preferences;
create policy "Users insert own onboarding preferences"
on public.user_onboarding_preferences for insert
to authenticated with check (auth.uid() = user_id);

drop policy if exists "Users update own onboarding preferences" on public.user_onboarding_preferences;
create policy "Users update own onboarding preferences"
on public.user_onboarding_preferences for update
to authenticated using (auth.uid() = user_id)
with check (auth.uid() = user_id);

comment on table public.user_onboarding_preferences is
'Phase 3T first-login setup: primary exam, language and daily study goal.';
