-- Phase 3N: announcements and in-app notification read state
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title_en text not null check (char_length(title_en) between 3 and 160),
  title_hi text,
  body_en text not null check (char_length(body_en) between 3 and 5000),
  body_hi text,
  category text not null default 'general' check (category in ('general','exam_update','important','maintenance')),
  target_exam_id uuid references public.exams(id) on delete set null,
  is_published boolean not null default false,
  publish_at timestamptz,
  expires_at timestamptz,
  created_by uuid references auth.users(id) on delete set null default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint announcement_expiry_valid check (expires_at is null or publish_at is null or expires_at > publish_at)
);
create index if not exists announcements_feed_idx on public.announcements(is_published, publish_at desc, created_at desc);
create index if not exists announcements_exam_idx on public.announcements(target_exam_id);

create table if not exists public.announcement_reads (
  announcement_id uuid not null references public.announcements(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  read_at timestamptz not null default now(),
  primary key (announcement_id, user_id)
);
create index if not exists announcement_reads_user_idx on public.announcement_reads(user_id, read_at desc);

alter table public.announcements enable row level security;
alter table public.announcement_reads enable row level security;

drop policy if exists "Published announcements readable" on public.announcements;
create policy "Published announcements readable" on public.announcements
for select to authenticated using (
  public.is_admin() or (
    is_published = true
    and (publish_at is null or publish_at <= now())
    and (expires_at is null or expires_at > now())
  )
);
drop policy if exists "Admins manage announcements" on public.announcements;
create policy "Admins manage announcements" on public.announcements
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Users read own announcement receipts" on public.announcement_reads;
create policy "Users read own announcement receipts" on public.announcement_reads
for select to authenticated using (user_id = auth.uid() or public.is_admin());
drop policy if exists "Users mark own announcements read" on public.announcement_reads;
create policy "Users mark own announcements read" on public.announcement_reads
for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users clear own read receipts" on public.announcement_reads;
create policy "Users clear own read receipts" on public.announcement_reads
for delete to authenticated using (user_id = auth.uid() or public.is_admin());

grant select, insert, update, delete on public.announcements to authenticated;
grant select, insert, delete on public.announcement_reads to authenticated;
