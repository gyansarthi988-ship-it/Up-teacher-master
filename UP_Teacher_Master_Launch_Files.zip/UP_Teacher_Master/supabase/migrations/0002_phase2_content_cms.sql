-- UP Teacher Master Phase 2: content management, syllabus, question bank and resources
create type public.content_status as enum ('draft','under_review','approved','published','archived');
create type public.question_difficulty as enum ('easy','moderate','difficult','advanced');


create table public.exam_patterns (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  version_label text not null,
  duration_minutes int,
  total_questions int,
  total_marks numeric(8,2),
  negative_marking boolean not null default false,
  marking_rules jsonb not null default '{}'::jsonb,
  source_name text,
  source_url text,
  verified_on date,
  effective_from date,
  effective_until date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(exam_id, version_label)
);

create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name_en text not null,
  name_hi text not null,
  description_en text,
  description_hi text,
  is_active boolean not null default true,
  display_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.exam_subjects (
  exam_id uuid not null references public.exams(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  is_compulsory boolean not null default false,
  display_order int not null default 0,
  primary key(exam_id, subject_id)
);

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid not null references public.subjects(id) on delete cascade,
  code text,
  name_en text not null,
  name_hi text not null,
  description_en text,
  description_hi text,
  display_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(subject_id, code)
);

create table public.topics (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  code text,
  name_en text not null,
  name_hi text not null,
  display_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(chapter_id, code)
);

create table public.syllabus_items (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  topic_id uuid not null references public.topics(id) on delete cascade,
  weightage numeric(6,2),
  notes_en text,
  notes_hi text,
  source_name text,
  source_url text,
  verified_on date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(exam_id, topic_id)
);

create table public.questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete restrict,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  topic_id uuid references public.topics(id) on delete set null,
  question_hi text,
  question_en text,
  difficulty public.question_difficulty not null default 'moderate',
  question_type text not null default 'single_choice' check (question_type in ('single_choice')),
  status public.content_status not null default 'draft',
  marks numeric(7,2) not null default 1,
  negative_marks numeric(7,2) not null default 0,
  created_by uuid references auth.users(id) on delete set null,
  reviewed_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint question_has_language check (
    nullif(trim(coalesce(question_hi,'')), '') is not null
    or nullif(trim(coalesce(question_en,'')), '') is not null
  )
);

create table public.question_tags (
  question_id uuid not null references public.questions(id) on delete cascade,
  tag text not null,
  primary key(question_id, tag)
);

create table public.question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  option_key text not null check (option_key in ('A','B','C','D')),
  text_hi text,
  text_en text,
  display_order int not null default 0,
  unique(question_id, option_key),
  constraint option_has_language check (
    nullif(trim(coalesce(text_hi,'')), '') is not null
    or nullif(trim(coalesce(text_en,'')), '') is not null
  )
);

alter table public.question_options
  add constraint question_options_id_question_unique unique(id, question_id);

create table public.question_answers (
  question_id uuid primary key references public.questions(id) on delete cascade,
  correct_option_id uuid not null,
  updated_at timestamptz not null default now(),
  constraint answer_option_belongs_to_question
    foreign key(correct_option_id, question_id)
    references public.question_options(id, question_id) on delete cascade
);

create table public.question_explanations (
  question_id uuid primary key references public.questions(id) on delete cascade,
  explanation_hi text,
  explanation_en text,
  updated_at timestamptz not null default now()
);

create table public.question_sources (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  source_name text,
  source_url text,
  exam_year int,
  page_reference text,
  is_verified boolean not null default false,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.question_reviews (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  reviewer_id uuid references auth.users(id) on delete set null,
  decision text not null check (decision in ('approved','rejected','needs_changes')),
  comments text,
  reviewed_at timestamptz not null default now()
);

create table public.question_reports (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'open' check (status in ('open','in_review','resolved','dismissed')),
  created_at timestamptz not null default now(),
  unique(question_id,user_id)
);

create table public.study_materials (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid references public.exams(id) on delete set null,
  subject_id uuid references public.subjects(id) on delete set null,
  topic_id uuid references public.topics(id) on delete set null,
  title_hi text,
  title_en text,
  description_hi text,
  description_en text,
  material_type text not null default 'pdf' check (material_type in ('pdf','document','link')),
  storage_path text,
  external_url text,
  access_tier text not null default 'free' check (access_tier in ('free','premium')),
  status public.content_status not null default 'draft',
  file_size_bytes bigint,
  uploaded_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  constraint material_has_title check (
    nullif(trim(coalesce(title_hi,'')), '') is not null
    or nullif(trim(coalesce(title_en,'')), '') is not null
  ),
  constraint material_has_location check (
    (material_type = 'pdf' and storage_path is not null)
    or (material_type in ('document','link') and (storage_path is not null or external_url is not null))
  )
);


-- Ensure topic/subject and exam/syllabus relationships remain consistent.
create or replace function public.validate_question_topic_subject()
returns trigger language plpgsql
set search_path = public
as $$
declare topic_subject uuid;
begin
  if new.topic_id is not null then
    select c.subject_id into topic_subject
    from public.topics t join public.chapters c on c.id = t.chapter_id
    where t.id = new.topic_id;
    if topic_subject is null or topic_subject <> new.subject_id then
      raise exception 'Selected topic does not belong to the selected subject.';
    end if;
  end if;
  return new;
end;
$$;

create trigger questions_validate_topic_subject
before insert or update of topic_id, subject_id on public.questions
for each row execute function public.validate_question_topic_subject();

create or replace function public.validate_syllabus_topic_mapping()
returns trigger language plpgsql
set search_path = public
as $$
declare topic_subject uuid;
begin
  select c.subject_id into topic_subject
  from public.topics t join public.chapters c on c.id = t.chapter_id
  where t.id = new.topic_id;
  if topic_subject is null or not exists (
    select 1 from public.exam_subjects es
    where es.exam_id = new.exam_id and es.subject_id = topic_subject
  ) then
    raise exception 'Map this topic subject to the examination before adding the topic to its syllabus.';
  end if;
  return new;
end;
$$;

create trigger syllabus_validate_exam_subject
before insert or update of exam_id, topic_id on public.syllabus_items
for each row execute function public.validate_syllabus_topic_mapping();

create index questions_exam_subject_status_idx on public.questions(exam_id,subject_id,status);
create index questions_topic_idx on public.questions(topic_id);
create index chapters_subject_order_idx on public.chapters(subject_id,display_order);
create index topics_chapter_order_idx on public.topics(chapter_id,display_order);
create index syllabus_exam_idx on public.syllabus_items(exam_id);
create index study_materials_catalogue_idx on public.study_materials(exam_id,subject_id,status,access_tier);

-- Helper: all content staff may manage content; student is excluded.
create or replace function public.can_manage_content()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid()
      and role in ('super_admin','content_admin','question_manager','test_manager')
  );
$$;

-- RLS enabled on every Phase 2 table.
alter table public.exam_patterns enable row level security;
alter table public.subjects enable row level security;
alter table public.exam_subjects enable row level security;
alter table public.chapters enable row level security;
alter table public.topics enable row level security;
alter table public.syllabus_items enable row level security;
alter table public.questions enable row level security;
alter table public.question_tags enable row level security;
alter table public.question_options enable row level security;
alter table public.question_answers enable row level security;
alter table public.question_explanations enable row level security;
alter table public.question_sources enable row level security;
alter table public.question_reviews enable row level security;
alter table public.question_reports enable row level security;
alter table public.study_materials enable row level security;

-- Public/student catalogue: active exam patterns, subjects, active syllabus,
-- published questions/materials only.
create policy "active exam patterns visible" on public.exam_patterns
for select to anon, authenticated using (is_active or public.is_admin());
create policy "content staff manage exam patterns" on public.exam_patterns
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());


create policy "active subjects visible" on public.subjects
for select to anon, authenticated using (is_active or public.is_admin());
create policy "content staff manage subjects" on public.subjects
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "exam subject mappings visible" on public.exam_subjects
for select to anon, authenticated using (true);
create policy "content staff manage exam subject mappings" on public.exam_subjects
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "active chapters visible" on public.chapters
for select to anon, authenticated using (is_active or public.is_admin());
create policy "content staff manage chapters" on public.chapters
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "active topics visible" on public.topics
for select to anon, authenticated using (is_active or public.is_admin());
create policy "content staff manage topics" on public.topics
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "active syllabus visible" on public.syllabus_items
for select to anon, authenticated using (is_active or public.is_admin());
create policy "content staff manage syllabus" on public.syllabus_items
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "published questions visible" on public.questions
for select to anon, authenticated using (status = 'published' or public.can_manage_content());
create policy "content staff manage questions" on public.questions
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "published tags visible" on public.question_tags
for select to anon, authenticated using (
  exists(select 1 from public.questions q where q.id = question_id and q.status = 'published')
  or public.can_manage_content()
);
create policy "content staff manage tags" on public.question_tags
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "published options visible" on public.question_options
for select to anon, authenticated using (
  exists(select 1 from public.questions q where q.id = question_id and q.status = 'published')
  or public.can_manage_content()
);
create policy "content staff manage options" on public.question_options
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

-- CRITICAL: correct answers are never exposed to the student client in Phase 2.
create policy "only content staff read answers" on public.question_answers
for select to authenticated using (public.can_manage_content());
create policy "content staff manage answers" on public.question_answers
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "published explanations visible" on public.question_explanations
for select to anon, authenticated using (
  exists(select 1 from public.questions q where q.id = question_id and q.status = 'published')
  or public.can_manage_content()
);
create policy "content staff manage explanations" on public.question_explanations
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "content staff manage sources" on public.question_sources
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());
create policy "content staff manage reviews" on public.question_reviews
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "students report questions" on public.question_reports
for insert to authenticated with check (user_id = auth.uid());
create policy "students see own reports" on public.question_reports
for select to authenticated using (user_id = auth.uid() or public.can_manage_content());
create policy "content staff manage reports" on public.question_reports
for update to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

create policy "published materials visible" on public.study_materials
for select to anon, authenticated using (status = 'published' or public.can_manage_content());
create policy "content staff manage materials" on public.study_materials
for all to authenticated using (public.can_manage_content()) with check (public.can_manage_content());

-- Private bucket for free and premium PDFs; signed URL delivery will be implemented
-- with entitlement checks in the student content delivery phase.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('study-materials','study-materials',false,52428800,array['application/pdf'])
on conflict (id) do nothing;

create policy "content staff upload study materials" on storage.objects
for insert to authenticated with check (
  bucket_id = 'study-materials' and public.can_manage_content()
);
create policy "content staff read study materials" on storage.objects
for select to authenticated using (
  bucket_id = 'study-materials' and public.can_manage_content()
);
create policy "content staff update study materials" on storage.objects
for update to authenticated using (
  bucket_id = 'study-materials' and public.can_manage_content()
) with check (bucket_id = 'study-materials' and public.can_manage_content());
create policy "content staff delete study materials" on storage.objects
for delete to authenticated using (
  bucket_id = 'study-materials' and public.can_manage_content()
);

-- Seed an initial subject catalogue. Exam mappings must be configured by admin
-- after confirming each recruitment cycle's official syllabus.
insert into public.subjects(code,name_en,name_hi,display_order) values
('HINDI','Hindi','हिन्दी',1),
('ENGLISH','English','अंग्रेज़ी',2),
('MATHS','Mathematics','गणित',3),
('SCIENCE','Science','विज्ञान',4),
('SOCIAL_STUDIES','Social Studies','सामाजिक अध्ययन',5),
('CDP','Child Development & Pedagogy','बाल विकास एवं शिक्षाशास्त्र',6),
('PEDAGOGY','Teaching Pedagogy','शिक्षण शास्त्र',7),
('REASONING','Reasoning','तर्कशक्ति',8),
('GK','General Knowledge','सामान्य ज्ञान',9),
('COMPUTER','Computer','कंप्यूटर',10),
('SANSKRIT','Sanskrit','संस्कृत',11)
on conflict (code) do nothing;
