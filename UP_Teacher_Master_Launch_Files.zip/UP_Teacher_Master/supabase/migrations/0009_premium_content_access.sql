-- Phase 3K: enforce Free/Premium access to published study materials and private files.
-- Existing content staff access remains unchanged.

-- Students can see only published Free materials or Premium materials with a live entitlement.
drop policy if exists "published materials visible" on public.study_materials;
create policy "published materials visible by entitlement" on public.study_materials
for select to authenticated
using (
  public.can_manage_content()
  or (
    status = 'published'
    and (
      access_tier = 'free'
      or (access_tier = 'premium' and public.has_premium_access())
    )
  )
);

-- Anonymous visitors do not receive study material catalogue rows.
-- Admin/content staff can still manage records through the existing policy.

-- Storage signed URLs are only minted when the caller can SELECT the underlying object.
-- Match the private object path to a published material row and enforce its access tier.
drop policy if exists "content staff read study materials" on storage.objects;
create policy "study material files readable by entitlement" on storage.objects
for select to authenticated
using (
  bucket_id = 'study-materials'
  and (
    public.can_manage_content()
    or exists (
      select 1
      from public.study_materials m
      where m.storage_path = storage.objects.name
        and m.status = 'published'
        and (
          m.access_tier = 'free'
          or (m.access_tier = 'premium' and public.has_premium_access())
        )
    )
  )
);

create index if not exists study_materials_access_lookup_idx
  on public.study_materials(status, access_tier, exam_id);

-- Central entitlement helper for client UI. This is informational only;
-- actual protection is enforced by RLS and Storage policies above.
create or replace function public.get_material_access_summary()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'is_premium', public.has_premium_access(),
    'free_material_count', (select count(*) from public.study_materials where status='published' and access_tier='free'),
    'premium_material_count', (select count(*) from public.study_materials where status='published' and access_tier='premium'),
    'accessible_premium_count', case when public.has_premium_access() then
      (select count(*) from public.study_materials where status='published' and access_tier='premium') else 0 end
  );
$$;
grant execute on function public.get_material_access_summary() to authenticated;
