UP TEACHER MASTER – PHASE 3K
Premium Content Access Control & Study Material Protection

Apply Supabase migrations in order through 0009. If you have already applied 0001–0008, run only:
supabase/migrations/0009_premium_content_access.sql

The mobile app now includes a Study Materials page. Access is enforced by Supabase RLS and private Storage policies, not just by hiding buttons in Flutter.

Important: Keep the study-materials bucket PRIVATE. Signed PDF links expire after 10 minutes. This is access control, not DRM; users can still copy a file while they have valid access.

This is a source package. Flutter compilation, live Supabase deployment and device testing have not been performed. Manual testing remains with the project owner.
