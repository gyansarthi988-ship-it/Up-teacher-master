UP TEACHER MASTER – PHASE 3P
AI Doubt Solving & Study Assistant

Read docs/PHASE3P_AI_DOUBT_ASSISTANT.md before deployment.
Run migration 0013 after 0001–0012, set OPENAI_API_KEY as a Supabase Edge Function secret, and deploy answer-study-doubt with JWT verification enabled.
Do not add secrets to Flutter or public GitHub.
Live AI answers are not enabled until configuration is complete.
