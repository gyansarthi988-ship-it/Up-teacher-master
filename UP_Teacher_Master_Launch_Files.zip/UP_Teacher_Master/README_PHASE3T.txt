UP TEACHER MASTER – PHASE 3T
First Login Onboarding & Study Setup

1. Source code is under mobile/.
2. New migration: supabase/migrations/0016_user_onboarding_preferences.sql
3. Apply migrations in order after 0001–0015.
4. Read docs/PHASE3T_ONBOARDING.md for feature and rollout details.

This is a source-code package. Flutter build, Supabase deployment and phone runtime
were not performed in this delivery. The owner will perform manual testing.
