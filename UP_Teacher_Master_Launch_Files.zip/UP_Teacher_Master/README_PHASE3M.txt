UP TEACHER MASTER — PHASE 3M
Profile, Account Dashboard & Subscription Management

Start from this package's existing mobile/ and admin/ source folders.
New screen: mobile/lib/screens/profile_screen.dart
Home drawer integration: mobile/lib/screens/home_screen.dart
Documentation: docs/PHASE3M_*.md

No new SQL migration is required. This phase uses existing profiles RLS and
Phase 3J get_my_membership() RPC. Ensure migrations 0001 through 0010 have
been applied in order and Supabase app configuration is supplied.

Not built or runtime-tested. Manual device testing is the user's responsibility.
Do not commit admin/.env.local or Supabase service-role/payment secrets.
