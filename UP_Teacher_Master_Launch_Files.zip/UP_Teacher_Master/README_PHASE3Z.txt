UP Teacher Master – Phase 3Z

Feature: Weak Topic Diagnosis & Personalised Improvement Plan.
No new Supabase migration is needed. Uses get_my_performance_analytics.
See docs/PHASE3Z_WEAK_TOPIC_DIAGNOSIS.md.

Manual device testing and deployment are handled by the project owner.
