UP TEACHER MASTER — PHASE 3O
Firebase Push Notifications & Real-Time Alerts

Read docs/PHASE3O_FIREBASE_PUSH_NOTIFICATIONS.md before configuring Firebase.
New migration: supabase/migrations/0012_push_notification_tokens.sql
New Edge Function: supabase/functions/send-push-notification/index.ts
Mobile service: mobile/lib/notification_service.dart
Admin action: Announcement Manager > Send Push (published notices only)

Firebase configuration and private credentials are NOT included. Flutter build,
Firebase delivery, Supabase deployment and device runtime have not been tested.
See docs/PHASE3O_CHANGELOG.md for the changes.
