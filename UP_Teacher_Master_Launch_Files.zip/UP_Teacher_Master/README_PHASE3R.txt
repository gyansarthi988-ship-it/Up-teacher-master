UP TEACHER MASTER – PHASE 3R
Spaced Revision & Weak Topic Mastery

1. This package continues the Phase 3Q project source.
2. Apply supabase/migrations/0015_spaced_revision_mastery.sql after 0001–0014.
3. Open the app menu and choose Spaced Revision / स्मार्ट रिवीजन.
4. Review due questions, reveal the explanation, then rate recall: Again, Hard, Good or Easy.
5. The server schedules the next review interval and tracks successful review streaks.

No Flutter build, Supabase deployment or device runtime test was performed in this packaging step. Manual testing is to be handled by the project owner.
