"use client";

import { FormEvent, useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import ContentStudio from "./components/ContentStudio";
import MockTestBuilder from "./components/MockTestBuilder";
import QuestionQualityCenter from "./components/QuestionQualityCenter";
import QuestionBulkImportCenter from "./components/QuestionBulkImportCenter";
import MembershipManager from "./components/MembershipManager";
import AnnouncementManager from "./components/AnnouncementManager";
import DoubtReviewCenter from "./components/DoubtReviewCenter";

type Exam = { id: string; code: string; name_en: string; name_hi: string };

export default function AdminHome() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState<string | null>(null);
  const [allowed, setAllowed] = useState(false);
  const [exams, setExams] = useState<Exam[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const { data: { user } } = await supabase.auth.getUser();
    setUser(user?.email ?? user?.phone ?? null);
    if (!user) { setAllowed(false); return; }
    const { data, error } = await supabase.from("user_roles")
      .select("role").eq("user_id", user.id);
    if (error) { setError(error.message); return; }
    const roles = (data ?? []).map((x: {role:string}) => x.role);
    const isAdmin = roles.some(r => r !== "student");
    setAllowed(isAdmin);
    if (isAdmin) {
      const result = await supabase.from("exams").select("id,code,name_en,name_hi").order("display_order");
      if (result.error) setError(result.error.message);
      else setExams(result.data ?? []);
    }
  }

  useEffect(() => { void refresh(); }, []);

  async function signIn(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setError(error.message);
    else await refresh();
    setBusy(false);
  }

  async function signOut() {
    await supabase.auth.signOut(); setUser(null); setAllowed(false);
  }

  if (!user) return <main><section className="card" style={{maxWidth:440,margin:"8vh auto"}}>
    <h1>UP Teacher Master</h1><p className="muted">Admin Control Panel</p>
    <form onSubmit={signIn}>
      <label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} />
      <label>Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} />
      <button disabled={busy}>{busy ? "Signing in…" : "Admin Sign In"}</button>
    </form>{error && <p style={{color:"crimson"}}>{error}</p>}
    <small>Admin accounts are created and promoted by the Super Admin. Public admin registration is disabled.</small>
  </section></main>;

  if (!allowed) return <main><section className="card">
    <h1>Access not authorized</h1><p>Your account does not have an admin role.</p>
    {error && <p style={{color:"crimson"}}>{error}</p>}
    <button onClick={signOut}>Sign out</button>
  </section></main>;

  return <main>
    <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
      <div><h1>UP Teacher Master</h1><p className="muted">Admin Control Centre · {user}</p></div>
      <button onClick={signOut}>Sign out</button>
    </header>
    <div className="grid">
      {[
        ["Examinations", String(exams.length)],
        ["Content Management", "Phase 2"],
        ["Question Bank", "Phase 2"],
        ["Mock Tests", "Phase 3"]
      ].map(([label,value])=><section className="card" key={label}><small>{label}</small><h2>{value}</h2></section>)}
    </div>
    <section className="card">
      <h2>Configured examinations</h2>
      {exams.map(exam=><p key={exam.id}><b>{exam.name_en}</b> · {exam.name_hi} <small>({exam.code})</small></p>)}
      {!exams.length && <p className="muted">No active exams found. Run the Phase 1 database migration.</p>}
    </section>
    <MockTestBuilder exams={exams} />
    <QuestionQualityCenter />
    <QuestionBulkImportCenter exams={exams} onImported={async()=>{}} />
    <MembershipManager />
    <AnnouncementManager exams={exams} />
    <DoubtReviewCenter />
    <ContentStudio />
  </main>;
}
