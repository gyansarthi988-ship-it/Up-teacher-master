UP TEACHER MASTER – PHASE 3W
Complete Syllabus Tracker

New screen: mobile/lib/screens/syllabus_tracker_screen.dart
Navigation: Home drawer > Syllabus Tracker.
IMPORTANT: Apply supabase/migrations/0017_user_syllabus_progress.sql.
The tracker requires admin-published syllabus_items and linked topics/chapters/subjects.
It does not claim official syllabus completeness until that catalogue is populated and verified.

Source package only. Flutter build, Supabase deployment and device runtime were not performed.
Owner handles manual testing.
