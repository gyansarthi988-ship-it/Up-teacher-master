UP TEACHER MASTER – PHASE 3N
Notifications, Announcements & Exam Updates

CONTENTS
- mobile/: Flutter app source, including Notifications & Updates screen.
- admin/: Next.js admin panel, including Announcement Manager.
- supabase/migrations/0011_notifications_announcements.sql
- docs/PHASE3N_NOTIFICATIONS_ANNOUNCEMENTS.md
- docs/PHASE3N_CHANGELOG.md

SETUP
1. Apply migrations 0001 through 0011 in order (if earlier migrations are not already applied).
2. Deploy the updated admin panel.
3. Build the updated Flutter application.
4. Sign in as an admin, create an announcement, and publish it.
5. Sign in as a student to view it under Notifications & Updates.

SECURITY
RLS protects the published feed and per-user read receipts. Admin management requires the existing public.is_admin() helper. Never put a Supabase service-role key in the mobile app or browser.

LIMITS
This phase provides in-app announcements only. Native push notifications (FCM/APNs), WhatsApp/email delivery, exam-specific audience filtering, and scheduled publishing are not configured.

No Flutter/Next production build or live Supabase runtime test has been performed. Manual device testing remains with the project owner.
