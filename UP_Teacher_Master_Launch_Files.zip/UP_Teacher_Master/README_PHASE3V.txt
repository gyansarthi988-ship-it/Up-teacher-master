UP TEACHER MASTER – PHASE 3V
Exam Readiness & Progress Indicators

New screen: mobile/lib/screens/exam_readiness_screen.dart
Navigation: Home navigation drawer.
Database: no new migration; uses get_my_performance_analytics (0005).

Read docs/PHASE3V_EXAM_READINESS.md. Readiness is an indicative practice score,
not a pass/selection prediction. Syllabus coverage is not claimed.

Source package only. Flutter build, backend deployment and device runtime were
not performed. Owner handles manual testing.
