from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
errors, warnings = [], []
# Required project structure
required = [
    'mobile/pubspec.yaml', 'mobile/lib/main.dart', 'admin/package.json',
    'supabase/migrations', '.github/workflows/android-apk.yml',
]
for item in required:
    if not (ROOT / item).exists(): errors.append(f'Missing required path: {item}')
# Migration numbering must be sequential; this catches accidentally omitted files.
files = sorted((ROOT / 'supabase/migrations').glob('*.sql'))
nums = []
for f in files:
    m = re.match(r'(\d{4})_', f.name)
    if m: nums.append(int(m.group(1)))
if not nums:
    errors.append('No numbered SQL migrations found')
else:
    expected = list(range(1, max(nums) + 1))
    if nums != expected:
        errors.append(f'Migration sequence has gaps/duplicates: found {nums}, expected {expected}')
# Guard against accidental privileged credentials in tracked source.
for base in ('mobile/lib', 'admin', '.github/workflows'):
    folder = ROOT / base
    if not folder.exists(): continue
    for f in folder.rglob('*'):
        if not f.is_file() or f.suffix not in {'.dart', '.ts', '.tsx', '.yml', '.yaml', '.json'}: continue
        try: content = f.read_text(encoding='utf-8')
        except Exception: continue
        if re.search(r'service_role\s*[:=]\s*[\"\'][^\"\']{12,}', content, re.I):
            errors.append(f'Possible Supabase service-role credential in {f.relative_to(ROOT)}')
# Ensure public app config uses compile-time defines and a non-empty endpoint.
config = ROOT / 'mobile/lib/app_config.dart'
if config.exists():
    s = config.read_text(encoding='utf-8')
    if 'String.fromEnvironment' not in s: warnings.append('App config does not appear to use compile-time environment defines')
    if 'supabase.co' not in s: warnings.append('No Supabase endpoint found in app config; ensure build secrets are supplied')
print(f'Project: {ROOT.name}')
print(f'Numbered migrations: {len(nums)} (latest: {max(nums) if nums else 0:04d})')
for w in warnings: print('WARNING:', w)
for e in errors: print('ERROR:', e)
if errors: sys.exit(1)
print('Preflight checks passed. This does not replace Flutter build or manual device testing.')
