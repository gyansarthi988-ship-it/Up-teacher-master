UP TEACHER MASTER — PHASE 3S
Release Readiness & Automated Build Gate

This update prepares the project for a repeatable GitHub cloud build. It does not add questions.

Main additions:
1. scripts/release_preflight.py
2. .github/workflows/project-preflight.yml
3. docs/PHASE3S_RELEASE_READINESS.md
4. docs/PHASE3S_CHANGELOG.md

GitHub Actions repository secrets required:
- SUPABASE_URL
- SUPABASE_ANON_KEY (public anon/publishable key only)

Run: GitHub repository > Actions > UP Teacher Master Project Preflight > Run workflow.
Download artifact: up-teacher-master-preflight-debug-apk

This is a debug APK, not a signed Play Store release. CI workflow has not been run here. Owner handles manual device testing.
