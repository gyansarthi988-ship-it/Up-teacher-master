# Phase 3H – Question Bank Intelligence & Quality Control

## Included

The Admin Control Centre now includes a Question Bank Quality Control panel. It reads up to the latest 1,000 questions and checks:

- Hindi and English question text availability.
- Exactly four options per single-choice question.
- Bilingual text on each option.
- Presence and linkage of the correct answer to one of the question's own options.
- Presence of an explanation.
- Topic mapping.
- Exact/normalised text duplicates as possible duplicate candidates.

The panel reports scanned totals, critical-error counts, warning counts and questions with no detected issues. Admins can filter by issue/status and search question text or ID.

## Review workflow

- Review: moves a question to `under_review`.
- Approve: moves a question to `approved`.
- Publish: moves a question to `published` and records `reviewed_by` and `published_at`.
- Return to draft: moves it back to `draft`.

Publishing is blocked in this panel while critical structural errors exist (wrong option count, missing answer, or answer not belonging to the question). Warnings remain visible and require human judgement.

## Technical notes

- New component: `admin/app/components/QuestionQualityCenter.tsx`.
- Admin page imports and renders the component.
- No database migration is required; existing `questions`, `question_options`, `question_answers`, and `question_explanations` tables are used.
- Access remains governed by existing Supabase authentication and RLS policies.
- Audit scope is limited to the latest 1,000 questions per refresh to avoid loading an unbounded question bank.
- Duplicate detection is a normalised text-match heuristic. It does not claim semantic/AI plagiarism detection.
- This phase does not generate translations, explanations or answer keys automatically. It identifies gaps for an editor to correct.
- Review actions update question status. A separate immutable review-history log is not added in this phase.

## Before release

1. Confirm admin roles can read all four question tables and update `questions` under RLS.
2. Confirm question status enum values match the Phase 2 migration.
3. Review duplicate candidates manually; similar wording can be legitimate.
4. Confirm official answers and explanations against trusted source material before publishing.
