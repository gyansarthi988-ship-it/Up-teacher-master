# Phase 3P – AI Doubt Solving & Study Assistant

## Included
- Bilingual Flutter doubt submission screen and recent personal history.
- Supabase Edge Function `answer-study-doubt` with authenticated-user validation.
- OpenAI API call performed server-side; provider key is never shipped in the app.
- Five-question-per-user-per-hour basic usage limit.
- Private user history and admin read-only review panel.
- AI safety prompt: clear explanations, no fabricated official notices/dates/citations, verify uncertain facts.

## Apply database migration
Run `supabase/migrations/0013_doubt_solving_ai_assistant.sql` after migrations 0001–0012.

## Configure Edge Function secrets
Set these in Supabase Edge Function secrets (never in Flutter, Next.js public variables, or GitHub):
- `OPENAI_API_KEY` – secret API key from the AI provider account.
- `OPENAI_MODEL` – optional; defaults to `gpt-4o-mini`.
Supabase project URL, anon key and service-role key are provided by the Supabase Edge Function runtime. Do not paste the service-role key into source code or chat.

## Deploy
Deploy function name `answer-study-doubt` with JWT verification enabled. The app invokes it using the signed-in Supabase session. Ensure the function runtime has `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` configured by the Supabase platform.

## Security notes
- Client cannot insert or edit doubt records directly; the Edge Function uses server credentials after validating the caller's JWT.
- Students can read only their own doubt history; admins can read all doubts.
- Basic rate limit is five requests per user per hour. For production scale, replace count-based throttling with an atomic rate-limit RPC/queue to avoid race conditions.
- AI output may be inaccurate. It is tutoring assistance, not an official answer key or legal/official notification.
- Do not place API keys in app source, `.env` files committed to Git, or screenshots.

## Not configured / not tested
No AI provider key was supplied and no live function was deployed. Flutter/Next production builds and runtime tests were not run. A live answer will work only after migration, secret configuration and function deployment.
