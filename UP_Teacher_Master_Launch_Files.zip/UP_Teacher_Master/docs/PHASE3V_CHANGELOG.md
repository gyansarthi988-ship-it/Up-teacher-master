# Phase 3V Changelog
- Added estimated Exam Readiness dashboard.
- Added readiness indicator breakdown, weak-topic list and subject accuracy bars.
- Added navigation drawer entry.
- Reuses existing analytics RPC; no SQL migration.
- No question bank content modified.
