# Phase 3W Changelog
- Added bilingual syllabus tracker screen.
- Added exam selector and subject/chapter/topic hierarchy.
- Added per-topic progress statuses and completion percentage.
- Added user-isolated persistence through RLS.
- Added migration 0017_user_syllabus_progress.sql.
