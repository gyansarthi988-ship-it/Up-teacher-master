# Phase 3K – Premium Content Access Control & Study Material Protection

## Included
- Student study-material catalogue screen in Flutter (English/Hindi).
- Published Free materials visible to signed-in students.
- Published Premium materials visible only while `has_premium_access()` is true.
- Private Storage objects can be selected / signed only when their path belongs to a published Free material or a Premium material with an active entitlement.
- Admin/content staff retain their existing content-management access.
- Material links are delivered as 10-minute signed URLs and copied for opening in a browser.
- Home drawer now includes Study Materials.
- `get_material_access_summary()` provides a small entitlement summary for future UI use.

## Migration
Run `supabase/migrations/0009_premium_content_access.sql` after migrations 0001–0008.

## Content publishing workflow
1. Upload PDF to the private `study-materials` bucket.
2. In Content Studio, create a matching `study_materials` row with the exact Storage object path.
3. Set `access_tier` to `free` or `premium`.
4. Keep status as `draft` until reviewed; change to `published` only when ready.
5. Premium materials are automatically filtered by the server-side membership entitlement.

## Security notes
- The client-side membership check is only for a friendly paywall. It is not the security boundary.
- Database RLS and Storage object policies enforce entitlement on every catalogue read and signed-URL request.
- Signed URLs are temporary (10 minutes); do not store or reuse them as permanent content URLs.
- Keep the Storage bucket private. Do not make `study-materials` public.
- Do not expose Supabase service-role credentials in Flutter or the browser admin app.
- External URLs are controlled by content staff. Prefer private Storage PDFs for material that must be protected; an external public URL cannot be made private by this app's RLS.

## Limitations / operational notes
- This phase provides protected catalogue and link delivery, not an in-app PDF reader or DRM. A recipient can still copy/download content while a signed URL is valid.
- Premium activation depends on Phase 3J migration and verified payment webhook deployment.
- No new payment provider or secrets are added in this phase.
- Run this migration only after Phase 3J migration 0008 has been applied.
