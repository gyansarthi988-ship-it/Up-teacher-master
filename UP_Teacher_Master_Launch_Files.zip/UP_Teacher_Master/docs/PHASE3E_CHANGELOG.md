# Phase 3E Changelog
- Connected study-plan tasks to topic-specific practice sessions.
- Added practice sessions from the wrong-question notebook.
- Added due-only spaced-revision sessions.
- Added automatic wrong-answer notebook synchronisation on submitted responses.
- Added authenticated RPC to retrieve due wrong-question IDs.
- Kept scoring and answer validation on the server-side submission RPC.
