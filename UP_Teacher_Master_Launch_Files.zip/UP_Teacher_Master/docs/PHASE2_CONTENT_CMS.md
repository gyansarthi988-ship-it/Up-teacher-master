# Phase 2 — Content Management System (CMS)

## What this phase adds

- Admin syllabus catalogue: examination pattern versions, subjects, chapters, topics, exam-subject mappings and exam-topic mappings.
- Bilingual MCQ authoring with four options, correct answer and explanations.
- Question review/publish workflow, question tags and source metadata.
- XLSX/XLS/CSV bulk question import (up to 500 rows per file).
- PDF uploads to a private Supabase Storage bucket, with draft/publish metadata.
- Student Android syllabus browser that reads only mapped, active syllabus topics.

## Apply the migration

In Supabase Dashboard → SQL Editor, run:

`supabase/migrations/0002_phase2_content_cms.sql`

Run Phase 1 migration first. The Phase 2 migration seeds general subjects but does not automatically map every subject to every exam. This is intentional: configure mappings only after verifying the official syllabus for the relevant recruitment cycle.

## Admin panel setup

```bash
cd admin
npm install
cp .env.example .env.local
# Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm run dev
```

Sign in with an authorised content/admin account. The Content Studio has four tabs:

1. **Syllabus:** create subjects, chapters, topics, map subjects to exams and map topics into an exam syllabus.
2. **Question Bank:** manually create bilingual MCQs. New questions are saved as Draft. Use Approve & Publish only after verifying the answer and explanation.
3. **Excel Import:** download the import template, upload XLSX/XLS/CSV, preview rows and import. The importer validates exam/subject codes, bilingual question content, four options, correct option, numeric marking values and optional topic UUID; it flags duplicate questions within the same file. Imported rows remain Draft.
4. **PDF Materials:** upload a PDF (maximum 50 MB) into the private `study-materials` bucket. Metadata is saved as Draft; publish only after review.

## Excel template

Use `UP_Teacher_Master_Question_Import_Template.xlsx`. Keep the column names unchanged. `exam_code` values are `SUPER_TET`, `TGT`, `PRT`, `JUNIOR`. `subject_code` must match the subject catalogue, for example `CDP`, `ENGLISH`, `MATHS`. `topic_id` is optional and, if supplied, must be a valid UUID.

## Security notes

- `question_answers` has no public/student read policy. Correct answers are not exposed to the student client.
- Only published questions, options, explanations and syllabus records are student-readable.
- Content-management writes require a permitted staff role and RLS.
- The PDF bucket is private. Student signed download links and premium entitlement checks are not yet implemented; those belong in the student content delivery/premium phases.
- The web client uses only the Supabase anon/publishable key. Never put the service-role key in browser or Flutter code.
- Imported questions are Draft; bulk import does not auto-publish.

## Current limitations / next steps

- The importer currently handles rows sequentially, detects duplicates within the uploaded file and is designed for controlled batches up to 500. It does not yet perform a full database-wide fuzzy duplicate search. For very large production imports, move parsing/validation to a server-side import job with resumability.
- Manual question editor currently supports single-choice MCQs with four options.
- Syllabus manager creates and maps catalogue records; editing/deactivation UI and source/version history can be expanded.
- PDF listing/publishing is present, but student-side signed URL delivery is not yet enabled.
- Test engine, scoring endpoint, subscriptions, push notifications and complete performance analytics are later phases.

## Phase 2 acceptance checklist

- [ ] Apply migration 0002 after migration 0001.
- [ ] Confirm the owner/content staff can create subjects, chapters and topics.
- [ ] Add exam-pattern version and official source details; map subjects and syllabus topics only after official verification.
- [ ] Create a bilingual question and confirm it is saved as Draft.
- [ ] Confirm a student session cannot read `question_answers`.
- [ ] Approve/publish a question and verify it is visible through the published-question read policy.
- [ ] Import the sample Excel file and confirm it creates Draft questions.
- [ ] Confirm invalid exam/subject codes and missing options are rejected.
- [ ] Upload a PDF and confirm the storage bucket remains private.
- [ ] Confirm the Android app opens the exam syllabus and shows only mapped topics.
