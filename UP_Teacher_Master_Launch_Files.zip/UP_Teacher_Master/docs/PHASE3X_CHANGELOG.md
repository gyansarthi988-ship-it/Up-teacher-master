# Phase 3X Changelog
- Enhanced study material library with search and filters.
- Added topic hierarchy labels.
- Added per-user material completion tracking.
- Added migration 0018_user_material_progress.sql and user-isolated RLS policies.
- Retained existing premium gating and signed URLs.
