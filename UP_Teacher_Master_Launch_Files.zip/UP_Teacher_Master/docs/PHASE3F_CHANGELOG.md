# Phase 3F changelog
- Added bilingual mock-test catalogue screen.
- Connected exam syllabus screen to active exam-specific mock templates.
- Extended mock runner to accept template configuration.
- Added subject distribution and optional difficulty distribution selection.
- Preserved secure server-side scoring through `submit_test_attempt`.
- Added template JSON contract and publishing governance documentation.
