# GitHub Cloud Build Setup — UP Teacher Master

This repository contains a GitHub Actions workflow for a **debug APK used for first-device testing**. It is not a Play Store release build.

## Before running the workflow

1. Upload the complete `UP_Teacher_Master` project folder to the root of your GitHub repository.
2. Open the repository on GitHub.
3. Go to **Settings → Secrets and variables → Actions → New repository secret**.
4. Add these two repository secrets:
   - `SUPABASE_URL` — the Supabase project URL.
   - `SUPABASE_ANON_KEY` — the Supabase publishable/anon key only.
5. Never add a Supabase `service_role` key, database password, OAuth client secret, or signing private key to the mobile app or a public repository.

## Build an APK

1. Open the repository's **Actions** tab.
2. Select **Build UP Teacher Master Android APK**.
3. Press **Run workflow** and confirm.
4. Wait for the workflow to finish successfully.
5. Open the completed run and download the artifact named `up-teacher-master-debug-apk`.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.

The workflow also runs automatically when files under `mobile/` are pushed to the `main` branch.

## Admin panel check

The `Admin Panel Build Check` workflow runs on admin changes. It checks whether the Next.js admin project can build. Deployment to Vercel/Netlify is a separate step.

## Important limitations

- A successful debug APK build proves compilation, not that phone OTP, Google OAuth, database policies, syllabus data, or all app flows are production-ready.
- Supabase Phone Auth needs an SMS provider or configured test numbers.
- Google OAuth requires the correct Supabase and Google Cloud redirect configuration.
- A signed release APK/AAB and Play Store release signing are intentionally not configured yet.
- GitHub Actions workflows must be present in the repository before they can run.
