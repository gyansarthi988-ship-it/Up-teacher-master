# Phase 3Q — AI Personal Study Mentor & Adaptive Learning

## Included
- Student goal setup: target exam, optional target date, and daily study minutes.
- Dashboard with attempts, correct answers, and accuracy from submitted practice/mock-test data.
- Reuses the existing Phase 3D 7-day learning plan and wrong-question notebook RPCs.
- Hindi/English UI and a manual refresh action.
- New Supabase migration: `0014_ai_personal_study_mentor.sql`.

## Database setup
Apply migrations `0001` through `0014` in order. Phase 3Q adds one table and two authenticated-user RPCs. It does not require an AI provider key: recommendations are derived from the learner's recorded results and the existing rule-based learning-plan engine. The word “AI” in the product label should not be interpreted as a generative model call in this phase.

## Behaviour and safeguards
- A user can save only their own preferences; the RPC uses `auth.uid()` and validates the active exam and daily time range.
- Dashboard data is scoped to the authenticated user.
- If the user has not completed enough practice, the dashboard asks them to complete practice/mock tests before weak-topic recommendations can be generated.
- Recommendations are advisory, not a guarantee of exam success.

## Dependencies
Requires Phase 3D migration `0006_smart_learning_plan.sql`, Phase 3A practice schema `0003_practice_mock_engine.sql`, and the base exam catalogue.

## Not included / not verified
No generative AI API integration, calendar reminders, push scheduling, or automatic background plan regeneration is included. Flutter/Next.js builds, Supabase deployment, and device runtime were not run for this package. User-side manual testing remains outstanding.
