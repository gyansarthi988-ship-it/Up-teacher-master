# UP Teacher Master — Owner Setup Status

## Already completed
- Supabase project: `https://iuvnrtuycyeaxnkqsfrw.supabase.co`
- Phase 1 database migration: successful
- Phase 2 content CMS migration: successful
- Owner account role: `super_admin`
- Admin web environment: `admin/.env.local` configured
- Flutter app config: Supabase URL and public anon key configured

## Important
- The key in this package is the Supabase anon/public key. Never add a `service_role` or secret key to this project.
- `.env.local` is excluded by `.gitignore`; keep it private and do not commit it to a public repository.
- The project has not been deployed or compiled in this environment.

## Run the admin panel on a computer
1. Install Node.js 20 or newer.
2. Open a terminal in `admin/`.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open `http://localhost:3000`.
6. Sign in using the same Supabase email/password account that was promoted to `super_admin`.

## Authentication note
The admin panel currently uses Supabase email/password authentication. If the owner account was created with a phone-only OTP login, add/confirm an email and set a password in Supabase Auth before using the web admin login. Do not share the password.

## Still pending
- Configure Supabase Phone OTP provider and SMS provider.
- Configure Google OAuth provider and redirect URLs.
- Install dependencies and run a real Next.js production build.
- Generate and test Android APK/AAB with Flutter SDK.
- Deploy the admin panel to a hosting provider.
