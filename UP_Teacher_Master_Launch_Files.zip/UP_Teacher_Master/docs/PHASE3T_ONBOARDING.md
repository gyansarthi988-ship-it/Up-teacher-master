# Phase 3T – First Login Onboarding

## Included
- First-login setup screen after successful authentication.
- Primary exam selection: Super TET, TGT, PRT, Junior.
- App language preference: Hindi, English, bilingual.
- Daily study target from 15 to 360 minutes.
- Saves the signed-in user's settings in `user_onboarding_preferences`.
- Returning users with a completed setup proceed to Home.

## Supabase
Apply `supabase/migrations/0016_user_onboarding_preferences.sql` after migrations 0001–0015.

The table uses row-level security. A signed-in user can read or change only their own row.

## Important rollout behaviour
If the migration has not been applied, the app gate catches the missing-table error and allows the user to reach Home. This avoids blocking existing users, but first-login onboarding will not be shown until migration 0016 is applied.

## Manual verification checklist (owner-operated)
1. Sign in with a new account after applying migration 0016.
2. Confirm onboarding appears.
3. Choose exam, language and daily goal; save.
4. Confirm Home opens.
5. Sign out and sign in again; confirm onboarding is skipped.
6. Check that the saved row belongs only to the signed-in user's UID.
