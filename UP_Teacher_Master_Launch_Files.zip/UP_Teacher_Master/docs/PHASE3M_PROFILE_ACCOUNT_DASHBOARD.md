# Phase 3M — Profile, Account Dashboard & Subscription Management

## Included
- New bilingual Flutter `ProfileScreen`.
- Reads the signed-in user's profile from `public.profiles` and membership summary from `get_my_membership()`.
- Allows the user to update their own full name and profile phone field under the existing profile RLS policy.
- Shows account email/phone, membership state, and active subscription expiry when available.
- Links to the existing Premium Membership screen for plans and purchase history.
- Adds Profile navigation to the Home drawer.
- Provides sign-out from the profile screen.

## Database
No new migration is required. Phase 1 already creates `profiles`, enables RLS, and permits a user to update only their own profile row. Phase 3J provides `get_my_membership()` and the purchase history summary.

## Important notes
- The profile phone field is profile information only; editing it does not change the authentication phone number.
- Account deletion is intentionally not exposed in the client because secure deletion requires a server-side administrative workflow and a clear confirmation process.
- Profile screen requires the existing Supabase configuration and migrations 0001–0010.
- This source package has not been built or runtime-tested on a device. The user handles manual device testing.
