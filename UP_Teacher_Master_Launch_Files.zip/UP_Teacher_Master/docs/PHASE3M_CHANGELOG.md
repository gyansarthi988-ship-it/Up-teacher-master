# Phase 3M Changelog
- Added bilingual profile and account dashboard screen.
- Connected profile editing to the existing `profiles` table and own-row RLS policy.
- Connected membership status to `get_my_membership()`.
- Added navigation from Home drawer and links to membership/purchase history.
- No SQL migration added.
