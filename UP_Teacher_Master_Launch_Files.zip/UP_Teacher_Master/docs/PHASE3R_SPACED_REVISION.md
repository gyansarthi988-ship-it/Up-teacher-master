# Phase 3R – Spaced Revision & Weak Topic Mastery

## What this phase adds
- A dedicated bilingual Spaced Revision screen.
- Due-question queue from the learner's own wrong-question notebook.
- Explanation reveal before the learner rates recall.
- Four recall ratings: Again, Hard, Good and Easy.
- Adaptive review intervals and ease factor stored per learner/question.
- Review history table and mastery tracking (five consecutive successful reviews; an Again rating resets the success streak).
- User-scoped security: review queue and submission RPCs only operate on `auth.uid()` data.

## Database deployment
Run `supabase/migrations/0015_spaced_revision_mastery.sql` in the Supabase SQL Editor after migrations 0001–0014 have been applied.

## How it works
Only questions already present in the user's wrong-question notebook and due today are shown. The learner reveals the explanation, then selects a recall rating. The server calculates the next review date and updates mastery status. The client cannot directly alter the review schedule or another user's records.

## Notes
- This is an adaptive spaced-repetition workflow, not a generative AI feature.
- A question becomes mastered after five successful ratings (Hard, Good or Easy) in sequence. Selecting Again resets that streak.
- Existing wrong-question notebook entries are supported through default values for the new scheduling fields.
- Flutter build, Supabase deployment and device runtime were not performed as part of packaging. The project source and SQL migration are provided for deployment; the user handles manual testing.
