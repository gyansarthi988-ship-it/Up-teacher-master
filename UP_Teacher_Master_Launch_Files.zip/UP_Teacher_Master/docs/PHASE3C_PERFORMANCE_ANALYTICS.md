# Phase 3C — Performance Analytics

## Included
- Student-scoped analytics RPC: `get_my_performance_analytics(p_exam_id uuid default null)`.
- Overall totals: submitted attempts, questions seen/attempted, correct/wrong/unanswered, weighted score, average percentage and accuracy.
- Last 20 submitted-attempt trend.
- Subject-wise accuracy and topic-wise accuracy.
- Weak-topic flag: accuracy below 50% after at least 3 answered questions in that topic.
- Flutter `PerformanceAnalyticsScreen`, reachable from the Home drawer under **My Performance**.
- Hindi/English labels and pull-to-refresh.

## Database deployment
Apply `supabase/migrations/0005_performance_analytics.sql` after migrations 0001–0004. It creates a read-only, authenticated RPC scoped to `auth.uid()`; clients cannot request another user's analytics.

## Notes
- Analytics are based only on submitted attempts and recorded responses. In-progress attempts are excluded.
- Topic analytics require questions to have a `topic_id`; subject analytics require valid `subject_id` mappings.
- Accuracy is correct answers divided by answered questions. Average percentage is the mean of each attempt's score percentage. Overall score/max score are weighted totals.
- Weak-topic threshold is currently <50% accuracy with at least 3 answered questions. This is a product rule and can be tuned later.
