# Phase 3D Changelog

- Added migration `0006_smart_learning_plan.sql`.
- Added learner-scoped learning plan task storage and wrong-question notebook.
- Added `generate_my_learning_plan` and `get_my_learning_plan` RPCs.
- Added bilingual `SmartLearningScreen` with exam selector, plan generation, task completion, wrong-question review, and mastered/revise-again controls.
- Added Smart Study Plan entry to the home drawer.
- Added phase documentation and deployment order notes.
