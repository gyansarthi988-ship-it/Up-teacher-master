# Phase 3W – Complete Syllabus Tracker

## Included
- Exam selector for active examinations.
- Published syllabus topics grouped by subject and chapter.
- Per-user topic status: Not started, In progress, Completed, Revise again.
- Completion count and percentage for the selected exam.
- Progress stored per authenticated user; one learner cannot read or update another learner's progress.
- Hindi/English labels and refresh.

## Database migration
Apply `supabase/migrations/0017_user_syllabus_progress.sql` in Supabase SQL Editor.
This creates `user_topic_progress` with row-level security and authenticated-user policies.

## Content dependency
The tracker displays only syllabus items already entered and active in `syllabus_items`, linked to active topics, chapters and subjects. It does not invent or preload official syllabus content. Admin must populate and verify the syllabus catalogue.

## Owner manual verification
After applying migration and publishing syllabus content:
1. Open Syllabus Tracker and choose an exam.
2. Change a topic status and navigate away/back.
3. Confirm the status persists and completion percentage updates.
4. Confirm another account cannot see this account's progress.
