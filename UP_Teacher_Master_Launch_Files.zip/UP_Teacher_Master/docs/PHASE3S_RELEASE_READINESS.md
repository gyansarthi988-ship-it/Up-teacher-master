# Phase 3S — Release Readiness & Automated Build Gate

## Purpose
This phase prepares the existing source tree for a repeatable first Android build. It does not add exam questions or change the question bank.

## Included
- `scripts/release_preflight.py`: checks required source folders, sequential SQL migration numbering, and obvious service-role credential patterns in tracked source.
- `.github/workflows/project-preflight.yml`: runs source preflight, Flutter static analysis, Flutter automated tests, and a debug APK build on GitHub Actions.
- APK artifact upload for retrieval from the completed Actions run.

## GitHub setup needed
Repository Actions secrets:
- `SUPABASE_URL` — project URL.
- `SUPABASE_ANON_KEY` — public anon/publishable key only.

Never add the Supabase `service_role` key, database password, OAuth client secret, or Android signing key to a public repository or mobile build secrets.

## Run
1. Upload/merge the complete project into the GitHub repository root.
2. Open **Actions**.
3. Select **UP Teacher Master Project Preflight**.
4. Select **Run workflow**.
5. When complete, download `up-teacher-master-preflight-debug-apk` from the run's Artifacts section.

## Important boundaries
- GitHub Actions has not been run from this package creation environment.
- A successful workflow is evidence of source analysis, automated tests, and compilation only; it does not prove OTP, Google sign-in, Supabase RLS, payments, push notifications, or all user journeys work on a physical device.
- The APK is a debug build for initial device installation, not a Play Store signed release.
- This phase does not deploy SQL migrations to Supabase.
- The owner remains responsible for manual device testing, as requested.
