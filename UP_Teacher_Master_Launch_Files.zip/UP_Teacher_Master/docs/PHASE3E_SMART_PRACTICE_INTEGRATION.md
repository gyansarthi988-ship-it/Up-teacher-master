# Phase 3E – Smart Practice Engine Integration

## Delivered
- Learning-plan task cards now open topic-specific MCQ practice.
- Wrong Question Notebook can launch a combined practice session for all unmastered wrong questions.
- Due Revision launches only wrong questions whose review date is due.
- PracticeScreen accepts either a topic ID or a fixed list of question IDs.
- New database trigger synchronises submitted incorrect answers into the learner's private wrong-question notebook. A correct retry schedules another review three days later.
- New `get_my_due_wrong_question_ids(uuid)` RPC returns only the signed-in user's due question IDs for the selected exam.

## Migration
Apply `0007_smart_practice_integration.sql` after migrations `0001` through `0006`.

## Important implementation notes
- The submit RPC inserts response rows while the attempt is still `in_progress`; therefore the trigger intentionally looks up the owning attempt without requiring `status='submitted'`.
- Question retrieval remains restricted to published questions for the selected exam. The server-side `submit_test_attempt` RPC remains responsible for scoring and validating selected options.
- The wrong-question notebook remains scoped to `auth.uid()` through its existing RLS policies and the new security-definer RPC checks `auth.uid()` explicitly.
- Existing content needs published questions with answer keys and options before practice can run.

## Verification boundary
Source and migration files are included. Flutter compilation, Supabase SQL execution, and live/device testing have not been performed. The project owner will perform manual testing.
