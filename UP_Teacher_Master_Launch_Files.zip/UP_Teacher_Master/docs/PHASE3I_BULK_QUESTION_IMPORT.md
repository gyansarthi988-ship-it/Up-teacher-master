# Phase 3I – Question Import & Bulk Processing Engine

## Delivered
- Dedicated Admin Panel bulk importer for XLSX, XLS and CSV.
- Downloadable bilingual question import workbook template.
- Automatic column-name matching with editable mapping before validation.
- Supports up to 2,000 rows per file; split larger question banks into batches.
- Pre-import validation for exam and subject codes, question text, four options, answer key, marks, negative marks, difficulty, topic IDs and year format.
- Duplicate screening within the uploaded file and against the latest 10,000 database question records using normalised question text.
- Validation preview with valid/rejected counts; only valid rows are eligible for import.
- Downloadable Excel error report listing row number and reasons.
- Imports questions, options, answer and explanation sequentially; imported questions remain Draft and must pass quality review before publishing.
- Attempts to delete a partially-created question if one of its dependent records fails.

## Important behaviour and limitations
- This is heuristic duplicate detection, not semantic AI similarity detection.
- Database duplicate scan is limited to the latest 10,000 questions visible to the signed-in admin under RLS.
- Import is sequential, not a single database transaction. Failed child-record writes trigger best-effort cleanup; verify the database before retrying a batch if a network interruption occurs.
- Source metadata is optional. Official answers and translations must be verified by a human editor.
- No new SQL migration is required; existing Phase 2 question tables are used.
- Existing ContentStudio import remains available; the new dedicated centre is added to the admin dashboard.

## Manual release checks
1. Confirm admin RLS can read exams, subjects, topics and question tables and insert question-related records.
2. Upload a small workbook with one valid and one invalid row; verify preview and error report.
3. Import a small batch; confirm each imported question has four options, one answer and an explanation row.
4. Confirm imported questions are Draft and not visible in student practice until reviewed and published.
5. Test duplicate detection and retry behaviour with a copy of an already-imported workbook.
