# Phase 3O Changelog
- Added Firebase Core and Firebase Messaging Flutter dependencies.
- Added authenticated FCM token registration and token refresh handling.
- Added push token table migration `0012_push_notification_tokens.sql` with owner-only RLS.
- Added admin-only Supabase Edge Function `send-push-notification` using Firebase Cloud Messaging HTTP v1.
- Added Send Push action for published announcements in the Admin Panel.
- Added Android notification permission and default notification channel metadata.
- Added Firebase setup and secrets deployment guide.
