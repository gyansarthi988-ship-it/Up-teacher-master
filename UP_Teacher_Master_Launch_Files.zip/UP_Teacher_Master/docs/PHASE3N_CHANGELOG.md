# Phase 3N Changelog

- Added announcements schema and per-user read receipts.
- Added RLS policies for published feed, admin management and user-owned receipts.
- Added admin bilingual announcement manager.
- Added Flutter bilingual notifications centre and drawer entry.
- Added Phase 3N setup and limitations documentation.
