# Phase 3Y Changelog
- Added topic_id to the spaced-revision queue RPC payload.
- Added related published study-material cards to each revision question.
- Preserved premium membership checks and signed Storage URL handling.
- Added migration 0019_revision_material_links.sql.
