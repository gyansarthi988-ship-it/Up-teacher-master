# Phase 3U – Daily Study Command Centre

## Included
- New bilingual dashboard screen.
- Daily target card linked to the existing personal study mentor preferences.
- Summary cards powered by the existing `get_my_performance_analytics` RPC.
- Quick access to spaced revision, smart learning plan, personal mentor and detailed analytics.
- Dashboard shortcut on the Home screen and navigation drawer.

## Database
No new migration is required. This phase reuses RPCs from migrations 0005, 0006/0014 and 0015-era features. Ensure migrations 0005, 0006, 0014 and 0015 have been applied before relying on all dashboard cards.

The dashboard handles unavailable RPC data with a friendly message and does not expose other users' records; the underlying RPCs are user-scoped.

## Manual verification checklist
1. Sign in and open Daily Study Command Centre from Home.
2. Confirm summary cards show your own submitted-test data.
3. Open each quick action and return to dashboard.
4. Refresh dashboard after submitting a practice/mock test.
5. Check Hindi/English labels.
