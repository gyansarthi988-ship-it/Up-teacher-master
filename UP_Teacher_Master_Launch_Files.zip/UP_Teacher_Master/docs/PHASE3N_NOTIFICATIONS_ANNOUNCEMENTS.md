# Phase 3N – Notifications, Announcements & Exam Updates

## Included
- Admin announcement composer in the Next.js admin panel.
- English and Hindi title/body fields.
- Categories: General, Exam Update, Important, Maintenance.
- Optional target-exam metadata.
- Draft/publish toggle, recent list, unpublish and delete.
- Flutter in-app notification centre with bilingual display, refresh, unread marker and per-user read receipts.
- Supabase RLS: signed-in users can read only published, currently valid announcements; only admins can create/update/delete; users can manage their own read receipts.

## Migration
Run `supabase/migrations/0011_notifications_announcements.sql` after migrations 0001–0010.

## Important limitations
- This phase implements in-app announcements, not Android push notifications. FCM/APNs credentials and a trusted push delivery function are not configured here.
- `target_exam_id` is stored for targeting metadata; current feed displays all published announcements to signed-in users. Exam-specific feed filtering is a later enhancement.
- Admin publishing is immediate or draft; scheduled delivery UI is not included.
- Notifications are not sent to email/WhatsApp.
- No secrets or service-role keys are included.

## Deployment
After migration, deploy the updated admin panel and build the Flutter app. Existing users must sign in to read announcements. Manual device testing is the project owner's responsibility.
