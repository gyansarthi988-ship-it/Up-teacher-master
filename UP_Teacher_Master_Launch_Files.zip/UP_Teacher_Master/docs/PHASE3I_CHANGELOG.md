# Phase 3I Changelog
- Added QuestionBulkImportCenter to the Admin Control Centre.
- Added auto column mapping, validation preview, duplicate screening, valid-only import and XLSX error export.
- Added Phase 3I operator notes and release checks.
- No database migration added.
