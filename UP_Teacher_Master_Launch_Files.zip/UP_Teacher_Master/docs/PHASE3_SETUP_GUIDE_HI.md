# Phase 3 Setup — आसान हिन्दी निर्देश

1. GitHub पर पूरा नया project upload करने के बाद `supabase/migrations/0003_practice_mock_engine.sql` खोलें।
2. Supabase Dashboard → SQL Editor → New Query में इस SQL file का पूरा content paste करके Run करें।
3. ध्यान दें: Phase 1 और Phase 2 migrations पहले से सफलतापूर्वक लागू होनी चाहिए। Phase 3 migration केवल एक बार चलाएँ।
4. Admin Content Studio में किसी topic के लिए प्रश्न बनाकर publish करें। हर प्रश्न के लिए options और सही answer key जोड़ें। Explanation वैकल्पिक है।
5. GitHub → Actions → Build UP Teacher Master Android APK → Run workflow करें।
6. Build सफल होने पर workflow run के Artifacts section से `up-teacher-master-debug-apk` डाउनलोड करें।
7. पहले debug APK को test device पर जाँचें; production release/signing बाद में करेंगे।

## सुरक्षा
- केवल Supabase anon/public key client app में इस्तेमाल करें।
- `service_role` key को GitHub, APK या mobile app में कभी न डालें।
- विद्यार्थी को correct answer table से सीधे पढ़ने की अनुमति नहीं है; score secure RPC से calculate होता है।

## जरूरी सीमा
इस चरण में topic-wise practice UI और server-side attempt scoring तैयार है। Full exam mock builder, leaderboard, detailed analytics और premium gating अगले चरणों में पूरे होंगे। अभी Flutter SDK उपलब्ध न होने के कारण स्थानीय Flutter compilation/device testing नहीं हुई है।
