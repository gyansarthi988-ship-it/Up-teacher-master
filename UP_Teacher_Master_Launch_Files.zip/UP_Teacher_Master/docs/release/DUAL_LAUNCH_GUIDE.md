# UP Teacher Master – Direct APK + Google Play Launch Guide

## Included in this kit
- `.github/workflows/android-release.yml`: builds signed release APK and Play Store AAB.
- Android Gradle signing configuration.
- Privacy policy HTML template.
- Store listing draft.

This is a launch-preparation source package. It does not publish the app, create your signing key, deploy Supabase, or host files.

## A. Create and back up the permanent upload key
On a trusted computer with Java `keytool`:
```bash
keytool -genkeypair -v -keystore upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias uptm-upload
```
Keep two secure offline backups. Never upload the keystore or passwords to GitHub or send them in chat. Losing the key can complicate future updates.

Base64 encode:
- Linux/macOS: `base64 -w 0 upload-keystore.jks`
- PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload-keystore.jks"))`

## B. GitHub Actions secrets
Repository → Settings → Secrets and variables → Actions. Add:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY` (public anon/publishable key only; never service_role)
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEY_ALIAS` (e.g. `uptm-upload`)
- `ANDROID_KEY_PASSWORD`
- `ANDROID_STORE_PASSWORD`

First upload the contents of the `UP_Teacher_Master` folder to the root of your GitHub repository (not the ZIP file itself). Keep `.github/workflows/android-release.yml` in place. Then Actions → **Build UP Teacher Master Release APK and AAB** → Run workflow. Download its artifact:
- `app-release.apk`: direct distribution
- `app-release.aab`: Google Play Console upload

## C. Direct APK launch
Upload the signed APK to your own HTTPS website or trusted file host. Create a download page showing app version, release date, file size, publisher and support email. Tell users to install updates only from your official link. Do not distribute debug APKs.

## D. Google Play launch
Create the app in Play Console, upload the AAB to Internal testing first, then complete the Console's current requirements for app access, data safety, ads, content rating, target audience, privacy policy and production access. Requirements vary by account and can change; follow the current Console prompts. Use Play App Signing when offered.

Prepare store assets:
- 512×512 PNG app icon
- 1024×500 feature graphic
- Phone screenshots (at least 2; more are useful)
- Short description (maximum 80 characters)
- Full description, support email and website

If login is required, provide Play reviewers with a dedicated review account and clear access instructions. Do not provide your personal account credentials.

## E. Privacy policy – must complete
Edit `privacy-policy-template.html`: replace all bracketed placeholders, verify the data collected by every SDK (including AI and payment providers), state the actual retention/deletion process and publisher contact, then host it at a public HTTPS URL without sign-in. Use that same URL in Play Console and provide an account deletion path consistent with current Play requirements.

## F. Production checks before submission
- Confirm migrations 0003–0019 have been applied in order after 0001 and 0002. Do not rerun migrations already applied.
- Confirm production Supabase phone/SMS and Google OAuth providers and redirect URL.
- Confirm Firebase production config and push notifications, or remove unsupported notification claims.
- Confirm premium entitlement, payment flow, refunds, restore/cancellation and customer support. Google Play payment rules for digital content may require Play Billing; do not assume an external Razorpay flow is permitted for in-app digital content.
- Verify RLS and ensure no service-role key is in mobile/admin client code.
- Increase `versionCode` for every release.
- Confirm final package ID remains `com.rsglobalacademy.upteachermaster`.

## Honest status
No APK/AAB has been built, signed, installed or device-tested in this package. No Play Console submission, APK hosting, privacy-policy hosting or Supabase deployment has occurred. No keystore is included. Manual testing and account setup are handled by the project owner.

## G. What I need to continue the live setup
Send the public GitHub repository URL after the source folder has been uploaded. I can then inspect the repository state and guide the next release step. I cannot access or change your GitHub/Play Console account unless a supported account connection is explicitly provided.
