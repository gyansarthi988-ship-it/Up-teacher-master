# Phase 3F – Smart Mock Test & Exam Pattern Engine

## Delivered
- Exam-specific published mock-test catalogue backed by `mock_test_templates`.
- Bilingual template title/description, duration, question count, marks, language mode and premium flag.
- Template launches the existing timed mock runner with its own configuration.
- Subject-wise question distribution and optional difficulty distribution are applied before the test starts.
- Questions are shuffled for each attempt; only published questions are eligible.
- Correct answer keys are not selected by the mobile client. Existing `submit_test_attempt` RPC remains the only scoring path.
- Exam content page now exposes a Full-Length Mock Tests entry.

## Template JSON contract
Store this in `mock_test_templates.question_selection`:

```json
{
  "strategy": "random",
  "published_only": true,
  "subject_distribution": {
    "SUBJECT_UUID_1": 30,
    "SUBJECT_UUID_2": 20
  },
  "difficulty_distribution": {
    "SUBJECT_UUID_1": {"easy": 5, "moderate": 20, "difficult": 5},
    "SUBJECT_UUID_2": {"easy": 5, "moderate": 10, "difficult": 5}
  }
}
```

`subject_distribution` keys must be actual `subjects.id` UUIDs mapped to the selected exam through `exam_subjects`. Counts should sum to the template's `question_count`. Difficulty distribution is optional and nested by subject UUID; if omitted for a subject, that subject pool is random. Publish only after enough approved/published questions exist for every requested subject/difficulty combination.

## Pattern governance
- `exam_pattern_id` links a template to the verified pattern record in `exam_patterns`.
- The app displays only active templates for the selected exam.
- Content administrators own pattern verification, source URL, effective dates, marks and negative marking policy.
- The runner's server-side scoring currently uses each question's `marks` and `negative_marks`; content staff must align those values with the selected official pattern before publishing a template.
- Premium templates are shown but launch is gated until the premium entitlement/billing phase is implemented.

## Migration
No new migration is required. Phase 3F uses the existing `0004_mock_test_templates.sql`, question bank schema, and `0003_practice_mock_engine.sql` secure submission RPC. Apply migrations `0001` through `0007` in order for the full preceding feature set.

## Verification status
Source-level changes and package structure only. Flutter compilation, live Supabase queries, official exam-pattern validation, and device runtime testing have not been performed. Manual testing remains with the project owner.
