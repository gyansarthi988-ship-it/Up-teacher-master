# Promote your own account to Super Admin

1. Create your first user by signing in to the mobile app or Supabase Auth.
2. In Supabase Dashboard > Authentication > Users, copy that user's UUID.
3. Open SQL Editor and run this statement after replacing the UUID:

```sql
insert into public.user_roles(user_id, role)
values ('YOUR-AUTH-USER-UUID', 'super_admin')
on conflict (user_id, role) do nothing;
```

Never expose the Supabase `service_role` key in Flutter, browser JavaScript, or a public repository. Do not provide admin registration in the public app.
