# Phase 3B — Full Mock Test Engine

## Delivered source
- `mobile/lib/screens/mock_test_screen.dart`: bilingual timed test runner, question palette, previous/next navigation, mark-for-review, answer selection, confirmation, auto-submit on timeout and result summary.
- `supabase/migrations/0004_mock_test_templates.sql`: admin-managed mock test blueprints with exam pattern, duration, question count, marks, negative marks, language and premium visibility settings.

## Screen integration
Open the screen from an exam/mock-test listing after obtaining the exam UUID:

```dart
Navigator.push(context, MaterialPageRoute(
  builder: (_) => MockTestScreen(
    examId: examId,
    durationMinutes: 120,
    questionCount: 100,
    language: 'hi', // or 'en'
  ),
));
```

Import:
```dart
import 'screens/mock_test_screen.dart';
```

## Scoring and answer-key protection
The client reads published question text and options only. It does not query `question_answers`. On submission it calls the existing `submit_test_attempt` RPC with question IDs and selected option IDs. The database function validates each option against its question, calculates positive/negative marks and persists the result. The RPC accepts at most 300 questions.

## Template configuration
`mock_test_templates.question_selection` is a JSON configuration field intended for future section/topic-level distribution rules. Current mobile runner accepts explicit duration and question count; the next integration step is loading these values from active templates and selecting a balanced question set server-side.

## Apply migration
Run `supabase/migrations/0004_mock_test_templates.sql` in Supabase SQL Editor after Phase 3 migration `0003_practice_mock_engine.sql`.

## Manual testing
Owner handles all manual device and live-project testing. This package is a development deliverable; do not treat it as a claim that a production APK has been built or deployed.
