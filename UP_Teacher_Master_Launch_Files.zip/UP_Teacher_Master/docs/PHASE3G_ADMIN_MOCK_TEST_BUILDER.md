# Phase 3G — Admin Mock Test Builder

## Purpose
Adds an admin-side builder to create and manage rows in `public.mock_test_templates` using the existing Supabase schema. No new database migration is required.

## Features
- Select an examination and optionally link an existing exam-pattern version.
- Set bilingual title and descriptions, duration, question count, total marks, correct-answer marks, negative marks, language, premium flag and display order.
- Store the question-selection JSON used by the mobile mock-test catalogue, including `subject_distribution`, `difficulty_distribution`, `strategy` and `published_only`.
- Create, edit, publish, unpublish and delete unpublished templates.
- Prevent publishing changes from being silently destructive; active templates must first be unpublished before deletion.
- Check duration/question count against a linked pattern when those pattern values are present.

## Access and security
The component is shown inside the existing authenticated admin page. Database access remains protected by the RLS policies on `mock_test_templates`; only users for whom `public.can_manage_content()` is true can manage templates. The component does not use a service-role key.

## Setup
1. Ensure Phase 1–3B migrations have been applied, especially `0004_mock_test_templates.sql`.
2. Configure the admin app's public Supabase URL and anon key using its environment file.
3. Sign in with a user who has a content-management role.
4. Open the Admin Control Panel and use **Mock Test Builder**.

## Configuration JSON example
Replace the example subject UUID keys with actual `subjects.id` UUID values:

```json
{
  "strategy": "random",
  "published_only": true,
  "subject_distribution": {
    "SUBJECT_UUID_1": 30,
    "SUBJECT_UUID_2": 20
  },
  "difficulty_distribution": {
    "easy": 30,
    "moderate": 50,
    "difficult": 20
  }
}
```

The admin builder stores this JSON as supplied after JSON parsing. It does not certify that an exam pattern is official, nor does it guarantee question availability for each subject/difficulty. Confirm the current official notification and populate the question bank before publishing.

## Limitations
- Premium flag is metadata only; subscription/payment entitlement enforcement is a separate phase.
- Existing mobile selection behavior must be checked against the configured distribution semantics before relying on strict quotas.
- No Flutter build, Next.js build, Supabase runtime test or device test is claimed for this source package.
