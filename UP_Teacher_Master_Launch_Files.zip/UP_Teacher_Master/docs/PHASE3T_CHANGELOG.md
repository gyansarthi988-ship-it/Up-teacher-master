# Phase 3T Changelog

- Added bilingual first-login onboarding.
- Added primary exam, language and daily study goal preferences.
- Added Supabase migration 0016 with user-owned RLS policies.
- Updated AppGate to route new users through onboarding and returning users to Home.
- Existing users are not blocked if migration 0016 is not yet deployed.
- No question bank content was added or modified.
