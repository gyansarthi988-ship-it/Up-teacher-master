# Phase 3S Changelog

- Added a repeatable source preflight script.
- Added a unified GitHub Actions quality gate for Flutter analysis, automated tests, and debug APK compilation.
- Added APK artifact retention for 14 days.
- Added release safety notes covering public keys, privileged secrets, debug builds, and limits of CI evidence.
- No question-bank content was added or modified.
- No Supabase migration was added in this phase.
