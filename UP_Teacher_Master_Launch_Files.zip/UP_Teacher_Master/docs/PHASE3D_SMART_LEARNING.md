# Phase 3D — Smart Learning & Personalised Study Plan

## Delivered
- Personalised 7-day plan generated from the signed-in learner's submitted attempts.
- Up to five weakest topics (accuracy below 70%, with at least two answered questions) are prioritised.
- Topic practice tasks are scheduled for today, then revision on day 2, day 4 and day 7 (day offsets 0, 1, 3 and 6).
- Wrong-question notebook is synchronised from submitted wrong answers and tracks repeat mistakes.
- Learners can mark tasks complete and mark a question mastered or put it back into revision.
- Bilingual Smart Study Plan screen and home drawer navigation.
- User-scoped RLS and authenticated RPCs.

## Database migration
Run `supabase/migrations/0006_smart_learning_plan.sql` after migrations 0001–0005.

## Important behaviour
- The plan is based on submitted practice/mock attempts; no test history means no inferred weak topics.
- The generated plan is a seven-day rolling window. Existing task rows are preserved; duplicate topic/task/date rows are not inserted again.
- Wrong-question records are deduplicated per learner and question.
- The app does not yet automatically launch a topic-specific practice session from a plan card. The plan gives the target topic and question count; direct task-to-practice routing is a follow-on integration.
- Push notifications/reminders are not included in this phase.

## Security notes
- Both tables have row-level security scoped to `auth.uid()`.
- Plan-generation and read RPCs require an authenticated session and only use that user's attempts.
- Correct answers are not returned by the wrong-question notebook; only the question and its explanation are shown.

## Verification status
Source and migration authored and packaged. Flutter build, live Supabase migration execution, and device/runtime testing have not been performed in this environment. The project owner will perform manual testing.
