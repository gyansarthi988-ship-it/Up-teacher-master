# Google OAuth setup

1. In Google Cloud Console, create/select a project owned by you.
2. Configure the OAuth consent screen and publish/test it according to your rollout needs.
3. Create OAuth credentials as required by Supabase's Google provider instructions.
4. In Supabase Dashboard > Authentication > Providers > Google, enable Google and enter the client ID and secret.
5. Copy the Supabase callback URL shown in that provider configuration and add it as an authorized redirect URI in Google Cloud.
6. In Supabase Authentication > URL Configuration, add:
   `com.rsglobalacademy.upteachermaster://login-callback/`
7. Add the matching Android intent filter to the main activity as described in `mobile/README_ANDROID_BOOTSTRAP.md`.
8. Test on a physical Android device. OAuth may not complete correctly until the redirect URI and provider settings match exactly.

Do not put the Google OAuth client secret in the Flutter app. The secret belongs only in the Supabase provider configuration.
