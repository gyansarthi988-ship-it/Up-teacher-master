# Phase 3K Changelog

- Added server-side entitlement filtering for published study materials.
- Added private Storage object read policy tied to published material records and live Premium access.
- Added 10-minute signed-link delivery from the Flutter student app.
- Added bilingual Study Materials screen and Home drawer entry.
- Added `get_material_access_summary()` RPC.
- Added deployment and content-publishing instructions.

No payment credentials or service-role secrets are included.
