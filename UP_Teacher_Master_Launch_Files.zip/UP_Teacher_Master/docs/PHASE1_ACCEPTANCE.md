# Phase 1 acceptance criteria

## Student Android app
- [ ] App launches without Supabase credentials and displays setup instructions.
- [ ] With Supabase credentials, app initializes Supabase.
- [ ] Phone OTP send and verification work with a configured SMS provider.
- [ ] Google OAuth completes and returns to the app using the configured deep link.
- [ ] Authenticated user sees the dashboard and four examination choices.
- [ ] Sign-out returns to the login screen.
- [ ] Language selector switches the Phase 1 home-screen labels.

## Admin web panel
- [ ] Admin can sign in with an account provisioned by the owner.
- [ ] Student/non-admin account is denied access.
- [ ] Admin sees configured examination catalogue.
- [ ] Sign-out clears the session.

## Backend
- [ ] Migration applies successfully.
- [ ] New auth user gets profile and student role.
- [ ] Student can read active examinations.
- [ ] Student cannot grant self an admin role.
- [ ] Student can only access own profile and exam selections.
- [ ] Admin can manage examination catalogue.
