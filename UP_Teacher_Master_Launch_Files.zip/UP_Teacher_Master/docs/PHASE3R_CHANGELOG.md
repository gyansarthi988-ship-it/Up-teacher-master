# Phase 3R Changelog

- Added `spaced_revision_screen.dart` with Hindi/English UI.
- Added revision queue, recall-rating workflow and progress indicators.
- Added migration `0015_spaced_revision_mastery.sql` with adaptive scheduling columns, review history, RLS and secure RPCs.
- Added Spaced Revision entry to the student navigation drawer.
- Preserved the preceding Phase 3Q source and features.
