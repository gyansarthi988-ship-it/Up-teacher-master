# Phase 3B Changelog

- Added bilingual full mock test runner screen.
- Added countdown timer and automatic submission at zero.
- Added horizontal question palette with answered, current and marked-for-review states.
- Added mark-for-review toggle, previous/next navigation and submit confirmation.
- Added result summary for correct, wrong, unanswered, attempted and score/max score.
- Added configurable mock-test template schema for exam admins.
- Reuses Phase 3 secure `submit_test_attempt` scoring RPC; correct answers are not fetched by the client.
