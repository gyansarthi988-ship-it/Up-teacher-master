# Phase 3Y – Smart Revision + Study Material Integration

## Included
- Revision queue now returns the source question's `topic_id`.
- The mobile spaced-revision screen loads published study materials linked to the current question topic.
- Related notes/PDFs/links appear directly beneath the revision question.
- Existing premium entitlement check is retained; private Storage files use short-lived signed links.
- The learner can move from a weak-question revision card to the exact linked study resource.

## Database migration
Apply `supabase/migrations/0019_revision_material_links.sql`. It replaces the authenticated revision queue RPC to include `topic_id`; it does not change revision scheduling or scoring.

## Content dependency
Admin must publish `study_materials` and assign the matching `topic_id`. Unlinked resources will not appear in revision cards. Premium content continues to rely on existing membership and Storage policies.

## Owner manual verification
After migration, publish a sample resource linked to a topic used by a due revision question. Confirm it appears under that question, free resources open, and premium resources require valid membership.
