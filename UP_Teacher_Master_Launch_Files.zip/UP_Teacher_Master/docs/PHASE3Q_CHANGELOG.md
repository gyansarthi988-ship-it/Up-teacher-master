# Phase 3Q Changelog
- Added learner-specific mentor preferences and secure save/dashboard RPCs.
- Added bilingual AI Personal Study Mentor screen with goal setup, accuracy summary, adaptive plan, and refresh.
- Added entry in the student navigation drawer.
- No client-side service-role key or AI provider secret.
