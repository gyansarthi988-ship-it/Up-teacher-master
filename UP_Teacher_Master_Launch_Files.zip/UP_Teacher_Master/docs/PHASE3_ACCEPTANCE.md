# Phase 3 Acceptance Checklist

- [ ] Apply migration 0003 after verifying Phase 1 and Phase 2 are present.
- [ ] Confirm a normal authenticated student can read published questions and options.
- [ ] Confirm the student cannot select from `question_answers` directly.
- [ ] Publish at least 3 test questions with options and answer keys.
- [ ] Open an exam > subject > chapter > topic and launch practice.
- [ ] Submit correct, incorrect and skipped answers; verify score and negative marking.
- [ ] Confirm the result review displays correct option and explanation only after submission.
- [ ] Confirm one student's attempt records are not visible to another student.
- [ ] Run `flutter analyze` and `flutter build apk --release` in CI.
