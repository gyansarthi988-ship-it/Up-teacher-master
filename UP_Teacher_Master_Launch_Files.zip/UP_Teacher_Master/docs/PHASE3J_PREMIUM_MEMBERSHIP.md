# Phase 3J — Premium Membership & Subscription

## Included
- Membership plans with INR price and duration.
- Subscription and payment-order ledger with RLS; users can read only their own records.
- `has_premium_access()` and `get_my_membership()` server-side entitlement functions.
- Flutter Premium Membership page with bilingual plan display and Razorpay Checkout launch.
- Premium mock-test catalogue checks the server entitlement function before allowing a premium test to start.
- Admin-only complimentary membership grant RPC with audit log.
- Supabase Edge Function `create-payment-order`: authenticates the user, reads an active plan, creates a Razorpay order server-side and stores the order.
- Supabase Edge Function `razorpay-webhook`: verifies HMAC signature, matches amount/currency/order, records captured payment and activates membership idempotently.

## Database migration
Run `supabase/migrations/0008_premium_membership.sql` once after migrations 0001–0007.

## Supabase Edge Function secrets
Set these secrets in the Supabase project (never put them in Flutter or the public admin bundle):
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`
- `RAZORPAY_WEBHOOK_SECRET`
- Supabase platform-provided `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` must be available to functions.

Deploy functions:
- `supabase functions deploy create-payment-order`
- `supabase functions deploy razorpay-webhook`

Configure Razorpay webhook URL as `https://<project-ref>.supabase.co/functions/v1/razorpay-webhook` and subscribe to `payment.captured`. Use the exact webhook secret configured above. Use Razorpay test mode first.

## Security notes
- Never grant premium from a client callback. The Flutter success callback only refreshes membership; the verified webhook grants entitlement.
- No client write policies exist for payment_orders or user_subscriptions.
- Admin complimentary grants are audited. They are separate from payment activation.
- Payment refunds, chargebacks, subscription auto-renewal, GST invoices and reconciliation dashboards are not part of this phase.
- The webhook currently handles `payment.captured` one-time orders. If webhook delivery is interrupted after payment row update but before subscription insert, reconcile the order and subscription before manually retrying; do not mark it paid by hand without provider verification.

## Important setup boundary
Razorpay account activation, KYC, live keys, webhook setup and production deployment require the project owner's account actions. The source is prepared but payment cannot be accepted until those are configured.

## Checks and limitations
Source structure and SQL were reviewed. No Supabase migration execution, Edge Function deployment, Flutter build, Razorpay checkout runtime or device testing was performed. The project owner handles manual testing.
