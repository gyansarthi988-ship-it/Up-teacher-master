# Phase 3 — Question Practice & Mock Engine

## Included
- Topic-wise published MCQ loading in the Flutter app.
- Bilingual question and option display.
- Answer selection, question navigation and progress indicator.
- Secure server-side scoring through `submit_test_attempt` RPC.
- Attempt history storage and answer/explanation review after submission.
- Correct answer table remains inaccessible to student clients; answer keys are returned only after a validated submission.

## Database migration
Run `supabase/migrations/0003_practice_mock_engine.sql` in Supabase SQL Editor after the Phase 1 and Phase 2 migrations. Do not rerun it if it has already been applied; the table/policy creation is not fully idempotent.

## Content requirements
For a topic to show questions, the content team must publish questions in `questions`, add 2–4 rows in `question_options`, and add the correct option in `question_answers`. Optional bilingual explanations belong in `question_explanations`.

## Current scope / known limitations
- The student app currently launches topic-wise practice sets (up to 20 published questions).
- The database RPC supports `practice` and `mock` attempt modes, negative marking, and up to 300 questions. A dedicated exam-pattern-driven mock-test setup, countdown selection, pause/resume, leaderboard, analytics dashboards, and premium gating are follow-on tasks.
- The UI uses network access and requires an authenticated Supabase user.
- This package has not been compiled with Flutter or tested against the live Supabase project. Run Flutter analyze/build and test with sample published questions before release.
