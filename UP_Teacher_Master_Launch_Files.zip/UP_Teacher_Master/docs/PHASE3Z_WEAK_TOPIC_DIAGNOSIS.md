# Phase 3Z – Weak Topic Diagnosis & Improvement Plan

## What changed
- Added a bilingual Weak Topic Diagnosis screen to the Flutter app.
- Reads the signed-in learner's existing `get_my_performance_analytics` RPC response.
- Sorts analytics-flagged weak topics by lowest accuracy first.
- Gives tiered, actionable improvement steps based on accuracy bands (<40%, 40–59%, 60%+).
- Adds a drawer entry so learners can open the screen.

## Backend
No new migration is required. This phase reuses the existing user-scoped performance analytics RPC and topic-level `weak`, `accuracy`, and `attempted` fields.

## Important
- Suggestions are deterministic study guidance, not an AI-verified diagnosis.
- Results depend on submitted tests and published analytics data.
- No Flutter build, Supabase deployment, or device runtime test was performed. Manual testing is handled by the project owner.
