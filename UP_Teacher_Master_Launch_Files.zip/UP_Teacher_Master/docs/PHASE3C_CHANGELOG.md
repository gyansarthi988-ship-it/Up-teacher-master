# Phase 3C Changelog

- Added secure personal performance analytics SQL RPC and supporting index.
- Added subject-wise and topic-wise accuracy aggregation.
- Added recent attempt trend (latest 20 submissions).
- Added weak-topic detection rule (less than 50% accuracy after at least 3 answered questions).
- Added bilingual Flutter performance dashboard with summary cards, subject progress bars, weak-topic list and recent tests.
- Added Home drawer navigation entry for My Performance.
