# Phase 3L — Membership Administration

## Included
- Admin panel membership manager for editing plan names, duration, INR price and sale availability.
- Recent subscription list (latest 100) with profile details where available.
- Admin-only membership revocation RPC with audit log entry.
- Admin-only aggregate summary RPC for active memberships, paid orders, pending orders and recorded revenue.
- Mobile Premium Membership screen now shows bilingual plan names and the latest 10 purchase orders returned by `get_my_membership()`.

## Migration
Run `supabase/migrations/0010_membership_admin_controls.sql` after migrations `0001` through `0009`.

## Security
- Existing RLS on `membership_plans`, `payment_orders` and `user_subscriptions` remains in force.
- Plan editing is limited by the existing `public.is_admin()` policy.
- Revocation is through a security-definer RPC that checks `public.is_admin()` and writes an audit log.
- No admin UI action can mark an order as paid. Paid status and activation remain webhook-controlled.
- The membership manager relies on profile/subscription relationship discovery; if Supabase does not infer the relationship in the deployed schema, adjust the select to fetch profile rows separately.

## Deployment dependencies
- Razorpay live payment still requires server-side secrets and a configured webhook.
- This phase does not create or deploy secrets, Edge Functions, or migrations to the user's Supabase project.
- Prices are editable in admin after migration; seeded defaults in migration 0008 are ₹99, ₹249 and ₹799. Confirm actual commercial prices before enabling sales.

## Verification boundary
Source inspection and ZIP integrity checks only. No Flutter build, Next.js production build, live Supabase migration, Razorpay transaction, or device runtime test was performed.
