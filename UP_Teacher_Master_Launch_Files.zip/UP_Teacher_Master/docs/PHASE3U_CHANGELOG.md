# Phase 3U Changelog
- Added Daily Study Command Centre.
- Reused existing analytics and mentor RPCs; no new SQL migration.
- Added Home screen shortcut and drawer navigation entry.
- Added quick links to revision, smart plan, mentor and detailed analytics.
- No question content changed.
