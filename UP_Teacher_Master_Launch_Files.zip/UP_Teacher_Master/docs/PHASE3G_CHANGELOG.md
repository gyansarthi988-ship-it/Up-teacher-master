# Phase 3G Changelog

- Added `admin/app/components/MockTestBuilder.tsx`.
- Integrated Mock Test Builder into the authenticated admin control panel.
- Added template create/edit/publish/unpublish/delete workflows using the existing RLS-protected Supabase table.
- Added exam-pattern consistency checks for duration and question count.
- Added bilingual fields, marking configuration, premium metadata, language mode, display order and question-selection JSON editor.
- Added setup, JSON example, security notes and known limitations documentation.
- No new SQL migration required.
