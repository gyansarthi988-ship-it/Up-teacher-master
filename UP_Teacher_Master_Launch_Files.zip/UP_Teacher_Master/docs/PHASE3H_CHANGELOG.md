# Phase 3H Changelog

- Added bilingual question-content audit.
- Added four-option, answer-key integrity and explanation checks.
- Added topic-mapping and likely duplicate warnings.
- Added quality summary cards, text search and issue/status filters.
- Added review, approve, publish and return-to-draft controls.
- Blocked publishing in the quality panel when critical structural errors are present.
- No new SQL migration required.
