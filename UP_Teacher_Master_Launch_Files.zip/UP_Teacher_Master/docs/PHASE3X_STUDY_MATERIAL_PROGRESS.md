# Phase 3X – Study Material & Learning Completion

## Included
- Enhanced bilingual study material library.
- Search by material title.
- Filters: all, pending, completed, free, premium.
- Displays linked subject/chapter/topic metadata where available.
- Per-user learning status: Not started, In progress, Completed.
- Overall completed-material count and progress indicator.
- Preserves existing premium entitlement check and temporary signed Storage links.

## Database
Apply `supabase/migrations/0018_user_material_progress.sql`.
It creates per-user material progress with RLS so users can access only their own progress.

## Content dependency
Only published rows from `study_materials` appear. Admin must add verified notes/PDFs and link them to exam/subject/topic. This phase does not generate or invent study notes.

## Owner manual verification
After migration and material publishing, verify search, filters, status persistence, and free/premium access using suitable accounts.
