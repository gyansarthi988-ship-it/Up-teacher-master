# Phase 3P Changelog
- Added bilingual AI Doubt Solver screen and personal doubt history.
- Added `study_doubts` schema with RLS and admin read access.
- Added authenticated Edge Function calling AI provider server-side.
- Added five requests/hour basic per-user limit and error handling.
- Added Admin AI Doubt Review panel.
- Requires migration 0013 and secure Edge Function secret configuration.
