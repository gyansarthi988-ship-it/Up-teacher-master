# Phase 3V – Exam Readiness & Progress Indicators

## Included
- Bilingual Exam Readiness screen.
- Estimated readiness score derived from the signed-in user's performance analytics:
  - average score (55%)
  - accuracy (30%)
  - breadth of distinct practised topics (15%, capped at 8 topics)
  - small penalty for each flagged weak topic
- Subject accuracy indicators and weak-topic list.
- Navigation drawer entry.

## Important interpretation
This is a practice-data indicator, not a probability of passing, selection prediction, or guarantee. Topic breadth is the number of distinct topics present in the user's analytics, not full official syllabus completion. The formula is intentionally transparent and will be refined when a verified exam-specific syllabus coverage denominator is available.

## Backend
No new migration. Uses the existing user-scoped `get_my_performance_analytics` RPC (migration 0005).

## Owner-operated manual verification
1. Open Exam Readiness from navigation drawer.
2. With no submitted attempts, confirm the empty-data state.
3. After practice/mock submissions, refresh and inspect score and subject indicators.
4. Confirm weak topics reflect the analytics report.
